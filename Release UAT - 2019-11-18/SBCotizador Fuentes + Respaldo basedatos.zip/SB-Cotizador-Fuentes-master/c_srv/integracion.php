<?php 

error_reporting(E_ALL);
ini_set('display_errors', 1);


session_start();
include ('../c_sistema_util/util.php');

include ('../c_negocio/negIntegracion.php');
include ('../c_datos/dtIntegracion.php');

include ('../c_negocio/negSistema.php');
include ('../c_datos/dtSistema.php');

include ('../c_datos/DBFactory.php');

if(isset($_REQUEST["qwerty"]))
{
	util::decodeParamURL($_REQUEST["qwerty"]);
}


$acc = "";
if(isset($_REQUEST["acc"]))
{
	$acc = $_REQUEST["acc"];
}


if($acc == "EDITAURL")
{
    $claveIntegracion = $_REQUEST["claveIntegracion"];
    $nuevaUrl = $_REQUEST["nuevaUrl"];
    negIntegracion::EditaUrl($claveIntegracion,$nuevaUrl);
   echo json_encode("OK"); 
    
}


?>
