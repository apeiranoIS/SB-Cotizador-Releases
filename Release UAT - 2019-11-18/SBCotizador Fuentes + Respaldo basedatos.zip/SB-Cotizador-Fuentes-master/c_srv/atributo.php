<?php 
error_reporting(E_ALL);
ini_set('display_errors', 1);


session_start();
include ('../c_negocio/negAtributo.php');
include ('../c_datos/dtAtributo.php');
include ('../c_datos/DBFactory.php');

include ('../c_negocio/negSistema.php');
include ('../c_datos/dtSistema.php');

include ('../c_negocio/negUsuario.php');
include ('../c_datos/dtUsuario.php');

include ('../c_sistema_util/util.php');


$acc = "";
if(isset($_REQUEST["acc"]))
{
	$acc = $_REQUEST["acc"];
}

if($acc == "CREARATRIBUTO")
{
	$atributo		= $_REQUEST["atributo"];
    $tipo_atributo  = $_REQUEST["tipo_atributo"];
	$factorid       = $_REQUEST["factorid"];
	$obligatorio    = $_REQUEST["obligatorio"];
	$imprime        = $_REQUEST["imprime"];
    $posicion       = $_REQUEST["posicion"];
	$factor_monto   = $_REQUEST["factor_monto"];
    $factor_tipo    = "NORMAL";
    $modificable    = "SI";
    negAtributo::addAtributo($atributo,$tipo_atributo,$factorid,$obligatorio,$imprime,$posicion,$factor_monto,$factor_tipo,$modificable);
	echo json_encode("OK");
	
}
if($acc == "ADDVALORATRIBUTO"){
    $valor           = $_REQUEST["valor"];
    $valor_interno_1 = $_REQUEST["valor_interno_1"];
    $valor_interno_2 = $_REQUEST["valor_interno_2"];
    $valor_interno_3 = $_REQUEST["valor_interno_3"];
    $atributoid      = $_REQUEST["atributoid"];   
    negAtributo::addValorAtributo($valor,$valor_interno_1,$valor_interno_2,$valor_interno_3,$atributoid);
    echo json_encode("OK");
}
if($acc == "DELETEVALOR"){
    $atributovalorid = $_REQUEST["atributovalorid"];
    negAtributo::deleteValorAtributo($atributovalorid);
    echo json_encode("OK");
}

?>

