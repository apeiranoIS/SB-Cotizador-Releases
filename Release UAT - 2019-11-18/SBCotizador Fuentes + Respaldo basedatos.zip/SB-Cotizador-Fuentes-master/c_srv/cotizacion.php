<?php 
error_reporting(E_ALL);
ini_set('display_errors', 1);


session_start();
include ('../c_sistema_util/util.php');

include ('../c_negocio/negCotizacion.php');
include ('../c_datos/dtCotizacion.php');

include ('../c_negocio/negAsegurado.php');
include ('../c_datos/dtAsegurado.php');

include ('../c_negocio/negCorredor.php');
include ('../c_datos/dtCorredor.php');

include ('../c_negocio/negSistema.php');
include ('../c_datos/dtSistema.php');

include ('../c_negocio/negWorking.php');
include ('../c_datos/dtWorking.php');

include ('../c_negocio/negProducto.php');
include ('../c_datos/dtProducto.php');

include ('../c_datos/DBFactory.php');

if(isset($_REQUEST["qwerty"]))
{
	util::decodeParamURL($_REQUEST["qwerty"]);
}


$acc = "";
if(isset($_REQUEST["acc"]))
{
	$acc = $_REQUEST["acc"];
}

if($acc == "SAVETASAS")
{   
    $cotizacionid= $_REQUEST["cotizacionid"];
    $tasa_afecta= $_REQUEST["tasa_afecta"];
    $tasa_excenta= $_REQUEST["tasa_excenta"];
    $tasa_neta= $_REQUEST["tasa_neta"];
    negCotizacion::setTasas($cotizacionid,$tasa_afecta,$tasa_excenta,$tasa_neta);
    echo json_encode("OK");
}
if($acc == "ADDCOTIZACION")
{   
    $aseguradoid= $_REQUEST["aseguradoid"];
    $corredorid= $_REQUEST["corredorid"];
    $moneda= $_REQUEST["moneda"];
    $caracteristica_poliza= $_REQUEST["caracteristica_poliza"];
    $vigencia_desde= $_REQUEST["vigencia_desde"];
    $vigencia_hasta= $_REQUEST["vigencia_hasta"];
    $cantidad_ubicaciones= $_REQUEST["cantidad_ubicaciones"];
    $comision_afecta= $_REQUEST["comision_afecta"];
    $comision_exenta=$_REQUEST["comision_exenta"];
    
    $solicitud_corredor=$_REQUEST["solicitud_corredor"];
    $fecha_recepcion=$_REQUEST["fecha_recepcion"];
    $fecha_entrega=$_REQUEST["fecha_entrega"];
    $lineanegocioid=4;
    $segmentoid=6;
    $ramoid=$_REQUEST["ramoid"];
    $productoid=$_REQUEST["productoid"];
    $ejecutivo=$_REQUEST["ejecutivo"];
    $coberturas= "";
    $secciones="";
    $cliente_nombre = $_REQUEST["nombre_cliente"];
    $cliente_rut = $_REQUEST["rut_cliente"];
    $cliente_fecha_nac = $_REQUEST["fecha_nac_cliente"];
    $cliente_no = $_REQUEST["cliente_no"];
    
    $corredor_nombre= $_REQUEST["nombre_corredor"];
    $corredor_rut = $_REQUEST["rut_corredor"];
    //PENDIENTE ESTRUCTURA
    //$corredor_no =$_REQUEST["corredor_no"];
    $corredor_no = rand(1,20000);//esto es pendiente
    if(isset($_REQUEST["cobertura"]))
    {
        $coberturas = $_REQUEST["cobertura"];
    }
    if(isset($_REQUEST["seccion"]))
    {
        $secciones = $_REQUEST["seccion"];
    }
    
    $arr = explode("-", $vigencia_desde);
    $vigencia_desde = $arr[2]."-".$arr[1]."-".$arr[0];
    $arr = explode("-", $vigencia_hasta);
    $vigencia_hasta = $arr[2]."-".$arr[1]."-".$arr[0];
   
    
    if($fecha_recepcion!="")
    {
        $arr = explode("-", $fecha_recepcion);
        $fecha_recepcion = $arr[2]."-".$arr[1]."-".$arr[0];
    }else{$fecha_recepcion="NULL";}
    
    if($fecha_entrega!="")
    {
        $arr = explode("-", $fecha_entrega);
        $fecha_entrega = $arr[2]."-".$arr[1]."-".$arr[0];
    }else{$fecha_entrega="NULL";}
    
    $asegurado = negAsegurado::validaAseguradoByIDTI($cliente_no);
    if(count($asegurado) > 0)
    {
        negAsegurado::editAseguradoIntegrado($cliente_nombre,$cliente_rut,$cliente_no,$asegurado["aseguradoid"]);
        $aseguradoid = $asegurado["aseguradoid"];
    }
    else 
    {
        $aseguradoid =  negAsegurado::creaAseguradoIntegrado($cliente_nombre,$cliente_rut,$cliente_no);
    }
    
    $corredor = dtCorredor::buscaCorredorNombreCompleto($corredor_nombre);
    if(count($corredor) > 0)
    {
        negCorredor::editCorredorIntegrado($corredor_nombre,$corredor_rut,$corredor_no);
        $corredorid = $corredor[0]["corredorid"];
    }
    else
    {   
        $corredorid = negCorredor::creaCorredorIntegrado($corredor_nombre,$corredor_rut,$corredor_no);
    }
    
    
    $cot = negCotizacion::addCotizacion($aseguradoid, $corredorid, $moneda, $vigencia_desde, $vigencia_hasta, $caracteristica_poliza, $cantidad_ubicaciones
                                            ,$comision_afecta, $comision_exenta,$_SESSION["IGT-usuarioid"], $solicitud_corredor,$fecha_recepcion,$fecha_entrega
        ,$lineanegocioid,$segmentoid,$ramoid,$productoid,$ejecutivo);
    
    $cotizacionid = $cot["cotizacionid"];
    
    negCotizacion::addCotizacionDeducibleFijo($cotizacionid);
    
    $goDetail = util::creaURLApp(1, "edita_cotizacion","&cotizacionid=".$cotizacionid);
    echo json_encode($goDetail);
}
if($acc == "EDITACOTIZACION")
{   
    $cotizacionid= $_REQUEST["cotizacionid"];
    $aseguradoid= $_REQUEST["aseguradoid"];
    $corredorid= $_REQUEST["corredorid"];
    $moneda= $_REQUEST["moneda"];
    $caracteristica_poliza= $_REQUEST["caracteristica_poliza"];
    $vigencia_desde= $_REQUEST["vigencia_desde"];
    $vigencia_hasta= $_REQUEST["vigencia_hasta"];
    $cantidad_ubicaciones= $_REQUEST["cantidad_ubicaciones"];
    $comision_afecta= $_REQUEST["comision_afecta"];
    $comision_exenta=$_REQUEST["comision_exenta"];
    
    $solicitud_corredor=$_REQUEST["solicitud_corredor"];
    $fecha_recepcion=$_REQUEST["fecha_recepcion"];
    $fecha_entrega=$_REQUEST["fecha_entrega"];
    $lineanegocioid=$_REQUEST["lineanegocio"];
    $segmentoid=0;
    $ramoid=$_REQUEST["ramoid"];
    $productoid=$_REQUEST["productoid"];
    $ejecutivo=$_REQUEST["ejecutivo"];
    $cliente_nombre = $_REQUEST["nombre_cliente"];
    $cliente_rut = $_REQUEST["rut_cliente"];
    $cliente_fecha_nac = $_REQUEST["fecha_nac_cliente"];
    $cliente_no = $_REQUEST["cliente_no"];
    
    $corredor_nombre= $_REQUEST["nombre_corredor"];
    $corredor_rut = $_REQUEST["rut_corredor"];
    
    $secciones 			= "";
    if(isset($_REQUEST["secciones"]))
    {
        $secciones = $_REQUEST["secciones"];
    }
    
    $arr = explode("-", $vigencia_desde);
    $vigencia_desde = $arr[2]."-".$arr[1]."-".$arr[0];
    $arr = explode("-", $vigencia_hasta);
    $vigencia_hasta = $arr[2]."-".$arr[1]."-".$arr[0];
    
    
    if($fecha_recepcion!="")
    {
        $arr = explode("-", $fecha_recepcion);
        $fecha_recepcion = $arr[2]."-".$arr[1]."-".$arr[0];
    }else{$fecha_recepcion="NULL";}
    
    if($fecha_entrega!="")
    {
        $arr = explode("-", $fecha_entrega);
        $fecha_entrega = $arr[2]."-".$arr[1]."-".$arr[0];
    }else{$fecha_entrega="NULL";}
    
    $asegurado = negAsegurado::validaAseguradoByIDTI($cliente_no);
    if(count($asegurado) > 0)
    {
        negAsegurado::editAseguradoIntegrado($cliente_nombre,$cliente_rut,$cliente_no,$asegurado["aseguradoid"]);
        $aseguradoid = $asegurado["aseguradoid"];
    }
    else
    {
        $aseguradoid =  negAsegurado::creaAseguradoIntegrado($cliente_nombre,$cliente_rut,$cliente_no);
    }
    
    $corredor = dtCorredor::buscaCorredorNombreCompleto($corredor_nombre);
    if(count($corredor) > 0)
    {
        negCorredor::editCorredorIntegrado($corredor_nombre,$corredor_rut);
        $corredorid = $corredor[0]["corredorid"];
    }
    else
    {
        $corredorid = negCorredor::creaCorredorIntegrado($corredor_nombre,$corredor_rut);
    }
    
    $cot = negCotizacion::editCotizacion($cotizacionid,$aseguradoid, $corredorid, $moneda, $vigencia_desde, $vigencia_hasta, $caracteristica_poliza, $cantidad_ubicaciones, $comision_afecta, $comision_exenta,$_SESSION["IGT-usuarioid"], $solicitud_corredor,$fecha_recepcion,$fecha_entrega,$lineanegocioid,$segmentoid,$ramoid,$productoid,$ejecutivo,$secciones);
    
    echo json_encode("OK");
}

if($acc == "ADDUBICACION")
{   
    $cotizacionid= $_REQUEST["cotizacionid_ub"];
    $nombre= $_REQUEST["nombre_ubicacion"];
    $usuarioid= $_SESSION["IGT-usuarioid"];
    
    $idUbica = negCotizacion::addCotizacionUbicacion($cotizacionid, $nombre, $usuarioid);
    echo json_encode($idUbica);
}

if($acc == "MODIFICAUBICACION")
{
    $ubicacionid    = $_REQUEST["ubicacionid"];
    $nombre         = $_REQUEST["nombre_ubicacion"];
    $usuarioid      = $_SESSION["IGT-usuarioid"];
    $cotizacionidub = $_REQUEST["cotizacionidub"];
    
    negCotizacion::editaCotizacionUbicacion($ubicacionid, $nombre, $usuarioid,$cotizacionidub);
    echo json_encode("OK");
    
}
if($acc == "SAVEMATERIA")
{
    $cotizacionid= $_REQUEST["cotizacionid"];
    $primaneta= $_REQUEST["primaneta"];
    $primabruta= $_REQUEST["primabruta"];
    $tasabruta= $_REQUEST["tasabruta"];
    $sublimite= $_REQUEST["sublimite"];
    $coberturaid= $_REQUEST["coberturaid"];
    $tasaneta = $_REQUEST["tasaneta"];
    
    $sublimite = str_replace(",", ".", $sublimite);
    $primaneta = str_replace(",", ".", $primaneta);
    $primabruta = str_replace(",", ".", $primabruta);
    $tasabruta = str_replace(",", ".", $tasabruta);
    $tasaneta = str_replace(",", ".", $tasaneta);
    
    negCotizacion::addCoberturaCotizacion($cotizacionid, $coberturaid, $sublimite, $tasaneta, $tasabruta, $primaneta, $primabruta);
}
if($acc == "SAVESUBLIMITE")
{
    $cotizacionid   = $_REQUEST["cotizacionid"];
    $valor          = $_REQUEST["valor"];
    $sublimiteid    = $_REQUEST["sublimiteid"];
    
    negCotizacion::saveSublimite($cotizacionid,$valor,$sublimiteid);
    
}
if($acc == "SAVETASANETASUBLIMITE")
{
    $cotizacionid   = $_REQUEST["cotizacionid"];
    $valor          = $_REQUEST["valor"];
    $sublimiteid    = $_REQUEST["sublimiteid"];
    
    negCotizacion::saveTasaNetaSublimite($cotizacionid,$valor,$sublimiteid);
    
}
if($acc == "SAVETASABRUTASUBLIMITE")
{
    $cotizacionid   = $_REQUEST["cotizacionid"];
    $valor          = $_REQUEST["valor"];
    $sublimiteid    = $_REQUEST["sublimiteid"];
    
    negCotizacion::saveTasaBrutaSublimite($cotizacionid,$valor,$sublimiteid);
    
}
if($acc == "SAVEPRIMANETASUBLIMITE")
{
    $cotizacionid   = $_REQUEST["cotizacionid"];
    $valor          = $_REQUEST["valor"];
    $sublimiteid    = $_REQUEST["sublimiteid"];
    
    negCotizacion::savePrimaNetaSublimite($cotizacionid,$valor,$sublimiteid);
    
}
if($acc == "SAVEPRIMABRUTASUBLIMITE")
{
    $cotizacionid   = $_REQUEST["cotizacionid"];
    $valor          = $_REQUEST["valor"];
    $sublimiteid    = $_REQUEST["sublimiteid"];
    
    negCotizacion::savePrimaBrutaSublimite($cotizacionid,$valor,$sublimiteid);
    
}
if($acc == "SAVEDEDUCIBLE")
{
    $cotizacionid= $_REQUEST["cotizacionid"];
    $valor= $_REQUEST["valor"];
    $deducibleid= $_REQUEST["deducibleid"];
    $tipo = $_REQUEST["tipo"];
    
    negCotizacion::saveDeducible($cotizacionid,$valor,$deducibleid,$tipo);
    
}
if($acc == "GUARDALIMITES")
{
    $cotizacionid= $_REQUEST["cotizacionid"];
    $limite_poliza= $_REQUEST["limite_poliza"];
    $limite_todas_polizas_grupo= $_REQUEST["limite_todas_polizas_grupo"];
    
    
    
    $cotizacionid = str_replace(",", ".", $cotizacionid);
    $limite_poliza = str_replace(",", ".", $limite_poliza);
    $limite_todas_polizas_grupo = str_replace(",", ".", $limite_todas_polizas_grupo);
    
    negCotizacion::addLimite($cotizacionid, $limite_poliza, $limite_todas_polizas_grupo);
}
if($acc=="VALIDAYENVIACOTIZACIONENCURSO")
{
    $cotizacionid= $_REQUEST["cotizacionid"];
    $salida= negCotizacion::validaCotizacionEnReserva($cotizacionid,$_SESSION["IGT-usuarioid"]);
    echo json_encode($salida);
}

if($acc=="ALERTACOTIZACIONENCURSO")
{
    $cotizacionid= $_REQUEST["cotizacionid"];
    $salida= negCotizacion::alertasCotizacionEnReserva($cotizacionid);
    echo json_encode($salida);
}
if($acc=="VALIDABLOQUEOCOTIZACIONENCURSO")
{
    $cotizacionid= $_REQUEST["cotizacionid"];
    $salida= negCotizacion::validaBloqueoCotizacionEnReserva($cotizacionid);
    echo json_encode($salida);
}
if($acc=="VOLVERRESERVA")
{
    $cotizacionid= $_REQUEST["cotizacionid"];
    $comentario= $_REQUEST["comentario"];
    negCotizacion::volverReservaCotizacion($cotizacionid,$comentario,$_SESSION["IGT-usuarioid"]);
    echo json_encode("OK");
    
}
if($acc=="RECHAZACOTIZACION")
{
    echo json_encode("OK");
    
}
if($acc=="APROBARCOTIZACIONTOENCURSO")
{
    $cotizacionid= $_REQUEST["cotizacionid"];
    $comentario= $_REQUEST["comentario"];
    negCotizacion::aprobarCotizacionToEnCurso($cotizacionid,$comentario,$_SESSION["IGT-usuarioid"]);
    echo json_encode("OK");
}
if($acc=="VALIDAYENVIACOTIZACIONTOADJUDICA")
{
    $cotizacionid= $_REQUEST["cotizacionid"];
    $salida= negCotizacion::validaCotizacionYAdjudica($cotizacionid,$_SESSION["IGT-usuarioid"]);
    echo json_encode($salida);
}
if($acc=="GETCOBERTURASPORIDPRODUCTO")
{
    $prodId = $_REQUEST["prodid"];
    
    $coberturas = negCotizacion::getCoberturasPorProductro($prodId);
    echo json_encode($coberturas);
}
if($acc=="LISTAMATERIASUBICACION")
{
    $cotizacionid = $_REQUEST["cotizacionid"];
    
    $seccion = negCotizacion::getMateriasPorCotiSeccion($cotizacionid);
    echo json_encode($seccion);   
}
if($acc == "PRODUCTOXRAMOYLN"){
    $ramo = $_REQUEST["ramo"];
    $ln = $_REQUEST["linea_negocio"];
    $productos = negCotizacion::getProductosXramoYln($ramo,$ln);
    
    $prodLNUsuario  = negProducto::getProductosByusuarioLineaNegocio($_SESSION["IGT-usuarioid"]);
    $arr = array();
    foreach($productos as $p)
    {
        foreach($prodLNUsuario as $pl)
        {
            if($p["productoid"] == $pl["productoid"])
            {
                $arr[] = $p;
            }
        }
    }
    
    echo json_encode($arr);
}
if($acc == "GETRAMOYLINEAXPRODUCTO"){
    $productoid = $_REQUEST["productoid"];
    echo json_encode(negCotizacion::getRamoyLineaXproducto($productoid));
}
if($acc == "ADDSINIESTRALIDADCOTIZACION"){
    $cotizacionid= $_REQUEST["cotizacionid"];
    $ultimo_anio = $_REQUEST["ultimo_anio"];
    $nro_anios = $_REQUEST["nro_anios"];
    negCotizacion::addSiniestralidadCotizacion($cotizacionid,$ultimo_anio,$nro_anios);
    echo json_encode("OK");
}
if($acc == "GETSINIESTRALIDADXCOTIZACIONID"){
    $cotizacionid= $_REQUEST["cotizacionid"];
    echo json_encode(negCotizacion::getSiniestralidadXcotizacionid($cotizacionid));
}
if($acc == "EDITSINIESTRALIDAD"){
    $cotizacionsiniestralidadid= $_REQUEST["cotizacionsiniestralidadid"];
    $prima = $_REQUEST["prima"];
    $tiv = $_REQUEST["tiv"];
    $nro_reclamo = $_REQUEST["nro_reclamo"];
    $pagado = $_REQUEST["pagado"];
    $pendiente = $_REQUEST["pendiente"];
    $gastos_honorarios = $_REQUEST["gastos_honorarios"];
    negCotizacion::editSiniestralidad($cotizacionsiniestralidadid,$prima,$tiv,$nro_reclamo,$pagado,$pendiente,$gastos_honorarios);
    echo json_encode("OK");
    
}
if($acc == "GETDETALLEUBICACIONE")
{
    $ubicacionid = $_REQUEST["ubicacionid"];
    echo json_encode(negCotizacion::getUbicacionDetalle($ubicacionid));
}
if($acc == "SAVEMATERIATOCOTIZACIONUBICACION")
{
    $cotizacionid = $_REQUEST["cotizacionid"];
    $ubicacionid = $_REQUEST["ubicacionid"];
    $materiaid = $_REQUEST["materiaid"];
    negCotizacion::addCotizacionUbicacionMateria($cotizacionid,$ubicacionid,$materiaid);
    echo json_encode("OK");
}

if($acc == "GETMATERIASBYUBICACION")
{
    $cotizacionid = $_REQUEST["cotizacionid"];
    $ubicacionid = $_REQUEST["ubicacionid"];
    echo json_encode(negCotizacion::getCotizacionUbicacionMateria($cotizacionid,$ubicacionid));
}
if($acc == "DELETEMATERIATOCOTIZACIONUBICACION")
{
    $cotizacionid = $_REQUEST["cotizacionid"];
    $ubicacionid = $_REQUEST["ubicacionid"];
    $materiaid = $_REQUEST["materiaid"];
    negCotizacion::deleteCotizacionUbicacionMateria($cotizacionid,$ubicacionid,$materiaid);
    echo json_encode("OK");
}
if($acc == "SAVEMONTOMATERIAUBICACION")
{
    $cotizacionid = $_REQUEST["cotizacionid"];
    $ubicacionid = $_REQUEST["ubicacionid"];
    $materiaid = $_REQUEST["materiaid"];
    $monto = $_REQUEST["monto"];
    negCotizacion::saveMontoMateriaUbicacion($cotizacionid,$ubicacionid,$materiaid,$monto);
    echo json_encode("OK");
}
if($acc == "GETPRODUCTOSDEDUCIBLES")
{
    $deducibleid = $_REQUEST["deducibleid"];
    echo json_encode(negCotizacion::getProductosByDeducible($deducibleid));
}
if($acc == "GETPRODUCTOSNODEDUCIBLE")
{
    $deducibleid = $_REQUEST["deducibleid"];
    echo json_encode(negCotizacion::getProductosDisponibleByDeducible($deducibleid));
}
if($acc == "ADDPRODUCTOSNODEDUCIBLE")
{
    $deducibleid = $_REQUEST["deducibleid"];
    $productoid  = $_REQUEST["productoid"];
    negCotizacion::addProductosDisponibleByDeducible($deducibleid,$productoid);
    echo json_encode("OK");
}
if($acc == "ELIMINAPRODUCTOSNODEDUCIBLE")
{
    $deducibleid = $_REQUEST["deducibleid"];
    $productoid  = $_REQUEST["productoid"];
    negCotizacion::elminaProductosDisponibleByDeducible($deducibleid,$productoid);
    echo json_encode("OK");
}
if($acc == "ADDPRODUCTOSCOBERTURASADICIONALESSUBLIMITE")
{
    $sublimiteid = $_REQUEST["sublimiteid"];
    $productoid  = $_REQUEST["productoid"];
    negCotizacion::setCobAdicionSublmitePorProducto($sublimiteid,$productoid);
    echo json_encode("OK");
}
if($acc == "ELIMINAPRODUCTOSNOCOBERTURAADICSUBLIMITE")
{
    $sublimiteid = $_REQUEST["sublimiteid"];
    $productoid  = $_REQUEST["productoid"];
    negCotizacion::eliminaCobAdicionSublmitePorProducto($sublimiteid,$productoid);
    echo json_encode("OK");
}
if($acc == "GETPRODUCTOSCOBERTURASADDSUBLIMITES")
{
    $sublimiteid = $_REQUEST["sublimiteid"];
    echo json_encode(negCotizacion::getProductoSublmitePorProducto($sublimiteid));
  
}
if($acc == "GETPRODUCTOSNOCOBERTURA")
{
    $sublimiteid = $_REQUEST["sublimiteid"];
    echo json_encode(negCotizacion::getProductoSublmitePorProductoDisponible($sublimiteid));

}
if($acc == "SAVECOMENTARIOSCOTIZACION")
{
    $cotizacionid = $_REQUEST["cotizacionid"];
    $comentario_prima = $_REQUEST["comentario_prima"];
    $comentario_siniestral = $_REQUEST["comentario_siniestral"];
    negCotizacion::addCOmentariosCotizacionSiniestralidad($cotizacionid,$comentario_prima,$comentario_siniestral);
    echo json_encode("OK");
}

if($acc == "ADDWORDINGLIBRE")
{
    $cotizacionid = $_REQUEST["cotizacionid"];
    $detalle_wording_add = $_REQUEST["detalle_wording_add"];
    $posicionid_wl = $_REQUEST["posicionid_wl"];
    negCotizacion::addWordingLibre($cotizacionid,$detalle_wording_add,$posicionid_wl);
    echo json_encode("OK");
    
}

if($acc == "GETWORDINGCOTIZACION")
{
    $cotizacionid = $_REQUEST["cotizacionid"];
    echo json_encode(negCotizacion::getWordingCotizacion($cotizacionid));
}
if($acc == "GETDETALLEWORDING")
{
    $cotizacionwordingid = $_REQUEST["cotizacionwordingid"];
    echo json_encode(negCotizacion::getWordingCotizacionByWording($cotizacionwordingid));
}
if($acc == "EDITAWORDINGLIBRE")
{
    $cotizacionwordingid = $_REQUEST["cotizacionwordingid"];
    $wording = $_REQUEST["detalle_wording_edita_hd_".$cotizacionwordingid];
    negCotizacion::editaWordingCotizacion($cotizacionwordingid,$wording);
    echo json_encode("OK");
}
if($acc == "DELETEWORDINGCOTIZACION")
{
    $cotizacionwordingid = $_REQUEST["cotizacionwordingid"];
    negCotizacion::eliminaWordingCotizacion($cotizacionwordingid);
    echo json_encode("OK");
}
if($acc == "GETWORDINGBYPRODUCTO")
{
    $productoid = $_REQUEST["productoid"];
    echo json_encode(negCotizacion::getWordingByProducto($productoid));
}
if($acc == "GETTAGWORDING")
{
    $wordingid = $_REQUEST["wordingid"];
    echo json_encode(negWorking::getTaggWording($wordingid));
}
if($acc == "ADDWORDINGTEMPLATE")
{
    $cotizacionid = $_REQUEST["cotizacionid"];
    $posicionid = $_REQUEST["posicionid_wt"];
    $wordingid = $_REQUEST["wordingid"];
    $detalle_wording = "";
 
    $wrk = negWorking::getWordingDetail($wordingid);
    foreach ($wrk as $w)
    {
        $detalle_wording = $w["detalle_wording"];
    }
    
    $cw =  negCotizacion::addWordingTemplate($cotizacionid,$wordingid,$posicionid,$detalle_wording);
    
   
    $cotizacionwordingid = $cw["cotizacionwordingid"];
    
    $tags = negWorking::getTaggWording($wordingid);
    foreach ($tags as $t)
    {
        $tag_var = $_REQUEST["tag_".$t["tagid"]];
        $tagid = $t["tagid"];
        //GUARDAR VALORES
        negCotizacion::addTagCotizacionWorking($cotizacionwordingid,$tag_var,$tagid,$t["tag"]);
    }
    
}

              if($acc=="ADDDOCUMENTOCOTIZACION")
              {
                  $cotizacionid   = $_REQUEST["cotizacionid"];
                  $tipo_documento = $_REQUEST["tipodocumento"];
                  $tipodocumento  = $_REQUEST["tipo_documento"];
                  $hoy= date("dmY[His]_");
                  $nameFile = $_FILES["documento"]['name'];
                  $tmpFile = $_FILES["documento"]['tmp_name'];
                  
                  $nombre_file = $nameFile;
                  $descripcion = $_REQUEST["descripcion_doc"];
                  
                  $ComercialPath = "";
                  $LegalesPath ="";
                  $GeneralPath="";
                  $OtroPath="";
                  $pathGral="";
                  $pathBD = "";
                  
                  $tipo_documento = str_replace(" ", "", $tipo_documento);
                  
                  if ($tmpFile != "")
                  {
                      $dirPath ="../c_archivos/COT_".$cotizacionid;
                      //$PathCoti = realpath($dirPath);
                      //$pathGral = $PathCoti;
                      $pathBD = "../c_archivos/COT_".$cotizacionid; 
                      $nameFile = $hoy.$nameFile;
                      $pathBD .=  "/".$nameFile;
                      
                      if(is_dir($dirPath))
                      {
                          move_uploaded_file($tmpFile, $dirPath."/".$nameFile);
                          
                      }else 
                      {
                          mkdir($dirPath,0777,true);
                      }
                      
                      move_uploaded_file($tmpFile, $dirPath."/".$nameFile);
                      negCotizacion::GuardarDirectorioDocumento($tipodocumento, $pathBD,$cotizacionid,$nombre_file,$descripcion);
                  }
                  
                  
                  
                   echo json_encode("OK");
              }
if($acc=="GETCOBERTURASDISPBYCOTIZACION")
{
    $cotizacionid = $_REQUEST["cotizacionid"];
    echo json_encode(negCotizacion::getCoberturasDispByCotizacion($cotizacionid));
}

if($acc=="GETCOBERTURASBYCOTIZACION")
{
    $cotizacionid = $_REQUEST["cotizacionid"];
    echo json_encode(negCotizacion::getCoberturasByCotizacion($cotizacionid));
}
if($acc=="SAVECOBERTURATOCOTIZACION")
{
    $coberturaid  = $_REQUEST["coberturaid"];
    $cotizacionid = $_REQUEST["cotizacionid"];
    negCotizacion::addCoberturaToCotizacion($cotizacionid,$coberturaid);
    echo json_encode("OK");
}
if($acc=="DELETECOBERTURACOTIZACION")
{
    $coberturaid  = $_REQUEST["coberturaid"];
    $cotizacionid = $_REQUEST["cotizacionid"];
    negCotizacion::deleteCoberturaToCotizacion($cotizacionid,$coberturaid);
    echo json_encode("OK");
}

if($acc=="ELIMINAARCHIVO")
{
    $iddirectorio = $_REQUEST["idirectorio"];
    $fullPath = negCotizacion::getDirectorioByid($iddirectorio);
    $fullPath = $fullPath['directorio_documento'];
    $cotizacionid = $_REQUEST["cotizacionid"];
    negCotizacion::eliminaDirectorio($iddirectorio);
    unlink($fullPath);
   echo json_encode("OK");
}
if($acc=="DELETECOBERTURACOTIZACION")
{
    $coberturaid  = $_REQUEST["coberturaid"];
    $cotizacionid = $_REQUEST["cotizacionid"];
    negCotizacion::deleteCoberturaToCotizacion($cotizacionid,$coberturaid);
    echo json_encode("OK");
}
if($acc=="ADDNOTACOTIZACION")
{
    $nota  = $_REQUEST["nota_cotizacion"];
    $cotizacionid = $_REQUEST["nota_cotizacionid"];
    $nota = str_replace("\n", "<br />", $nota);
    negCotizacion::addNotaCotizacion($cotizacionid,$nota,$_SESSION["IGT-usuarioid"]);
    echo json_encode("OK");
    
}
if($acc=="GETNOTASCOTIZACION")
{
    echo json_encode(negCotizacion::getNotasCotizacion($_REQUEST["cotizacionid"]));
}
if($acc=="SAVEASEGURADOCOTIZA")
{
    $cliente_nombre = $_REQUEST["nombre_cliente_save"];
    $cliente_rut = $_REQUEST["rut_cliente_save"];
    $cliente_no = $_REQUEST["cliente_no_save"];
    $aseguradoid = 0;
    $asegurado = negAsegurado::validaAseguradoByIDTI($cliente_no);

    if(count($asegurado) > 0)
    {
        negAsegurado::editAseguradoIntegrado($cliente_nombre,$cliente_rut,$cliente_no,$asegurado["aseguradoid"]);
        $aseguradoid = $asegurado["aseguradoid"];
    }
    else
    {
        $aseguradoid =  negAsegurado::creaAseguradoIntegrado($cliente_nombre,$cliente_rut,$cliente_no);
    }
    
    echo json_encode($aseguradoid);
}
if($acc=="SAVECOASEGURO")
{
    $cotizacionid = $_REQUEST["cotizacionid"];
    $coaseguro = $_REQUEST["coaseguro"];
    $tc = $_REQUEST["tc"];
    $pc = $_REQUEST["pc"];
    negCotizacion::addCoaseguroToCotizacion($cotizacionid,$coaseguro,$tc,$pc);
}
if($acc=="ADDPARTICIPANTECOASEGURO")
{
    $cotizacionid = $_REQUEST["cotizacionid"];
    $coaseguradorid = $_REQUEST["coaseguradorid"];

    negCotizacion::addCoaseguroParticipanteToCotizacion($cotizacionid,$coaseguradorid);
}
if($acc=="GETCOASEGURADORESDISP")
{
    $cotizacionid = $_REQUEST["cotizacionid"];
    echo json_encode(negCotizacion::getCoasegurosDisponiblesByCotizacion($cotizacionid));
}
if($acc=="GETCOASEGURADORESBYCOTIZACION")
{
    $cotizacionid = $_REQUEST["cotizacionid"];
    echo json_encode(negCotizacion::getCoasegurosByCotizacion($cotizacionid));
}
if($acc=="ELIMINAPARTICIPANTECOTI")
{
    $cotizacionid = $_REQUEST["cotizacionid"];
    $coaseguradorid = $_REQUEST["coaseguradorid"];
    negCotizacion::eliminaCoaseguradorCotizacion($cotizacionid,$coaseguradorid);
    echo json_encode("OK");
}
if($acc=="SAVEPORCCOASEGURADOR")
{
    $cotizacionid = $_REQUEST["cotizacionid"];
    $coaseguradorid = $_REQUEST["coaseguradorid"];
    $pc = $_REQUEST["pc"];
    negCotizacion::addCoaseguroParticipePorcCotizacion($cotizacionid,$coaseguradorid,$pc);
    echo json_encode("OK");
}
if($acc=="SAVEPARTICIPACIONCOASEGURADOR")
{
    $cotizacionid = $_REQUEST["cotizacionid"];
    $coaseguradorid = $_REQUEST["coaseguradorid"];
    $tipo = $_REQUEST["tipo"];
    negCotizacion::saveParticipacionCoasegurador($cotizacionid,$coaseguradorid,$tipo);
    echo json_encode("OK");
}
if($acc=="SAVETIPOMATERIA")
{
    $cotizacionid = $_REQUEST["cotizacionid"];
    $materiaid = $_REQUEST["materiaid"];
    $tipo = $_REQUEST["tipo"];
    $ubicacionid = $_REQUEST["ubicacionid"];
    negCotizacion::saveTipoMateriaUbicacion($cotizacionid,$materiaid,$tipo,$ubicacionid);
    echo json_encode("OK");
    
}

if($acc=="DELETEUBICACIONCOTIZACION")
{
    $cotizacionid = $_REQUEST["cotizacionid"];
    $ubicacionid = $_REQUEST["ubicacionid"];
    negCotizacion::eliminaUbicacionCotizacion($cotizacionid,$ubicacionid);
    echo json_encode("OK");
}
if($acc=="SETHTMLATTRBYUBICACION")
{
    $cotizacionid = $_REQUEST["cotizacionid"];
    $ubicacionid = $_REQUEST["ubicacionid"];
    echo json_encode(negCotizacion::setHTMLAtributosByUbicacion($cotizacionid, $ubicacionid));
}
if(isset($_REQUEST["acc_ub"]))
{
    $acc = $_REQUEST["acc_ub"];
    
    if($acc=="SAVEATTRTOUBICACION")
    {
        $cotizacionid   = $_REQUEST["cotizacionidub"];
        $ubicacionid    = $_REQUEST["ubicacionid"];
        $attr           = $_REQUEST["attr"];
        $attrid         = $_REQUEST["attrid"];
        $tipo           = $_REQUEST["tipo"];
        negCotizacion::saveAttrToUbicacion($cotizacionid,$ubicacionid,$attr,$attrid,$tipo);
        echo json_encode("OK");
    }
    
}
if($acc=="GETSICCODEDETAIL")
{
    $siccodeid = $_REQUEST["siccodeid"];
    $sc = negSistema::getSicCodeDetail($siccodeid);
    $siccodem = $sc["familia_3"];
    echo json_encode($siccodem);
}
if($acc == "SAVEDEDUCIBLEFIJO")
{
    $cotizacionid       = $_REQUEST["cotizacionid"];
    $valor              = $_REQUEST["valor"];
    $deduciblefijoid    = $_REQUEST["deduciblefijoid"];
    negCotizacion::saveDeducibleFijoCotizacion($cotizacionid,$valor,$deduciblefijoid);
    echo json_encode("OK");
    
}
if($acc=="ELIMINACOBERTURAADICCONFIG")
{
    $sublimiteid = $_REQUEST["sublimiteid"];
    negCotizacion::eliminaCoberturaAdicionalConfig($sublimiteid);
    echo json_encode("OK");
}
if($acc=="CREACOBERTURAADICINALSUBLIMITE")
{
    $coberturaNombre = $_REQUEST["coberturaNombre"];
    $tipo = $_REQUEST["tipo"];
    negCotizacion::creaCoberturaSublimite($coberturaNombre,$tipo);
    echo json_encode("OK");
}

if($acc=="SAVETASAMATERIAADICSUBLIMITE")
{
    $sublimiteid = $_REQUEST["sublimiteid"];
    $tasa = $_REQUEST["tasa"];
    negCotizacion::saveMateriaAdicionalSubLimiteTasaNeta($sublimiteid,$tasa);
    echo json_encode("OK");
}
if($acc=="SAVETASABRUTAMATERIAADICSUBLIMITE")
{
    $sublimiteid = $_REQUEST["sublimiteid"];
    $tasa = $_REQUEST["tasa"];
    negCotizacion::saveMateriaAdicionalSubLimiteTasaBruta($sublimiteid,$tasa);
    echo json_encode("OK");
}
if($acc=="GETTASAMOTOR")
{
    $tipotasaid     = $_REQUEST["tipotasaid"];
    $nombre         = $_REQUEST["nombre"];
    $cotizacionid   = $_REQUEST["cotizacionid"];
    echo json_encode(number_format(negCotizacion::getTasaMotor($tipotasaid,$nombre,$cotizacionid),4,",",""));
}
if($acc=="SAVETASACALCULADA")
{
    $cotizacionid   = $_REQUEST["cotizacionid"];
    $tasaid         = $_REQUEST["tasaid"];
    $tasa           = $_REQUEST["tasa"];
    negCotizacion::saveTasaInput($cotizacionid,$tasaid,$tasa);
}
if($acc == "GETCOTIZACIONDETALLE")
{
    $cotizacionid= $_REQUEST["cotizacionid"];
    $cot = negCotizacion::getCotizacionDetail($cotizacionid);
    $cot["tasa_afecta"] = number_format($cot["tasa_afecta"],4,",","");
    $cot["tasa_excenta"] = number_format($cot["tasa_excenta"],4,",","");
    $cot["tasa_neta"] = number_format($cot["tasa_neta"],4,",","");
    echo json_encode($cot);
}
if($acc=="SAVETIPOTASACOTIZACION")
{
    $cotizacionid  = $_REQUEST["cotizacionid"];
    $tipotasa      = $_REQUEST["tipotasa"];
    negCotizacion::saveTipoTasaCotizacion($cotizacionid,$tipotasa);
}
if($acc=="GETCOTIZACIONTASAFIJAVERSION")
{
    $cotizacionid  = $_REQUEST["cotizacionid"];
    $cot = negCotizacion::getCotizacionTasaFijaVersion($cotizacionid);
    echo json_encode($cot);
}


?>

