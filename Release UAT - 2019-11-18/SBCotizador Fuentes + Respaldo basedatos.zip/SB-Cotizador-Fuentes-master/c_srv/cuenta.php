<?php 
error_reporting(E_ALL);
ini_set('display_errors', 1);


session_start();
include ('../c_negocio/negCuenta.php');
include ('../c_datos/dtCuenta.php');
include ('../c_datos/DBFactory.php');

include ('../c_negocio/negSistema.php');
include ('../c_datos/dtSistema.php');

include ('../c_negocio/negUsuario.php');
include ('../c_datos/dtUsuario.php');

include ('../c_sistema_util/util.php');


$acc = "";
if(isset($_REQUEST["acc"]))
{
	$acc = $_REQUEST["acc"];
}

if($acc == "VALIDAUSUARIO")
{
	$usuario		= $_REQUEST["usuario"];
	$clave			= $_REQUEST["clave"];
	
	$cuenta = negCuenta::validaUsuario($usuario, $clave);
	
	if(count($cuenta)>0)
	{
		echo json_encode("OK");
	}else
	{
		echo json_encode("ERROR - El usuario y/o clave ingresados no son correctos!!!");
		
	}
	
}

if($acc == "RECUPERACUENTA")
{
	$correo		= $_REQUEST["usuario"];
	echo json_encode(negCuenta::recuperaCuenta($correo));
	
}
if($acc == "RECUPERACLAVENUEVA")
{
	$usuarioid= $_REQUEST["usuarioid"];
	$clave= $_REQUEST["clave"];
	$valida_url = $_REQUEST["valida_url"];
	negCuenta::creaNuevaClaveusuario($usuarioid,$clave,$valida_url);
	echo json_encode("OK");
	
}

if($acc == "CREACUENTA")
{
	$usuario		= $_REQUEST["usuario"];
	$clave			= $_REQUEST["clave"];
	$correo			= $_REQUEST["correo"];
	$nombre			= $_REQUEST["nombre"];
	$tipo			= $_REQUEST["tipo"];
	$organizacion	= $_REQUEST["organizacion"];
	$correoV = negCuenta::validaCorreousuarioCrea($correo);
	
	if($correoV[0]["valida"] != "0")
	{
		echo json_encode("ERROR 1001- El correo ingresados ya existe como cuenta en nuestro sistema contactate con nosotros.");
	}else
	{
		//Correo No existe se debe validar solo que el nombre de la cuenta este disponible
		$cuenta = negCuenta::validaUsuarioCrea($usuario);
		if($cuenta[0]["valida"] != "0")
		{
			echo json_encode("ERROR 1002- El nombre de usuario ya existe en nuestro sistema por favor intentalo usando un nombre de usuario diferente.");
		}else
		{
			
			//se debe crear la cuenta
			negCuenta::creaCuenta($usuario,$clave,$correo,$nombre,$tipo,$organizacion);
			echo json_encode("OK");
		}
	}
	
	
	
	
}



?>

