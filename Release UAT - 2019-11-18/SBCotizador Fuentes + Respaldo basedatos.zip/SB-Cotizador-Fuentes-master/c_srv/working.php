<?php 
error_reporting(E_ALL);
ini_set('display_errors', 1);


session_start();
include ('../c_sistema_util/util.php');

include ('../c_negocio/negWorking.php');
include ('../c_datos/dtWorking.php');

include ('../c_negocio/negSistema.php');
include ('../c_datos/dtSistema.php');

include ('../c_datos/DBFactory.php');

if(isset($_REQUEST["qwerty"]))
{
	util::decodeParamURL($_REQUEST["qwerty"]);
}


$acc = "";
if(isset($_REQUEST["acc"]))
{
	$acc = $_REQUEST["acc"];
}
if($acc == "GUARDAITEM")
{
    $nombre_item = $_REQUEST["nombre_item"];
    negWorking::GuardaItem($nombre_item);
    echo json_encode("OK");
}
if($acc=="ELIMINAITEM")
{
    $idItem = $_REQUEST["idItem"];
     negWorking::EliminaItem($idItem);
     echo json_encode("OK");
}

if($acc == "GUARDAWORDING")
{
    $nombre_wording = $_REQUEST["nombre_wording"];
    $detalle_wording = $_REQUEST["detalleWor"];    
    $itemId= $_REQUEST["itemId"];
    
    negWorking::GuardaWording($nombre_wording,$detalle_wording,$itemId);
    echo json_encode("OK");
}

if($acc == "EDITAWORDING")
{
    $nombre_wording = $_REQUEST["nombre_wording"];
    $detalle_wording = $_REQUEST["detalle_wording_data"];
    $wordingId= $_REQUEST["wordingId"];
    
    negWorking::EditaWording($nombre_wording,$detalle_wording,$wordingId);
    echo json_encode("OK");
}
if($acc == "GUARDASECCIONES")
{
    $wordingId= $_REQUEST["wordingId"];
    if(isset($_REQUEST["seccion"]))
    {
        $secciones = $_REQUEST["seccion"];
    }
    
    negWorking::GuardaSecciones($wordingId,$secciones);
    echo json_encode("OK");
}
if($acc == "GETWORDINGDETAIL")
{
    $wordingId= $_REQUEST["wordingId"];
    echo json_encode(negWorking::getWordingDetail($wordingId));
}
if($acc == "EDITAITEM")
{
    $nombre_item = $_REQUEST["nombre_item"];
    $itemId= $_REQUEST["itemId"];
    
    negWorking::EditaItem($nombre_item,$itemId);
    echo json_encode("OK");
}
if($acc == "ADDTAGWORDING")
{
    $wordingId  = $_REQUEST["wordingId"];
    $nombre_tag = $_REQUEST["nombre_tag"];
    $tag        = $_REQUEST["tag"];
    
    negWorking::addTAG($wordingId,$nombre_tag,$tag);
    echo json_encode("OK");
}
if($acc == "ELIMINATAG")
{
    $tagid  = $_REQUEST["tagid"];
    
    negWorking::eliminaTAG($tagid);
    echo json_encode("OK");
}
if($acc == "ELIMINAWORDING")
{
    $wordingid  = $_REQUEST["wordingid"];
    
    negWorking::eliminaWording($wordingid);
    echo json_encode("OK");
}
?>

