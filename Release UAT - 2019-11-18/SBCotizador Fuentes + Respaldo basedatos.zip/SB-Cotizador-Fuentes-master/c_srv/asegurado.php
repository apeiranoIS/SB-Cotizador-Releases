<?php 
error_reporting(E_ALL);
ini_set('display_errors', 1);


session_start();
include ('../c_sistema_util/util.php');

include ('../c_negocio/negAsegurado.php');
include ('../c_datos/dtAsegurado.php');

include ('../c_negocio/negSistema.php');
include ('../c_datos/dtSistema.php');

include ('../c_datos/DBFactory.php');

if(isset($_REQUEST["qwerty"]))
{
	util::decodeParamURL($_REQUEST["qwerty"]);
}


$acc = "";
if(isset($_REQUEST["acc"]))
{
	$acc = $_REQUEST["acc"];
}



if($acc == "VALIDAASEGURADO")
{
	$rut 	= $_REQUEST["rut"];
	echo json_encode(negAsegurado::validaRutAsegurado($rut));
}

if($acc == "CREAASEGURADO")
{
    $rut 	= $_REQUEST["rut"];
    $nombre 	= $_REQUEST["nombre"];
    $apellidos 	= $_REQUEST["apellidos"];
    $giro 	= $_REQUEST["giro"];
    $grupo 	= $_REQUEST["grupo"];
    $mail 	= $_REQUEST["mail"];
    $telefono 	= $_REQUEST["telefono"];
    
    negAsegurado::creaAsegurado($rut,$nombre,$apellidos,$giro,$grupo,$mail,$telefono);
  
  
}


if($acc == "BUSCAASEGURADO")
{
    $rut 	     = $_REQUEST["rut"];
    $nombre 	 = $_REQUEST["nombre"];
    echo json_encode(negAsegurado::buscaAsegurado($rut,$nombre));
}
if($acc == "BUSCAASEGURADOINTERNO")
{
    
    $nombre  = $_REQUEST["nombre"];
    echo json_encode(negAsegurado::buscaAseguradoInterno($nombre));
}
if($acc == "GETASEGURADODETAIL")
{
    $aseguradoid = $_REQUEST["aseguradoid"];
    echo json_encode(negAsegurado::getAseguradoDetail($aseguradoid));
}
if($acc == "EXISTEASEGURADO"){
    $client_no = $_REQUEST["client_no"];
    echo json_encode(negAsegurado::getExisteAseguradoXidTI($client_no));
}
if($acc == "CREARASEGURADOINTEGRADO"){
    $id_ti = $_REQUEST["ID_TI"];
    $rut = $_REQUEST["rut"];
    $nombre = $_REQUEST["nombre"];
    $apellido = $_REQUEST["apellido"];
    $tipo_persona = $_REQUEST["tipo_persona"];
    $resp = negAsegurado::creaAseguradoIntegrado($id_ti,$rut,$nombre,$apellido,$tipo_persona);
    echo json_encode($resp);
}
if($acc == "EDITASEGURADOINTEGRADO"){
    $id_ti = $_REQUEST["ID_TI"];
    $rut = $_REQUEST["rut"];
    $nombre = $_REQUEST["nombre"];
    $apellido = $_REQUEST["apellido"];
    $tipo_persona = $_REQUEST["tipo_persona"];
    $resp = negAsegurado::editAseguradoIntegrado($id_ti,$rut,$nombre,$apellido,$tipo_persona);
    echo json_encode($resp);
}
if($acc == "GETASEGURADOLISTA")
{
    $cotiid = $_REQUEST["cotiid"];
    echo json_encode(negAsegurado::getAseguradosListaxId($cotiid));
}

if($acc == "GETASEGURADOAGREGA"){
    
    $aid = $_REQUEST["aseguradoid"];
    $cotiid = $_REQUEST["cotiid"];    
    negAsegurado::AddAseguradoCotizacion($aid,$cotiid);
    echo json_encode('OK');
}
if($acc == "GETEXISTEPARACOTI"){
    
    $cotiid = $_REQUEST["cotiid"];
    echo json_encode(negAsegurado::existeAseguradoCotizacion($cotiid));
}
if($acc=="ELIMINAASEGURADOCOTI")
{
    $aseguradoid = $_REQUEST["aseguradoid"];
    $cotiid = $_REQUEST["cotiid"];
    negAsegurado::eliminarAseguradoCoti($aseguradoid,$cotiid);
    echo json_encode("OK");
}
if($acc == "EXEINTEGRACION")
{
    $nombre = $_REQUEST["nombre"];
    $rut = $_REQUEST["rut"];    
    $url 	= negAsegurado::ConsultarAsegurado($nombre,$rut);
    echo json_encode($url);
    
    /*file_get_contents($url);*/
    
}

if($acc == "GETASEGURADODETAILBYCOTIZACION")
{
    $aseguradoid  = $_REQUEST["aseguradoid"];
    $cotizacionid = $_REQUEST["cotizacionid"]; 
    echo json_encode(negAsegurado::getAseguradoDetailByCotizacion($aseguradoid,$cotizacionid));
}
if($acc == "EXISTEASEGURADOENBASEDATOS"){
    $datoCliente = $_REQUEST["datoCliente"];
    echo json_encode(negAsegurado::validaClienteBaseDatos($datoCliente));
}
if($acc == "CREAASEGURADOINTEGRACION")
{
    $tipoCliente = $_REQUEST["tipoCliente"];
    $rut = $_REQUEST["rut"];
    $apellido = $_REQUEST["apellido"];
    $nombre = $_REQUEST["nombre"];
    $direccion = $_REQUEST["direccion"];
    $ciudad = $_REQUEST["ciudad"];
    $pais = $_REQUEST["pais"];
    $fecha_nacimiento = $_REQUEST["fecha_nacimiento"];
    $codigo_ocupacion = $_REQUEST["codigo_ocupacion"];
    $estadoCivil = $_REQUEST["estadoCivil"];
    $mail = $_REQUEST["mail"];
    $giro = $_REQUEST["giro"];
    $exento = $_REQUEST["exento"];
    $telefono = $_REQUEST["telefono"];
    $celular = $_REQUEST["celular"];
    
    
    negAsegurado::creaAseguradoIntegracion($tipoCliente,$rut,$nombre,$apellido,$giro,$direccion,$mail,$telefono,$ciudad,$pais,$fecha_nacimiento,$codigo_ocupacion,$estadoCivil,$exento,$celular);
    echo json_encode("OK");
    
}
?>

