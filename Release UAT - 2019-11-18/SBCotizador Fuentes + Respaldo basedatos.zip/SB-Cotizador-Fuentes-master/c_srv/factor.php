<?php
//error_reporting(E_ALL);
ini_set('display_errors', 1);


session_start();
include ('../c_sistema_util/util.php');

include ('../c_negocio/negFactor.php');
include ('../c_datos/dtFactor.php');

include ('../c_negocio/negSistema.php');
include ('../c_datos/dtSistema.php');

include ('../c_datos/DBFactory.php');

if(isset($_REQUEST["qwerty"]))
{
    util::decodeParamURL($_REQUEST["qwerty"]);
}


$acc = "";
if(isset($_REQUEST["acc"]))
{
    $acc = $_REQUEST["acc"];
}



if($acc == "CREAFACTOR")
{
    $nombre = $_REQUEST["nombre_factor"];
    $tipo_tasa   = $_REQUEST["tipo_tasa"];
    $tipo   = $_REQUEST["tipo"];
    negFactor::CreaFactor($nombre,$tipo_tasa,$tipo);
    echo json_encode("OK");
}
if($acc == "ELIMINAFACTOR")
{
    $factorid 	     = $_REQUEST["factorid"];
    negFactor::EliminarFactor($factorid);
    echo json_encode("OK");
}
if($acc == "MODIFICAFACTOR")
{
    $factorid 	     = $_REQUEST["factorid"];
    $nombre = $_REQUEST["nombre_factor"];
    $tipo_tasa   = $_REQUEST["tipo_tasa"];
    $tipo   = $_REQUEST["tipo"];
    negFactor::ModificaFactor($factorid,$nombre,$tipo_tasa,$tipo);
    echo json_encode("OK");
}
if($acc == "AGREGARVALORES")
{
    $factorid       = $_REQUEST["factorid"];
    $valor_muestra_1 = $_REQUEST["valor_muestra_1"];
    $valor_muestra_2 = $_REQUEST["valor_muestra_2"];
    $valor_compara_1 = $_REQUEST["valor_compara_1"];
    $valor_compara_2 = $_REQUEST["valor_compara_2"];
    $factor          = $_REQUEST["factor"];
    $tipo_factor     = $_REQUEST["tipo_factor"];
    $valor_compara_ad_1 = $_REQUEST["valor_compara_ad_1"];
    $valor_compara_ad_2 = $_REQUEST["valor_compara_ad_2"];
    negFactor::AgregarValores($factorid,$valor_muestra_1,$valor_muestra_2,$valor_compara_1,$valor_compara_2,$factor,$tipo_factor,$valor_compara_ad_1,$valor_compara_ad_2);
    echo json_encode("OK");
}
if($acc == "GETVALORESXFACTOR")
{
    $factorid       = $_REQUEST["factorid"];
    echo json_encode(negFactor::GetValoresXFactor($factorid));
}
if($acc == "ELIMINAVALORFACTOR")
{
    $factorvalorid       = $_REQUEST["factorvalorid"];
    negFactor::EliminaValorFactor($factorvalorid);
    echo json_encode("OK");
}
?>

