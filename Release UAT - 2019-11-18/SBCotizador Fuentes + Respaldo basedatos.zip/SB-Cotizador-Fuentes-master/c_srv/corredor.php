<?php 
error_reporting(E_ALL);
ini_set('display_errors', 1);


session_start();
include ('../c_sistema_util/util.php');

include ('../c_negocio/negCorredor.php');
include ('../c_datos/dtCorredor.php');

include ('../c_negocio/negSistema.php');
include ('../c_datos/dtSistema.php');

include ('../c_datos/DBFactory.php');

if(isset($_REQUEST["qwerty"]))
{
	util::decodeParamURL($_REQUEST["qwerty"]);
}


$acc = "";
if(isset($_REQUEST["acc"]))
{
	$acc = $_REQUEST["acc"];
}



if($acc == "BUSCACORREDOR")
{
	$rut 	     = $_REQUEST["rut"];
	$nombre 	 = $_REQUEST["nombre"];
	echo json_encode(negCorredor::buscaCorredor($rut,$nombre));
}
if($acc == "BUSCACORREDORINTERNO"){
    
    $nombre 	 = $_REQUEST["nombre"];
    echo json_encode(negCorredor::buscaCorredorInterno($nombre));
}
if($acc == "GETCORREDORDETAIL")
{
    $corredorid = $_REQUEST["corrid"];
    echo json_encode(negCorredor::getCorredorDetail($corredorid));
}

if($acc == "EXISTECORREDOR"){
    $client_no = $_REQUEST["client_no"];
    echo json_encode(negCorredor::getExisteCorredorXidTI($client_no));
}
if($acc == "EXISTECORREDORNOMBRECOMPLETO"){
    $nombreCompleto = $_REQUEST["nombreCompleto"];
    echo json_encode(negCorredor::getExisteCorredorXNombreCompleto($nombreCompleto));
}
if($acc == "CREARCORREDORINTEGRADO"){
    //$id_ti = $_REQUEST["ID_TI"];
    $rut = $_REQUEST["rut"];
    $nombre = $_REQUEST["nombre"];
    //$apellido = $_REQUEST["apellido"];
    //$tipo_persona = $_REQUEST["tipo_persona"];
    $resp = negCorredor::creaCorredorIntegrado($rut,$nombre);
    echo json_encode($resp);
}
if($acc == "EDITACORREDORINTEGRADO"){
   // $id_ti = $_REQUEST["ID_TI"];
    $rut = $_REQUEST["rut"];
    $nombre = $_REQUEST["nombre"];
    //$apellido = $_REQUEST["apellido"];
    //$tipo_persona = $_REQUEST["tipo_persona"];
    $resp = negCorredor::editCorredorIntegrado($rut,$nombre);
    echo json_encode($resp);
}
if($acc == "EXEINTEGRACION")
{
    $url 	= negCorredor::ConsultarCorredor();
    echo json_encode($url);
    
    /*file_get_contents($url);*/
}
if($acc == "BUSCACORREDORINTERNOBD"){
    
    $valor = $_REQUEST["nombreCompleto"];
    $resp = negCorredor::buscaCorredorEnBaseDatos($valor);
    echo json_encode($resp);
}

?>

