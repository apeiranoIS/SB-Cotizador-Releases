<?php 

error_reporting(E_ALL);
ini_set('display_errors', 1);


session_start();
include ('../c_sistema_util/util.php');

include ('../c_negocio/negMateria.php');
include ('../c_datos/dtMateria.php');

include ('../c_negocio/negCobertura.php');
include ('../c_datos/dtCobertura.php');

include ('../c_negocio/negSistema.php');
include ('../c_datos/dtSistema.php');

include ('../c_datos/DBFactory.php');

if(isset($_REQUEST["qwerty"]))
{
	util::decodeParamURL($_REQUEST["qwerty"]);
}


$acc = "";
if(isset($_REQUEST["acc"]))
{
	$acc = $_REQUEST["acc"];
}


if($acc == "EXEINTEGRACIONMATERIA")
{
    negMateria::ConsultarMateria();
    echo json_encode("OK");
    
}

if($acc == "GETMATERIAS")
{
    echo json_encode(negMateria::getMaterias());
}

if($acc == "GETMATERIASXID")
{
    $materiaid = $_REQUEST["materiaid"];
    $selectMateria = negMateria::getMateriaPorIdMateria($materiaid);
    echo json_encode($selectMateria);
}

if($acc == "GETMATERIASDISPONIBLESBYUBICACION")
{
    $ubicacionid = $_REQUEST["ubicacionid"];
    $cotizacionid = $_REQUEST["cotizacionid"];
    $selectMateria = negMateria::getMateriasDisponiblesByUbicacion($ubicacionid,$cotizacionid);
    echo json_encode($selectMateria);
}
if($acc == "GETMATERIASDISPONIBLESBYLINEANEGOCIO")
{
    $lineanegociocomercialid = $_REQUEST["lineanegociocomercialid"];
    $selectMateria = negMateria::getMateriasDisponiblesByLineaNegocioComercial($lineanegociocomercialid);
    echo json_encode($selectMateria);
}
if($acc == "GETMATERIASBYLINEANEGOCIO")
{
    $lineanegociocomercialid = $_REQUEST["lineanegociocomercialid"];
    echo json_encode(negMateria::getMateriasByLineaNegocioComercial($lineanegociocomercialid));
}
if($acc == "ADDMATERIATOLINEANEGOCIOCOMERCIAL")
{
    $lineanegociocomercialid = $_REQUEST["lineanegociocomercialid"];
    $materiaid               = $_REQUEST["materiaid"];
    echo json_encode(negMateria::addMateriasByLineaNegocioComercial($lineanegociocomercialid,$materiaid));
}
if($acc == "DELETEMATERIASBYLINEANEGOCIO")
{
    $lineanegociocomercialid = $_REQUEST["lineanegociocomercialid"];
    $materiaid               = $_REQUEST["materiaid"];
    echo json_encode(negMateria::deleteMateriasByLineaNegocioComercial($lineanegociocomercialid,$materiaid));
}
if($acc == "GETMATERIASDISPONIBLESBYTEMPLATE")
{
    $wordingid = $_REQUEST["wordingid"];
    $selectMateria = negMateria::getMateriasDisponiblesByWording($wordingid);
    echo json_encode($selectMateria);
}
if($acc == "GETMATERIASBYTEMPLATE")
{
    $wordingid = $_REQUEST["wordingid"];
    $selectMateria = negMateria::getMateriasByWording($wordingid);
    echo json_encode($selectMateria);
}

if($acc == "ADDMATERIATOTEMPLATE")
{
    $wordingid = $_REQUEST["wordingid"];
    $materiaid = $_REQUEST["materiaid"];
    $selectMateria = negMateria::addMateriasToByWording($wordingid,$materiaid);
    echo json_encode("OK");
}
if($acc == "DELETEMATERIATOTEMPLATE")
{
    $wordingid = $_REQUEST["wordingid"];
    $materiaid = $_REQUEST["materiaid"];
    $selectMateria = negMateria::deleteMateriasToByWording($wordingid,$materiaid);
    echo json_encode("OK");
}



?>
