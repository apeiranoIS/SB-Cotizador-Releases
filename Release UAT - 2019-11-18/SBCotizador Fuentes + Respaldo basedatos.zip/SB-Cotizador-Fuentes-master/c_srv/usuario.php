<?php 
error_reporting(E_ALL);
ini_set('display_errors', 1);


session_start();
include ('../c_sistema_util/util.php');

include ('../c_negocio/negUsuario.php');
include ('../c_datos/dtUsuario.php');

include ('../c_negocio/negSistema.php');
include ('../c_datos/dtSistema.php');

include ('../c_datos/DBFactory.php');

if(isset($_REQUEST["qwerty"]))
{
	util::decodeParamURL($_REQUEST["qwerty"]);
}


$acc = "";
if(isset($_REQUEST["acc"]))
{
	$acc = $_REQUEST["acc"];
}

if($acc == "VALIDAUSUARIO")
{
	$ususario_mae = $_REQUEST["ususario_mae"];
	$clave_mae = $_REQUEST["clave_mae"];
	echo json_encode(negUsuario::validaDisponibilidadUsarioMae($ususario_mae,$clave_mae));
	
}

if($acc=="CAMBIAIMAGEN")
{
	$usuarioid = $_REQUEST["usuarioid_img"];
	$hoy= date("dmY[His]_");
	$nameFile = $_FILES["imagen"]['name'];
	$tmpFile = $_FILES["imagen"]['tmp_name'];
	if ($tmpFile != ""){
		
		$avataridPath= '../c_archivos/usuarios/'.$hoy.$nameFile;
		move_uploaded_file($tmpFile,$avataridPath);
		negUsuario::modificaImagen($usuarioid,$avataridPath);
	}
	echo json_encode("OK");
	
}
if($acc=="DESHABILITAUSUARIO")
{
	$usuarioid= $_REQUEST["usuarioid"];
	negUsuario::desHabilitaUsuario($usuarioid);
	echo json_encode("OK");
}
if($acc=="ELIMINAUSUARIO")
{
	$usuarioid= $_REQUEST["usuarioid"];
	negUsuario::eliminarUsuario($usuarioid);
	echo json_encode("OK");
}

if($acc=="CREAUSUARIO")
{
	
	$nombre= $_REQUEST["nombre"];
	$apellidos= $_REQUEST["apellidos"];
	$mail= $_REQUEST["mail"];
	$telefono= $_REQUEST["telefono"];
	$ususario_mae= $_REQUEST["ususario_mae"];
	$clave= $_REQUEST["clave"];
	$perfil = $_REQUEST["perfil"];
	$avataridPath = "";
	
	$hoy= date("dmY[His]_");
	$nameFile = $_FILES["imagen"]['name'];
	$tmpFile = $_FILES["imagen"]['tmp_name'];
	if ($tmpFile != ""){
	
		$avataridPath= '../c_archivos/usuarios/'.$hoy.$nameFile;
		move_uploaded_file($tmpFile,$avataridPath);
	}
	
	negUsuario::creaUsuario($nombre,$apellidos,$mail,$telefono,$ususario_mae,$clave,$perfil,$avataridPath);
	echo json_encode("OK");
	
	
}

if($acc=="MODIFICAUSUARIO")
{
	
	$nombre= $_REQUEST["nombre"];
	$apellidos= $_REQUEST["apellidos"];
	$mail= $_REQUEST["mail"];
	$telefono= $_REQUEST["telefono"];
	$ususario_mae= $_REQUEST["ususario_mae"];
	$clave= $_REQUEST["clave"];
	$perfil = $_REQUEST["perfil"];
	$estado = $_REQUEST["estado"];
	$usuarioid= $_REQUEST["usuarioid"];
	

	negUsuario::modificaaUsuario($nombre,$apellidos,$mail,$telefono,$ususario_mae,$clave,$perfil,$usuarioid,$estado);
	echo json_encode("OK");
	
	
}

if($acc=="MODIFICAUSUARIOPERSONAL")
{
    
    $nombre= $_REQUEST["nombre"];
    $apellidos= $_REQUEST["apellidos"];
    $mail= $_REQUEST["mail"];
    $telefono= $_REQUEST["telefono"];
    $ususario_mae= $_REQUEST["ususario_mae"];
    $clave= $_REQUEST["clave"];
    $estado = $_REQUEST["estado"];
    $usuarioid= $_REQUEST["usuarioid"];
    
    
    negUsuario::modificaUsuarioPersonal($nombre,$apellidos,$mail,$telefono,$ususario_mae,$clave,$usuarioid,$estado);
    echo json_encode("OK");
    
    
}
if($acc == "GETUSUARIOS"){
    echo json_encode(negUsuario::getUsuarios());
}




?>

