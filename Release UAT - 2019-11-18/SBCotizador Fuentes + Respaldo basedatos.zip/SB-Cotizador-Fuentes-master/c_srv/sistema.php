<?php 
error_reporting(E_ALL);
ini_set('display_errors', 1);


session_start();
include ('../c_sistema_util/util.php');

include ('../c_negocio/negSistema.php');
include ('../c_datos/dtSistema.php');
include ('../c_negocio/negCotizacion.php');
include ('../c_datos/dtAsegurado.php');
include ('../c_datos/dtCorredor.php');

include ('../c_datos/DBFactory.php');

if(isset($_REQUEST["qwerty"]))
{
	util::decodeParamURL($_REQUEST["qwerty"]);
}


$acc = "";
if(isset($_REQUEST["acc"]))
{
	$acc = $_REQUEST["acc"];
}

if($acc == "GETCOMUNADETAIL")
{
	$id_comuna 	= $_REQUEST["id_comuna"];
	echo json_encode(negSistema::getComunasAllDetalleByComuna($id_comuna));
}

if($acc == "GETSICCODEDETAIL")
{
    $siccodeid 	= $_REQUEST["siccodeid"];
    echo json_encode(negSistema::getSicCodeDetail($siccodeid));
}


if($acc == "TESTBD")
{
    echo "ENTRO <hr/>";
    
    DBFactory::ExecuteNonQuery("insert into [sb_cotizador].[dbo].[usuario]([nombre]) VALUES('usr_2') ");
    
    echo(DBFactory::ExecuteNonQueryReturnId("insert into [sb_cotizador].[dbo].[usuario]([nombre]) OUTPUT INSERTED.usuarioid  VALUES('usr_2') ","usuarioid"));
    
    $usr = DBFactory::ExecuteSQL("select * from [sb_cotizador].[dbo].[usuario];");
    echo "SALIDA <hr/>";
    
    echo json_encode($usr);
    
    echo "-->".$usr[0]["usuarioid"]."<--";
    
    foreach ($usr as $u)
    {
        echo "-->".$u["nombre"]."<--";
    }
    
    $usr = DBFactory::ExecuteSQLFirst("select * from [sb_cotizador].[dbo].[usuario];");
    
    echo "-->".$usr["nombre"]."<--";
}

if($acc == "EXEINTEGRACIONCLIENTE")
{
    $rut 	= $_REQUEST["rut"];
    $nombre 	= $_REQUEST["nombre"];
    $url = negCotizacion::getUrlIntegracionCliente($nombre,$rut);
    
    $datosURL =  file_get_contents($url["url"]);
    $datosSB = json_decode($datosURL,false);
   
    echo json_encode($datosSB);
      
}
if($acc == "EXEINTEGRACIONCORREDOR")
{
    $rut 	= $_REQUEST["rut"];
    $nombre 	= $_REQUEST["nombre"];
    $url = negCotizacion::getUrlIntegracionCorredor($nombre,$rut);
   
    echo file_get_contents($url["url"]);
    
}


?>

