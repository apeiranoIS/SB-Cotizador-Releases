<?php 

error_reporting(E_ALL);
ini_set('display_errors', 1);


session_start();
include ('../c_sistema_util/util.php');

include ('../c_negocio/negLineaNegocio.php');
include ('../c_datos/dtLineaNegocio.php');

include ('../c_negocio/negProducto.php');
include ('../c_datos/dtProducto.php');

include ('../c_negocio/negSistema.php');
include ('../c_datos/dtSistema.php');

include ('../c_datos/DBFactory.php');

if(isset($_REQUEST["qwerty"]))
{
	util::decodeParamURL($_REQUEST["qwerty"]);
}


$acc = "";
if(isset($_REQUEST["acc"]))
{
	$acc = $_REQUEST["acc"];
}
if($acc == "EXEINTEGRACION")
{
    $url = negLineaNegocio::Consultarln();
    echo json_encode($url);
    
}

if($acc == "CREALINEANEGOCIOCOMERCIAL")
{
    $nombre_lnc = $_REQUEST["nombre_ln_comercial"];
    $usuarioid = $_SESSION["IGT-usuarioid"];
    
    negLineaNegocio::CreaLineaNegocioComercial($nombre_lnc,$usuarioid);
    
    echo json_encode("OK");
}
if($acc == "ASIGNAPRODUCTOLINEANEGOCIOCOMERCIAL")
{
    
    $lnc_comecialid = $_REQUEST["lineanegociocomercialid"];
    //$productoid = $_REQUEST["productoid"];
    if(isset($_REQUEST["producto"]))
    {
        $productos = $_REQUEST["producto"];
        
    }        
    negLineaNegocio::guardaProductoLineaNegocioComercial($lnc_comecialid, $productos);
    
    echo json_encode("OK");
}
if($acc == "MODIFICALINEANEGOCIOCOMERCIAL")
{
    $lnc_comecialid = $_REQUEST["lineanegociocomercialid"];
    $nuevo_nombre_lnc = $_REQUEST["nuevo_nombre"];
    
    negLineaNegocio::guardaNuevoNombreLnc($lnc_comecialid, $nuevo_nombre_lnc);    
    echo json_encode("OK");
}
if($acc == "LISTAPRODUCTOSASOCIADOS")
{
    $lnc_comecialid = $_REQUEST["lineanegociocomercialid"];
    
    echo json_encode(negLineaNegocio::getProductoLineanegocioComercial($lnc_comecialid));
}
if($acc == "GETPRODUCTOSVALIDA")
{        
    $lnc_comecialid = $_REQUEST["lineanegociocomercialid"];
    echo json_encode(negProducto::getProductosLineaComercialValida($lnc_comecialid));
}
if($acc == "ELIMINAPRODUCTOLNC")
{
    $lnc_comecialid = $_REQUEST["lineanegociocomercialid"];
    $productoid = $_REQUEST["productoid"];
    dtLineaNegocio::eliminaProductoLNC($lnc_comecialid, $productoid);
    echo json_encode("OK");
}
if($acc == "ELIMINALNC")
{
    $lnc_comecialid = $_REQUEST["lineanegociocomercialid"];
    
    negLineaNegocio::eliminaLNC($lnc_comecialid);
    echo json_encode("OK");
}
if($acc=="GETPRODDISPBYLINEACOMERCIAL")
{
    $lnc_comecialid = $_REQUEST["lineanegociocomercialid"];
    echo json_encode(negLineaNegocio::productosByLineaNegocioDisp($lnc_comecialid));
}

if($acc=="GETPRODBYLINEACOMERCIAL")
{
    $lnc_comecialid = $_REQUEST["lineanegociocomercialid"];
    echo json_encode(negLineaNegocio::getProductoLineanegocioComercial($lnc_comecialid));
}
if($acc=="ADDPRODUCTOTOLINEA")
{
    $lineanegociocomercialid = $_REQUEST["lineanegociocomercialid"];
    $productoid              = $_REQUEST["productoid"];
    
    dtLineaNegocio::guardaProductoLineaNegocioComercial($lineanegociocomercialid,$productoid);
}
if($acc=="GETUSUARIODISPBYLINEACOMERCIAL")
{
    $lnc_comecialid = $_REQUEST["lineanegociocomercialid"];
    echo json_encode(negLineaNegocio::getUsuariosByLineaNegocioComercial($lnc_comecialid));
}
if($acc=="GETPUSUARIOBYLINEACOMERCIAL")
{
    $lnc_comecialid = $_REQUEST["lineanegociocomercialid"];
    echo json_encode(negLineaNegocio::getUsuariosByLineaNegocioComercialConfig($lnc_comecialid));
}
if($acc=="ADDUSUARIOTOLINEA")
{
    $lnc_comecialid = $_REQUEST["lineanegociocomercialid"];
    $usuarioid = $_REQUEST["usuarioid"];
    echo json_encode(negLineaNegocio::addUsuariosToLineaNegocioComercialConfig($lnc_comecialid,$usuarioid));
}
if($acc=="ELIMINAUSUARIOLNC")
{
    $lnc_comecialid = $_REQUEST["lineanegociocomercialid"];
    $usuarioid = $_REQUEST["usuarioid"];
    echo json_encode(negLineaNegocio::elimnaUsuariosToLineaNegocioComercialConfig($lnc_comecialid,$usuarioid));
}
if($acc == "GETFACTORESOBYLINEACOMERCIAL")
{
    $lnc_comecialid = $_REQUEST["lineanegociocomercialid"];
    echo json_encode(negLineaNegocio::getFactoresNegocioByLineaComercial($lnc_comecialid));
}
if($acc == "GETFACTORESDISBYLINEANEGCOMERCIAL")
{
    $lnc_comecialid = $_REQUEST["lineanegociocomercialid"];
    echo json_encode(negLineaNegocio::getFactoresDisponiblesNegocioByLineaComercial($lnc_comecialid));
}
if($acc == "ADDFACTORTOLINEA")
{
    $lnc_comecialid = $_REQUEST["lineanegociocomercialid"];
    $factorid = $_REQUEST["factorid"];
    echo json_encode(negLineaNegocio::addFactoresNegocioByLineaComercial($lnc_comecialid,$factorid));
}
if($acc == "ELIMINAFACTORLNC")
{
    $lnc_comecialid = $_REQUEST["lineanegociocomercialid"];
    $factorid = $_REQUEST["factorid"];
    echo json_encode(negLineaNegocio::eliminaFactoresNegocioByLineaComercial($lnc_comecialid,$factorid));
}
if($acc=="GETTASASMONTOSXLINEA")
{
    $lnc_comecialid = $_REQUEST["lineanegociocomercialid"];
    echo json_encode(negLineaNegocio::GetTasasMontoxLinea($lnc_comecialid));
}
if($acc=="ELIMINATASAMONTO")
{
    $lnc_comecialid = $_REQUEST["lineanegociocomercialid"];
    $tipo_monto = $_REQUEST["tipo_monto"];
    $tipo_tasa = $_REQUEST["tipo_tasa"];
    negLineaNegocio::EliminaMontoTasa($lnc_comecialid,$tipo_monto,$tipo_tasa);
    echo json_encode("OK");
}
if($acc=="AGREGARTIPOMONTOTASA")
{
    $lnc_comecialid = $_REQUEST["lineanegociocomercialid"];
    $tipo_monto = $_REQUEST["tipo_monto"];
    $tipo_tasa = $_REQUEST["tipo_tasa"];
    negLineaNegocio::AgregarTipoMontoTasa($lnc_comecialid,$tipo_monto,$tipo_tasa);
    echo json_encode("OK");
}
if($acc=="GETMATERIASDISPXLN")
{
    $lnc_comecialid = $_REQUEST["lineanegociocomercialid"];
    echo json_encode(negLineaNegocio::GetMateriasDisponiblesxLN($lnc_comecialid));
}
if($acc=="ADDMATERIATIPOMT")
{
    $lnc_comecialid = $_REQUEST["lineanegociocomercialid"];
    $tipo = $_REQUEST["tipo"];
    $tipo_monto = $_REQUEST["tipo_monto"];
    $tipo_tasa = $_REQUEST["tipo_tasa"];
    $materiaid = $_REQUEST["materiaid"];
    negLineaNegocio::addMateriaTipoMT($lnc_comecialid,$tipo,$tipo_monto,$tipo_tasa,$materiaid);
    echo json_encode("OK");
}
if($acc=="ELIMINARMATERIAMT")
{
    $lnc_comecialid = $_REQUEST["lineanegociocomercialid"];
    $tipo_monto = $_REQUEST["tipo_monto"];
    $tipo_tasa = $_REQUEST["tipo_tasa"];
    $materiaid = $_REQUEST["materiaid"];
    negLineaNegocio::EliminarMateriaTipoMT($lnc_comecialid,$tipo_monto,$tipo_tasa,$materiaid);
    echo json_encode("OK");
}





?>