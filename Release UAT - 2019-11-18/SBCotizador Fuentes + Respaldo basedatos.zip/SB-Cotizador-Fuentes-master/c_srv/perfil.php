<?php 
error_reporting(E_ALL);
ini_set('display_errors', 1);


session_start();
include ('../c_sistema_util/util.php');

include ('../c_negocio/negPerfil.php');
include ('../c_datos/dtPerfil.php');

include ('../c_negocio/negSistema.php');
include ('../c_datos/dtSistema.php');

include ('../c_datos/DBFactory.php');

if(isset($_REQUEST["qwerty"]))
{
	util::decodeParamURL($_REQUEST["qwerty"]);
}


$acc = "";
if(isset($_REQUEST["acc"]))
{
	$acc = $_REQUEST["acc"];
}



if($acc == "CREAPERFIL")
{
	$descripcion 	= $_REQUEST["descripcion_perfil"];
	$nombre			= $_REQUEST["nombre_perfil"];
	$apps 			= "";
	
	if(isset($_REQUEST["apps"]))
	{
		$apps = $_REQUEST["apps"];
	}
	negPerfil::creaPerfil(strtoupper($nombre),$descripcion,$apps);
	echo json_encode("OK");
	
	
}

if($acc == "EDITAPERFIL")
{
	$descripcion 	= $_REQUEST["descripcion_perfil"];
	$nombre			= $_REQUEST["nombre_perfil"];
	$apps 			= "";
	$perfilid		= $_REQUEST["perfilid"];
	
	if(isset($_REQUEST["apps"]))
	{
		$apps = $_REQUEST["apps"];
	}
	negPerfil::editaPerfil(strtoupper($nombre),$descripcion,$apps,$perfilid);
	echo json_encode("OK");
	
	
}

if($acc == "VALIDAELIMINACIONPERFIL")
{
	$perfilid = $_REQUEST["perfilid"];
	$usuariosPerfil = negPerfil::getUsuariosByPerfil($perfilid);
	if(count($usuariosPerfil)>0)
	{
		echo json_encode("NOK");
	}else
	{
		echo json_encode("OK");
	}
	
}


if($acc == "ELIMINAPERFIL")
{
	$perfilid = $_REQUEST["perfilid"];
	negPerfil::eliminaPerfil($perfilid);
	echo json_encode("OK");
	
}

if($acc == "DESHABILITAPERFIL"){
    
    $perfilid = $_REQUEST["perfilid"];
    negPerfil::deshabilitarPerfil($perfilid);
    echo json_encode("OK");
}

if($acc == "HABILITAPERFIL"){
    
    $perfilid = $_REQUEST["perfilid"];
    negPerfil::habilitarPerfil($perfilid);
    echo json_encode("OK");
    
}

?>

