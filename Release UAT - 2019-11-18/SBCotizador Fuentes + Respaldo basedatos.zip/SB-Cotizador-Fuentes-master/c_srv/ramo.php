<?php 

error_reporting(E_ALL);
ini_set('display_errors', 1);


session_start();
include ('../c_sistema_util/util.php');

include ('../c_negocio/negRamo.php');
include ('../c_datos/dtRamo.php');

include ('../c_negocio/negCobertura.php');
include ('../c_datos/dtCobertura.php');

include ('../c_negocio/negSistema.php');
include ('../c_datos/dtSistema.php');

include ('../c_negocio/negMateria.php');
include ('../c_datos/dtMateria.php');

include ('../c_datos/DBFactory.php');

if(isset($_REQUEST["qwerty"]))
{
	util::decodeParamURL($_REQUEST["qwerty"]);
}


$acc = "";
if(isset($_REQUEST["acc"]))
{
	$acc = $_REQUEST["acc"];
}

if($acc=="GETRAMOPRODUCTO")
{
	$productoid = $_REQUEST["productoid"];
	
	$ramo = negRamo::getRamoPorProducto($productoid);
	echo json_encode($ramo);
	
	
}
if($acc == "EXEINTEGRACION")
{
    $url 	= negRamo::ConsultarRamo();
    echo json_encode($url);
    
}
if($acc == "EXEINTEGRACIONMATERIA")
{
    $url 	= negMateria::ConsultarMateria();
    echo json_encode($url);
    
}
if($acc == "EXEINTEGRACIONCOBERTURA")
{
    $url 	= negCobertura::ConsultarCobertura();
    echo json_encode($url);
    
}


?>
