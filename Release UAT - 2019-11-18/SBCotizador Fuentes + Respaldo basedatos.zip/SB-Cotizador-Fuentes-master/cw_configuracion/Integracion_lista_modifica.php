<?php 

$urls = negIntegracion::getIntegracionUrl();

?>
<div class="row">
	<div class="col-md-12">
		<h1>Url Integracion</h1>
	</div>
</div>
<div class="row mb-4">
	<div class="col-md-12">
		<div class="card">
			<div class="card-header">
				
			</div>
			<div class="card-body">
				<table id="dataTables-UrlIntegracionLista" class="table table-bordered">
													<thead class="thead-light">
														<tr>
															<th>Integracion</th>
															<th>URL</th>
															<th style="text-align: center;">Acciones</th>
														</tr>
													</thead>
													<?php 
													if(count($urls)>0)
														{
														   
														   echo '<tbody>';
														   foreach ($urls as $u)
															{ 
															    $Nombre = substr($u["integracion"],4);
																echo '
																		<tr>
                                                                            <td style="text-align: left;"><h5><strong>'.$Nombre.'</strong></h5></td>
                                                                            <td style="text-align: center;">
																					<input type="text" class="form-control" id="url_'.$u["integracion"].'" name="url"  value="'.$u["url"].'"></td>
																			<td style="text-align: center;">
																					<button type="button" class="btn btn-primary btn-sm waves-effect waves-light" onclick="EditarUrl(\''.$u["integracion"].'\')" >Editar</button>';
																															
																echo'
																			</td>
																			
																		</tr>';
																
															}
															echo '</tbody>';
														}
													
													
													?>
													
												</table>
			</div>
		</div>
	</div>
</div>
<div class="modal fade" id="modal_elimina_materia" tabindex="-1" role="dialog" aria-labelledby="modal_elimina_materiaLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Eliminar Materia</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body" id="modal_cp_bdy">
				
				Esta seguro que quiere eliminar esta materia
				
			</div>
			<div class="modal-footer" id="modal_cp_fter">
				<button type="button" class="btn btn-secondary btn-sm waves-effect waves-light" data-dismiss="modal">Entendido</button>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
function ConsultarMaterias()
{
	urlIn = "../c_srv/materia.php";
	dataIn = "acc=EXEINTEGRACIONMATERIA";
	srv="EXEINTEGRACIONMATERIA";
	msjError = "No pudimos realizar lo solicitado";
	sal = getDataJson(urlIn,dataIn,srv,msjError);	
	
}
function EditarUrl(claveIntegracion)
{

	urlIn = "../c_srv/integracion.php";
	dataIn = "acc=EDITAURL&claveIntegracion="+claveIntegracion+"&nuevaUrl="+$("#url_"+claveIntegracion).val();
	srv="EDITAURL";
	msjError = "No pudimos realizar lo solicitado";
	sal = getDataJson(urlIn,dataIn,srv,msjError);	
	
}
</script>

<script>
    $(document).ready(function() {
    	    	
        $('#dataTables-UrlIntegracionLista').DataTable({
            responsive: true,
            "language": {
                "lengthMenu": "Mostrando _MENU_",
                "zeroRecords": "No se han encontrados registros",
                "info": "Mostrando página _PAGE_ de _PAGES_",
                "infoEmpty": "No se han encontrados registros",
                "search": "Busqueda",
                "infoFiltered": "(Filtro de _MAX_ registros totales)",
                "paginate": {
                	"previous": "Anterior",
                	"next": "Siguiente",
                	"first":    "Primero",
                    "last":    "Último"
                  }
                
            }
        });
    });

   
    </script>

				