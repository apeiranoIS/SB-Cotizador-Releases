<?php 

$asegurados = negAsegurado::getAsegurados();


?>
<div class="row">
	<div class="col-md-12">
		<h1>Asegurados</h1>
	</div>
</div>
<div class="row mb-4">
	<div class="col-md-12">
		<div class="card">
			<div class="card-header">
				<button type="button" class="btn btn-primary btn-gradient waves-effect waves-light" onclick="goCreaPerfil('<?php echo util::creaURLApp(1, "conf_asegurado_crea");?>')">
					<span class="gradient">
						<i class="batch-icon batch-icon-add"></i>
						Crear nuevo Asegurado
					</span>
				</button>
			</div>
			<div class="card-body">
				<table id="dataTables-ListaAsegurados" class="table table-bordered">
													<thead class="thead-light">
														<tr>
															<th>Asegurado</th>
															<th>RUT</th>
															<th>Giro</th>
															<th>Grupo</th>
															<th style="text-align: center;">Acciones</th>
														</tr>
													</thead>
													<?php 
													if(count($asegurados)>0)
														{
															echo '<tbody>';
															foreach ($asegurados as $p)
															{
																$ELIMNA_URL = util::encodeParamURL('acc=ELIMINAASEGURADO&aseguradoid='.$p["aseguradoid"]);
																echo '
																		<tr>
																			<td>'.$p["nombre"].' '.$p["apellido"].'</td>
																			<td>'.$p["rut"].'</td>
                                                                            <td>'.$p["giro"].'</td>
																			<td>'.$p["grupo"].'</td>
																			<td style="text-align: center;">
																					<button type="button" class="btn btn-primary btn-sm waves-effect waves-light" onclick="goto(\''.util::creaURLApp(1,"conf_asegurado_modifica","&aseguradoid=".$p["aseguradoid"]).'\')" >Ver Detalle</button>
																					<button type="button" class="btn btn-danger btn-sm waves-effect waves-light" onclick="eliminarAsegurado(\''.$p["nombre"].'\',\''.$ELIMNA_URL.'\')" data-toggle="modal" data-target="#modal_elimina_perfil" >Editar Asegurado</button>
																	
																				</td>
																			
																		</tr>';
																
															}
															echo '</tbody>';
														}
													
													
													?>
													 
												</table>
			</div>
		</div>
	</div>
</div>
<div class="modal fade" id="modal_elimina_perfil" tabindex="-1" role="dialog" aria-labelledby="modal_elimina_perfilLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Eliminar Asegurado</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body" id="modal_cp_bdy">
				
				La demostración no incluye la eliminación del asegurado
				
			</div>
			<div class="modal-footer" id="modal_cp_fter">
				<button type="button" class="btn btn-secondary btn-sm waves-effect waves-light" data-dismiss="modal">Entendido</button>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
function ConsultarClientes()
{
	urlIn = "../c_srv/asegurado.php";
	dataIn = "acc=EXEINTEGRACION";
	srv="EXEINTEGRACION";
	msjError = "No pudimos realizar lo solicitado";
	sal = getDataJson(urlIn,dataIn,srv,msjError);	
	
}
</script>

<script>
    $(document).ready(function() {
    	    	
        $('#dataTables-ListaAsegurados').DataTable({
            responsive: true,
            "language": {
                "lengthMenu": "Mostrando _MENU_",
                "zeroRecords": "No se han encontrados registros",
                "info": "Mostrando página _PAGE_ de _PAGES_",
                "infoEmpty": "No se han encontrados registros",
                "search": "Busqueda",
                "infoFiltered": "(Filtro de _MAX_ registros totales)",
                "paginate": {
                	"previous": "Anterior",
                	"next": "Siguiente",
                	"first":    "Primero",
                    "last":    "Último"
                  }
                
            }
        });
    });

   
    </script>

				