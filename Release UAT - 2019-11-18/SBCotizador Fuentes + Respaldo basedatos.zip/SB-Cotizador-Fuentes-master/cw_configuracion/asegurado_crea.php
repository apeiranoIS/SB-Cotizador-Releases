<?php 

$vuelve = util::creaURLApp(1, "conf_asegurado_lista");


?>
<div class="row">
	<div class="col-md-12">
		<h1>Crear Asegurado</h1>
	</div>
</div>
<div class="row mb-4">
	<div class="col-md-12">
		<div class="card">
			<div class="card-header">
				Nuevo Asegurado
				<p class="task-list-stats" style="margin-right: 65px;">
					Para crear un nuevo asegurado en el sistema debe completar el siguiente formulario.
				</p>
				<div class="header-btn-block" style="top: 31px;">
					<button type="button" class="btn btn-secondary btn-sm waves-effect waves-light" onclick="goto('<?php echo $vuelve;?>');">Volver</button>
				</div>
			</div>
			<div class="card-body">
			
			<form role="form" name="frm_crea_asegurado" id="frm_crea_asegurado" method="post" enctype='multipart/form-data'>
				<input type="hidden" id="acc" name="acc" value="CREAASEGURADO">
				<input type="hidden" id="lista_asegurado_url" name="lista_asegurado_url" value="<?php echo $vuelve;?>">
				
				
				
				<div class="form-group">
					<label for="nombre"><span style="color:red;">*</span> Nombre</label>
					<input type="text" class="form-control" id="nombre" name="nombre" placeholder="Indique el nombre del nuevo usuario">
				</div>
				<div class="form-group">
					<label for="apellidos">Apellidos</label>
					<input type="text" class="form-control" id="apellidos" name="apellidos" placeholder="Indique el o los apellidos">
				</div>
				<div class="form-group">
					<label for="nombre"><span style="color:red;">*</span> RUT</label>
					<input type="text" class="form-control" id="rut" name="rut" placeholder="Indique el nombre del nuevo usuario">
				</div>
				<div class="form-group">
					<label for="apellidos">Giro</label>
					<input type="text" class="form-control" id="giro" name="giro" placeholder="Indique el Giro">
				</div>
				<div class="form-group">
					<label for="perfil"><span style="color:red;">*</span>Grupo</label>
					<select class="form-control" id="grupo" name="grupo">
						<option value="0">-- Seleccione un Grupo --</option>
						<?php 
							$grupos = negGrupo::getGrupos();
							foreach ($grupos as $g)
							{
							    echo '<option value="'.$g["grupoid"].'">'.$g["grupo"].'</option>';
							}
						?>					
					</select>
				</div>
				<div class="form-group">
					<label for="mail"><span style="color:red;">*</span>mail</label>
					<input type="text" class="form-control" id="mail" name="mail" placeholder="Indicar mail valido">
				</div>
				<div class="form-group">
					<label for="telefono">Telefono</label>
					<input type="text" class="form-control" id="telefono" name="telefono" >
				</div>
				
				
			</form>
			
			<div id="btn_crea_asegurado">
				<button type="button" class="btn btn-primary" onclick="crea_asegurado();" data-toggle="modal" data-target="#mod_creausuario" data-backdrop="static" data-keyboard="false">
						Crear Nuevo Asegurado
				</button>
			</div>
			<hr />
				
			</div>
		</div>
	</div>
</div>


<!-- Modal Validacion crea perfil -->
<div class="modal fade" id="mod_creausuario" tabindex="-1" role="dialog" aria-labelledby="mod_creausuarioLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Crear nuevo Asegurado</h5>
				
			</div>
			<div class="modal-body" id="modal_cp_bdy">
				
				
				
			</div>
			<div class="modal-footer" id="modal_cp_fter">
				
			</div>
		</div>
	</div>
</div>

				