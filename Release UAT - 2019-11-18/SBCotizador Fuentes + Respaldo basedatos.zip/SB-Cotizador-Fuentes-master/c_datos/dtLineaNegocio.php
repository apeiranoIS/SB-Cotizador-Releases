<?php 
class dtLineaNegocio{

    public static function getLineaNegocio()
	{
		$SQLQuery= "EXECUTE dbo.getLineaNegocio; ";
		return DBFactory::ExecuteSQL($SQLQuery);
		
	}
	
	public static function getLineaNegocioPorId($lineanegocioid)
	{
	    $SQLQuery= "EXECUTE dbo.getLineaNegocioPorId @lineanegocioid=".$lineanegocioid."; ";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	
	public static function ConsultarLN($codigo,$nombre)
	{
	    $SQLQuery= "EXECUTE dbo.CompletaLineaNegocio @nombre='".$nombre."',@codigo='".$codigo."';";
	    //echo $SQLQuery;
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	
	public static function getUrlIntegracionLineaNegocio($integracion)
	{
	    $SQLQuery= "EXECUTE dbo.getUrlIntegracionLineaNegocio @integracion='".$integracion."'; ";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	    
	}
	public static function updateLineaNegocio($coberturas,$codigo,$fecha_vigencia,$codigo_Producto,$codigo_riesgo)
	{
	    $arr = explode("/", $fecha_vigencia) ;
	    $fecha_vigencia = $arr[1]."/".$arr[0]."/".$arr[2];
	    $SQLQuery= "EXECUTE dbo.updateLineaNegocio @coberturas='".$coberturas."',@codigo='".$codigo."',@fecha_vigencia='".$fecha_vigencia."',@codigo_Producto='".$codigo_Producto."',@codigo_riesgo='".$codigo_riesgo."'; ";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function insertLineaNegocio($nombre,$codigo)
	{	   
	    $SQLQuery= "EXECUTE dbo.insertLineaNegocio @nombre='".$nombre."',@codigo='".$codigo."'; ";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function CreaLineaNegocioComercial($nombre_lnc)
	{
	    $SQLQuery = "EXECUTE dbo.crealineaNegocioComercial @nombre_lnc='".$nombre_lnc."';";
	    return DBFactory::ExecuteNonQueryReturnId($SQLQuery, "lineanegociocomercialid");
	}
	public static function guardaProductoLineaNegocioComercial($ln_comercialid,$productos) 
	{
	    $SQLQuery = "EXECUTE dbo.guardaProductoLineaNegocioComercial @ln_comercialid = ".$ln_comercialid.",@productoid = ".$productos.";";
	    
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function guardaUsuarioCreaLineaNegocioComercial($ln_comercialid,$usuarioid)
	{
	    $SQLQuery = "EXECUTE dbo.guardaUsuarioCreaLineaNegocioComercial @ln_comercialid=".$ln_comercialid.",@usuarioid = ".$usuarioid.";";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function getLineaNegocioComercial()
	{
	    $SQLQuery= "EXECUTE dbo.getLineaNegocioComercial; ";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	
	public static function getLineaNegocioComercialDetail($lineanegociocomercialid)
	{
	   $SQLQuery = "EXECUTE dbo.getDetalLineanegocioProducto @lineanegociocomercialid=".$lineanegociocomercialid.";";
	   return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function getProductoLineanegocioComercial($lineanegociocomercialid)
	{
	    $SQLQuery = "EXECUTE dbo.getProductosByLineaNegocioComercial @lineanegociocomercialid=".$lineanegociocomercialid.";";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function guardaNuevoNombreLnc($lnc_comecialid, $nuevo_nombre_lnc)
	{
	    $SQLQuery = "EXECUTE dbo.ModificaLineaNegocioComercial @lineangociocomercialid =".$lnc_comecialid.",@nombre='".$nuevo_nombre_lnc."'";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function eliminaProductoLNC($lnc_comecialid, $productoid)
	{
	    $SQLQuery = "EXECUTE dbo.eliminarProductoLineaNegocioComercial @lineangociocomercialid =".$lnc_comecialid.",@productoid=".$productoid."";
	    echo $SQLQuery;
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function eliminaLNC($lnc_comecialid)
	{
	    $SQLQuery = "EXECUTE dbo.eliminarLineaNegocioComercial @lineangociocomercialid =".$lnc_comecialid.";";
	    //echo $SQLQuery;
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function getUsuariosByLineaNegocioComercial($lnc_comecialid)
	{
	    $SQLQuery= "EXECUTE dbo.getUsuariosByLineaNegocioComercial @lineanegociocomercialid = ".$lnc_comecialid."; ";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getUsuariosByLineaNegocioComercialConfig($lnc_comecialid)
	{
	    $SQLQuery= "EXECUTE dbo.getUsuariosByLineaNegocioComercialConfig @lineanegociocomercialid = ".$lnc_comecialid."; ";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function addUsuariosToLineaNegocioComercialConfig($lnc_comecialid,$usuarioid)
	{
	    $SQLQuery= "EXECUTE dbo.addUsuariosToLineaNegocioComercialConfig @lineanegociocomercialid = ".$lnc_comecialid.", @usuarioid=".$usuarioid." ; ";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function elimnaUsuariosToLineaNegocioComercialConfig($lnc_comecialid,$usuarioid)
	{
	    $SQLQuery= "EXECUTE dbo.elimnaUsuariosToLineaNegocioComercialConfig @lineanegociocomercialid = ".$lnc_comecialid.", @usuarioid=".$usuarioid." ; ";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getFactoresNegocioByLineaComercial($lnc_comecialid)
	{
	    $SQLQuery= "EXECUTE dbo.getFactoresNegocioByLineaComercial @lineanegociocomercialid = ".$lnc_comecialid."; ";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getFactoresDisponiblesNegocioByLineaComercial($lnc_comecialid)
	{
	    $SQLQuery= "EXECUTE dbo.getFactoresDisponiblesNegocioByLineaComercial @lineanegociocomercialid = ".$lnc_comecialid."; ";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function addFactoresNegocioByLineaComercial($lnc_comecialid,$factorid)
	{
	    $SQLQuery= "EXECUTE dbo.addFactoresNegocioByLineaComercial @lineanegociocomercialid = ".$lnc_comecialid.",@factorid = ".$factorid."; ";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function eliminaFactoresNegocioByLineaComercial($lnc_comecialid,$factorid)
	{
	    $SQLQuery= "EXECUTE dbo.eliminaFactoresNegocioByLineaComercial @lineanegociocomercialid = ".$lnc_comecialid.",@factorid = ".$factorid."; ";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function GetTasasMontoxLinea($lnc_comecialid)
	{
	    $SQLQuery= "EXECUTE dbo.GetTasasMontoxLinea @lineanegociocomercialid = ".$lnc_comecialid."; ";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function EliminaMontoTasa($lnc_comecialid,$tipo_monto,$tipo_tasa)
	{
	    $SQLQuery= "EXECUTE dbo.eliminaMontoTasa @lineanegociocomercialid = ".$lnc_comecialid.",@tipo_monto = '".$tipo_monto."',@tipo_tasa = '".$tipo_tasa."'; ";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function AgregarTipoMontoTasa($lnc_comecialid,$tipo_monto,$tipo_tasa)
	{
	    $SQLQuery= "EXECUTE dbo.agregarTipoMontoTasa @lineanegociocomercialid = ".$lnc_comecialid.",@tipo_monto = '".$tipo_monto."',@tipo_tasa = '".$tipo_tasa."'; ";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function GetMateriasDisponiblesxLN($lnc_comecialid)
	{
	    $SQLQuery= "EXECUTE dbo.GetMateriasDisponiblesxLN @lineanegociocomercialid = ".$lnc_comecialid."; ";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function addMateriaTipoMT($lnc_comecialid,$tipo,$tipo_monto,$tipo_tasa,$materiaid)
	{
	    $SQLQuery= "EXECUTE dbo.addMateriaTipoMT @lineanegociocomercialid = ".$lnc_comecialid.",@tipo_monto = '".$tipo_monto."',@tipo_tasa = '".$tipo_tasa."',@tipo = '".$tipo."',@materiaid = '".$materiaid."'; ";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function EliminarMateriaTipoMT($lnc_comecialid,$tipo_monto,$tipo_tasa,$materiaid)
	{
	    $SQLQuery= "EXECUTE dbo.EliminarMateriaTipoMT @lineanegociocomercialid = ".$lnc_comecialid.",@tipo_monto = '".$tipo_monto."',@tipo_tasa = '".$tipo_tasa."',@materiaid = '".$materiaid."'; ";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	
}

?>