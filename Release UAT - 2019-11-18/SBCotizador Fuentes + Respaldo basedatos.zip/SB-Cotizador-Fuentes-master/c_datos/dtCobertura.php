<?php 
class dtCobertura{
    
public static function getCoberturas()
    {
        $SQLQuery= "EXECUTE dbo.getCoberturas; ";
        return DBFactory::ExecuteSQL($SQLQuery);
        
    }
    
    public static function getCoberturaPorId($coberturaid)
    {
        $SQLQuery= "EXECUTE dbo.getCoberturaPorId @coberturaid=".$coberturaid."; ";
        return DBFactory::ExecuteSQLFirst($SQLQuery);
    }
    
    public static function getCoberturaPorMateria($materiasid)
    {
        //$SQLQuery= "EXECUTE dbo.getMateriaPorSeccion @seccionesid=".$seccionesid."; ";
        $SQLQuery= "SELECT ma.materia,co.cobertura,ma.fecha_actualizacion,ma.r_fecha_vigencia as vigenciaMateria,co.r_fecha_vigencia as vigenciaCobertura
                    FROM cobertura co
                        inner join materia_cobertura mc ON co.coberturaid = mc.coberturaid
                        inner join materia ma ON ma.materiaid = mc.materiaid
                    WHERE mc.materiaid in (".$materiasid."); ";
        return DBFactory::ExecuteSQL($SQLQuery);
    }
    
    public static function ConsultarCobertura($codigo_producto, $codigo_seccion,$codigo_riesgo,$coberturas,
        $codigo, $fecha_Vigencia,$tipoCobertura,$nombre_ramo,$codigo_ramo)
    {
        $SQLQuery= "EXECUTE dbo.CompletaCobertura @codigo_producto ='".$codigo_producto."',@codigo_seccion ='".$codigo_seccion."',@codigo_riesgo='".$codigo_riesgo."',@coberturas = '".$coberturas."'
                    ,@tipoCobertura = '".$tipoCobertura."',@codigo = '".$codigo."',@fecha_vigencia ='".$fecha_Vigencia."',@nombre_ramo = '".$nombre_ramo."',@codigo_ramo = '".$codigo_ramo."';";
        //echo $SQLQuery."<br />";
         DBFactory::ExecuteNonQuery($SQLQuery);
    }
    public static function getUrlIntegracionCobertura($integracion)
    {
        $SQLQuery= "EXECUTE dbo.getUrlIntegracionCobertura @integracion='".$integracion."'; ";
        return DBFactory::ExecuteSQLFirst($SQLQuery);
        
    }
    public static function updateCobertura($coberturas,$codigo,$fecha_vigencia,$codigo_Producto,$codigo_riesgo)
    {
        $arr = explode("/", $fecha_vigencia) ;
        $fecha_vigencia = $arr[1]."/".$arr[0]."/".$arr[2];
        $SQLQuery= "EXECUTE dbo.updateCobertura @coberturas='".$coberturas."',@codigo='".$codigo."',@fecha_vigencia='".$fecha_vigencia."',@codigo_Producto='".$codigo_Producto."',@codigo_riesgo='".$codigo_riesgo."'; ";
        DBFactory::ExecuteNonQuery($SQLQuery);
    }
    public static function insertCobertura($coberturas,$codigo,$fecha_vigencia,$codigo_seccion,$codigo_Producto,$codigo_riesgo,$tipoCobertura,$nombre_ramo,$codigo_ramo)
    {
        $arr = explode("/", $fecha_vigencia) ;
        $fecha_vigencia = $arr[1]."/".$arr[0]."/".$arr[2];
        $SQLQuery= "EXECUTE dbo.insertCobertura @coberturas='".$coberturas."',@codigo='".$codigo."',@fecha_vigencia='".$fecha_vigencia."',@codigo_seccion='".$codigo_seccion."',@codigo_Producto='".$codigo_Producto."',@codigo_riesgo='".$codigo_riesgo."',@tipoCobertura='".$tipoCobertura."',@nombre_ramo='".$nombre_ramo."',@codigo_ramo='".$codigo_ramo."'; ";
        DBFactory::ExecuteNonQuery($SQLQuery);
    }
    public static function CompletaSeccionCobertura()
    {
        $SQLQuery= "EXECUTE dbo.CompletaSeccionCobertura; ";
        return DBFactory::ExecuteNonQuery($SQLQuery);
    }
}



?>