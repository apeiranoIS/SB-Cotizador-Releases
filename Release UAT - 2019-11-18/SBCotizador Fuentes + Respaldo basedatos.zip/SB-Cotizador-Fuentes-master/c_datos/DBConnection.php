<?php

class DBConnection
{
	function Connect(){
		
	    try
	    {
	        $serverName = "tcp:isdesarrollo.cruo06virxbz.sa-east-1.rds.amazonaws.com,1433";
	        $connectionOptions = array("Database"=>"sb_cotizador",
           "Uid"=>"root", "PWD"=>"imagina2019","CharacterSet" => "UTF-8");
	        $conn = sqlsrv_connect($serverName, $connectionOptions);
	        if($conn == false)
	             die( print_r( sqlsrv_errors(), true));
	        
	            return ($conn);      
	    }
	    catch(Exception $e)
	    {
	        echo("Error!");
	    }
	    
	}	
	
	

	

}

?>
