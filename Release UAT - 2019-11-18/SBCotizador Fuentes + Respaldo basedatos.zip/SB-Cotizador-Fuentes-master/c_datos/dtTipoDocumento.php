<?php 
class dtTipoDocumento{
    
    public static function getTipoDocuemnto()
    {
        $SQLQuery= "EXECUTE dbo.getTipoDocumento; ";
        return DBFactory::ExecuteSQL($SQLQuery);
        
    }
    
   
}



?>