<?php 
class dtProducto{

    public static function getProductos()
	{
		$SQLQuery= "EXECUTE dbo.getProductos; ";
		return DBFactory::ExecuteSQL($SQLQuery);
		
	}
	
public static function getProductosLista()
	{
	    $SQLQuery= "EXECUTE dbo.getProductosLista; ";
	    return DBFactory::ExecuteSQL($SQLQuery);
	    
	}
	
	public static function getProductoPorId($productoid)
	{
	    $SQLQuery= "EXECUTE dbo.getProductoPorId @productoid=".$productoid.";";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function ConsultarProducto($nombre_producto,$codigo,$fecha_vigencia,$linea_negocio)
	{
	    $arr = explode("/", $fecha_vigencia) ;
	    $fecha_vigencia = $arr[1]."/".$arr[0]."/".$arr[2];
	    
	    $SQLQuery= "EXECUTE dbo.CompletaProducto @nombre_producto='".$nombre_producto."',@codigo='".$codigo."',@fecha_vigencia='".$fecha_vigencia."',@linea_negocio='".$linea_negocio."'; ";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function UPdateProducto($nombre_producto,$codigo,$fecha_vigencia,$linea_negocio,$cod_linea_negocio,$ramo,$codigo_ramo)
	{
	    $arr = explode("/", $fecha_vigencia) ;
	    $fecha_vigencia = $arr[0]."/".$arr[1]."/".$arr[2];
	    $SQLQuery= "EXECUTE dbo.UPdateProducto @nombre_producto='".$nombre_producto."',@codigo='".$codigo."',@fecha_vigencia='".$fecha_vigencia."',@linea_negocio='".$linea_negocio."', @codigo_lineaNegocio='".$cod_linea_negocio."', @ramo='".$ramo."', @codigo_ramo='".$codigo_ramo."'; ";
	    //echo $SQLQuery;
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function INsertProducto($nombre_producto,$codigo,$fecha_vigencia,$linea_negocio,$cod_linea_negocio,$ramo,$codigo_ramo)
	{
	    $arr = explode("/", $fecha_vigencia) ;
	    $fecha_vigencia = $arr[1]."/".$arr[0]."/".$arr[2];
	    $SQLQuery= "EXECUTE dbo.INsertProducto @nombre_producto='".$nombre_producto."',@codigo='".$codigo."',@fecha_vigencia='".$fecha_vigencia."',@linea_negocio='".$linea_negocio."', @codigo_lineaNegocio='".$cod_linea_negocio."', @ramo='".$ramo."', @codigo_ramo='".$codigo_ramo."'; ";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function getLineaNegocioxNombre($nombreLN)
	{
	    $SQLQuery= "EXECUTE dbo.getLineaNegocioxNombre @nombre='".$nombreLN."'; ";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function getUrlIntegracionProducto($integracion)
	{
	    $SQLQuery= "EXECUTE dbo.getUrlIntegracion @integracion='".$integracion."'; ";	    
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	   
	}
	public static function getProductosLineaComercialValida($lnc_comecialid)
	{
	    $SQLQuery= "EXECUTE dbo.getProductosLineaNegocioComercial @lineanegociocomercialid = ".$lnc_comecialid."; ";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getProductosByusuarioLineaNegocio($usuarioid)
	{
	    $SQLQuery= "EXECUTE dbo.getProductosByusuarioLineaNegocio @usuarioid = ".$usuarioid."; ";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getLineaNegocioComercialByProductoid($productoid)
	{
	    $SQLQuery= "EXECUTE dbo.getLineaNegocioComercialByProductoid @productoid = ".$productoid."; ";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	
}


?>