<?php 
class dtAsegurado{

    public static function validaRutAsegurado($rut)
    {
        $sql = "EXECUTE dbo.validaRutAsegurado @rut=".$rut.";";
        return DBFactory::ExecuteSQLFirst($sql);
		
	}
	public static function creaAsegurado($rut,$nombre,$apellidos,$giro,$grupo,$mail,$telefono)
	{
	    $sql = "EXECUTE dbo.creaAsegurado @rut='".$rut."',@nombre='".$nombre."',@apellidos='".$apellidos."',@giro='".$giro."',@grupoid=".$grupo.",@mail='".$mail."',@telefono='".$telefono."';";
	    return DBFactory::ExecuteSQLFirst($sql);
	 
	}
	
	public static function getAsegurados()
	{
	    $sql = "EXECUTE dbo.getAsegurados;";
	    return DBFactory::ExecuteSQL($sql);
	}
	public static function getAsegurado($aseguradoid)
	{
	    $sql = "EXECUTE dbo.getAsegurado @aseguradoid=".$aseguradoid.";";
	    return DBFactory::ExecuteSQLFirst($sql);
	}
	public static function getAseguradoDetail($aseguradoid)
	{
	    $sql = "EXECUTE dbo.getAsegurado @aseguradoid=".$aseguradoid.";";
	    return DBFactory::ExecuteSQLFirst($sql);
	}
	public static function buscaAsegurado($rut,$nombre)
	{
	    $sql = "EXECUTE dbo.buscaAsegurado @rut='".$rut."',@nombre='".$nombre."';";
	    return DBFactory::ExecuteSQL($sql);
	}
	public static function buscaAseguradoInterno($nombre)
	{
	    $sql = "EXECUTE dbo.buscaAseguradoInterno @nombre='".$nombre."';";
	    return DBFactory::ExecuteSQL($sql);
	}
	public static function getExisteAseguradoXidTI($client_no)
	{
	    $sql = "EXECUTE dbo.existeAseguradoByIdTI @client_no = ".$client_no.";";
	    return DBFactory::ExecuteSQLFirst($sql);
	}
	public static function creaAseguradoIntegrado($cliente_nombre,$cliente_rut,$cliente_no){
	    $sql = "EXECUTE dbo.creaAseguradoIntegrado
                @id_ti = ".$cliente_no.",
                @rut = '".$cliente_rut."',
                @nombre = '".$cliente_nombre."';   ";
	    
	    return DBFactory::ExecuteNonQueryReturnId($sql,"aseguradoid");
	}
	public static function editAseguradoIntegrado($cliente_nombre,$cliente_rut,$cliente_no,$aseguradoid){
	    $sql = "EXECUTE dbo.editAseguradoIntegrado
                @id_ti = ".$cliente_no.",
                @rut = '".$cliente_rut."',
                @nombre = '".$cliente_nombre."',
                @aseguradoid = ".$aseguradoid.";  ";
	    
	    return DBFactory::ExecuteSQLFirst($sql);
	}
	
	public static function getAseguradosListaxId($cotiid)
	{
	    $sql = "EXECUTE dbo.getAseguradosPorId @cotiid =".$cotiid.";";
	    
	    return DBFactory::ExecuteSQL($sql);
	}
	public static function AddAseguradoCotizacion($aid,$cotiid)
	{
	    $sql = "EXECUTE dbo.AddAseguradoCotizacion @aseguradoid='".$aid."',@cotizacionid='".$cotiid."';";
	    DBFactory::ExecuteNonQuery($sql);
	    
	}
	public static function existeAseguradoCotizacion($cotiid)
	{
	    $sql = "EXECUTE dbo.getExisteAseguradoCotizacion @cotiid =".$cotiid.";";
	    //echo($sql);
	    return DBFactory::ExecuteSQLFirst($sql);
	}
	public static function eliminarAseguradoCoti($aseguradoid,$cotiid)
	{
	    $SQLQuery= "EXECUTE dbo.eliminarAseguradoCotizacion @aseguradoid = '".$aseguradoid."',@cotiid='".$cotiid."';";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function ConsultarAsegurado($cliente_nro,$rut,$apellido,$nombre,$tipo_persona)
	{
	    $SQLQuery= "EXECUTE dbo.CompletaAsegurado @cliente_nro='".$cliente_nro."',@rut='".$rut."',@apellido='".$apellido."',@nombre='".$nombre."',@tipo_persona=".$tipo_persona."; ";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function getAseguradoDetailByCotizacion($aseguradoid,$cotizacionid)
	{
	    $sql = "EXECUTE dbo.getAseguradoDetailByCotizacion @aseguradoid=".$aseguradoid.";";
	    return DBFactory::ExecuteSQLFirst($sql);
	}
	public static function getUrlIntegracionCliente($Integracion)
	{
	    $sql = "EXECUTE dbo.getUrlIntegracionCliente @integracion=".$Integracion.";";
	    return DBFactory::ExecuteSQLFirst($sql);
	}
	public static function buscaAseguradoNombreCompletoBD($nombre)
	{
	    $sql = "EXECUTE dbo.buscaAseguradoNombreCompletoBD @nombre='".$nombre."';";
	    return DBFactory::ExecuteSQL($sql);
	}
	public static function buscaAseguradoRutCompletoBD($nombre)
	{
	    $sql = "EXECUTE dbo.buscaAseguradoRutCompletoBD @nombre='".$nombre."';";
	    return DBFactory::ExecuteSQL($sql);
	}
	public static function validaAseguradoByIDTI($cliente_no)
	{
	    $sql = "EXECUTE dbo.validaAseguradoByIDTI @IDTI=".$cliente_no.";";
	    return DBFactory::ExecuteSQLFirst($sql);
	} 
	public static function creaAseguradoIntegracion($tipoCliente,$rut,$nombre,$apellidos,$giro,$direccion,$mail,$telefono,$ciudad,$pais,$fecha_nacimiento,$codigo_ocupacion,$estadoCivil,$exento,$celular)
	{
	    $sql = "EXECUTE dbo.AddAseguradoIntegracion @tipoCliente='".$tipoCliente."',@rut='".$rut."',@nombre='".$nombre."',@apellido='".$apellidos."',@giro='".$giro."',@direccion='".$direccion."',
                                                    @mail='".$mail."',@telefono='".$telefono."',@ciudad='".$ciudad."',@pais='".$pais."',@fecha_nacimiento='".$fecha_nacimiento."',@codigo_ocupacion='".$codigo_ocupacion."',
                                                    @estadoCivil='".$estadoCivil."',@exento='".$exento."',@celular='".$celular."';";
	    return DBFactory::ExecuteSQLFirst($sql);
	}
}


?>