<?php 
class dtIntegracion{
    
    public static function getIntegracionUrl()
    {
        $SQLQuery= "EXECUTE dbo.getIntegracionUrl; ";
        return DBFactory::ExecuteSQL($SQLQuery);
        
    }
    public static function EditaUrl($claveIntegracion,$nuevaUrl)
    {
        $SQLQuery= "EXECUTE dbo.EditaUrl @claveIntegracion='".$claveIntegracion."', @nuevaUrl='".$nuevaUrl."' ; ";
        
        DBFactory::ExecuteNonQuery($SQLQuery);
        
    }
    
}



?>