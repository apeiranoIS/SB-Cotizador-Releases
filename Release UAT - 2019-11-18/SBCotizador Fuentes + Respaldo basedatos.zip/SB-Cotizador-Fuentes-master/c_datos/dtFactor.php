<?php
class dtFactor{
    
    public static function CreaFactor($nombre,$tipo_tasa,$tipo)
    {
        $SQLQuery= "EXECUTE dbo.addFactor @nombre='".$nombre."',@tipo_tasa = '".$tipo_tasa."',@tipo = '".$tipo."'; ";
        DBFactory::ExecuteSQLFirst($SQLQuery);
    }
    public static function GetFactoresxEstado($estado)
    {
        $SQLQuery= "EXECUTE dbo.GetFactoresXEstado @estado='".$estado."'; ";
        return DBFactory::ExecuteSQL($SQLQuery);
    }
    public static function EliminarFactor($factorid)
    {
        $SQLQuery= "EXECUTE dbo.EliminarFactor @factorid='".$factorid."'; ";
        return DBFactory::ExecuteSQLFirst($SQLQuery);
    }
    public static function GetFactorxid($factorid)
    {
        $SQLQuery= "EXECUTE dbo.GetFactorxid @factorid='".$factorid."'; ";
        return DBFactory::ExecuteSQLFirst($SQLQuery);
    }
    public static function ModificaFactor($factorid,$nombre,$tipo_tasa,$tipo)
    {
        $SQLQuery= "EXECUTE dbo.ModificaFactor @factorid='".$factorid."', @nombre='".$nombre."',@tipo_tasa = '".$tipo_tasa."',@tipo = '".$tipo."'; ";
        return DBFactory::ExecuteSQLFirst($SQLQuery);
    }
    public static function AgregarValores($factorid,$valor_muestra_1,$valor_muestra_2,$valor_compara_1,$valor_compara_2,$factor,$tipo_factor,$valor_compara_ad_1,$valor_compara_ad_2)
    {
        $SQLQuery= "EXECUTE dbo.AgregarValores @factorid='".$factorid."', @valor_muestra_1='".$valor_muestra_1."'
          , @valor_muestra_2='".$valor_muestra_2."', @valor_compara_1='".$valor_compara_1."', @valor_compara_2='".$valor_compara_2."',
            @factor='".$factor."',@tipo_factor='".$tipo_factor."',@valor_compara_ad_1='".$valor_compara_ad_1."',@valor_compara_ad_2='".$valor_compara_ad_2."'; ";

        return DBFactory::ExecuteSQLFirst($SQLQuery);
    }
    public static function GetValoresXFactor($factorid)
    {
        $SQLQuery= "EXECUTE dbo.GetValoresXFactor @factorid='".$factorid."'; ";
        return DBFactory::ExecuteSQL($SQLQuery);
    }
    public static function EliminaValorFactor($factorvalorid)
    {
        $SQLQuery= "EXECUTE dbo.EliminarValorFactor @factorvalorid='".$factorvalorid."'; ";
        return DBFactory::ExecuteSQLFirst($SQLQuery);
    }
    
    
}



?>