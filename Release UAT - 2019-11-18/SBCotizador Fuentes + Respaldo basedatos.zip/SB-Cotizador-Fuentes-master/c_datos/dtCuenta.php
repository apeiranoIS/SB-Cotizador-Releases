<?php 
class dtCuenta
{	
	public static function validaUsuario($usuario, $clave)
	{
        $SQLQuery = "EXECUTE dbo.validaUsuario @usuario_mae = '".$usuario."', @clave = '".$clave."';";
		return DBFactory::ExecuteSQLFirst($SQLQuery);		
	}
	public static function getUsuario($usuarioid)
	{
		$SQLQuery= "EXECUTE dbo.getUsuario @usuarioid = ".$usuarioid."; ";
		return DBFactory::ExecuteSQLFirst($SQLQuery);	
	}
	public static function getAppsByPerfil($perfilid)
	{
		$SQLquery="EXECUTE dbo.getAppsByPerfil @perfilid = ".$perfilid.";";
		return DBFactory::ExecuteSQL($SQLquery);
	}
	public static function getUsuarioByCorreo($correo)
	{
		$SQLQuery= "EXECUTE dbo.getUsuarioByCorreo @mail='".$correo."'; ";
		return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function saveProcesoRecuperaClave($usuarioid,$correo,$url_env,$url_env_limpia)
	{
	   //pendiente de crear el procedimiento
		/*$SQLquery="call saveProcesoRecuperaClave('".$usuarioid."','".$correo."','".$url_env."','".$url_env_limpia."')";
		DBFactory::ExecuteNonQuery($SQLquery);*/
	}
	
	public static function getRecuperaClaveByURL($valida_url)
	{//pendiente de crear el procedimiento
		/*$SQLQuery= "call getRecuperaClaveByURL('".$valida_url."'); ";
		return DBFactory::ExecuteSQLFirst($SQLQuery);*/
	}
	public static function creaNuevaClaveusuario($usuarioid,$clave,$valida_url)
	{
		/*$SQLQuery= "call creaNuevaClaveusuario('".$usuarioid."','".$clave."','".$valida_url."'); ";
		return DBFactory::ExecuteSQLFirst($SQLQuery);*/
	}
	public static function validaCorreousuarioCrea($correo)
	{
		/*$ConexionOBJ = new DBConnection;
		$Conexion=$ConexionOBJ->ConnectToMasterBD();
		$SQLQuery= "call validaCorreousuarioCrea('".$correo."'); ";
		return DBFactory::ExecuteSQLFirst($SQLQuery,$Conexion);*/
	}
	public static function validaUsuarioCrea($usuario)
	{
		/*$ConexionOBJ = new DBConnection;
		$Conexion=$ConexionOBJ->ConnectToMasterBD();
		$SQLQuery= "call validaUsuarioCrea('".$usuario."'); ";
		return DBFactory::ExecuteSQLFirst($SQLQuery,$Conexion);*/
	}
	public static function creaCuenta($usuario,$clave,$correo,$nombre,$tipo_cliente,$organizacion,$tipo_cuenta)
	{
		/*$ConexionOBJ = new DBConnection;
		$Conexion=$ConexionOBJ->ConnectToMasterBD();
		$SQLQuery= "call creaCuenta('".$usuario."','".$clave."','".$correo."','".$nombre."','".$tipo_cliente."',".$organizacion.",'".$tipo_cuenta."'); ";
		return DBFactory::ExecuteNonQuery($SQLQuery,$Conexion);*/
	}
	public static function getCuentaMaster($correo)
	{
		/*$ConexionOBJ = new DBConnection;
		$Conexion=$ConexionOBJ->ConnectToMasterBD();
		$SQLQuery= "call getCuentaMaster('".$correo."'); ";
		return DBFactory::ExecuteSQLFirst($SQLQuery,$Conexion);*/
	}
	public static function getSistemaDef()
	{
	    $SQLQuery= "EXECUTE dbo.getSistemaDef; ";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	    
	}

}
?>
