<?php 
class dtCoaseguro{

   
    public static function insertCoaseguradorIntegrado($coasegurador,$codigo,$rut_coasegurador){
	    $sql = "EXECUTE dbo.insertCoaseguradorIntegrado 
                @coasegurador       = '".$coasegurador."',
                @codigo             = '".$codigo."',
                @rut_coasegurador   = '".$rut_coasegurador."';   ";
	    
	    return DBFactory::ExecuteNonQuery($sql);
	}
	
	public static function getCoaseguradores(){
	    
	    $sql = "EXECUTE dbo.getCoaseguradores;   ";
	    return DBFactory::ExecuteSQL($sql);
	}
	
}


?>