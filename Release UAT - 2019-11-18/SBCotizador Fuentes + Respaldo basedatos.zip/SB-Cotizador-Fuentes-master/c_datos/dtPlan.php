<?php 
class dtPlan{

    public static function getPlanes()
	{
		$SQLQuery= "EXECUTE dbo.getPlanes; ";
		return DBFactory::ExecuteSQL($SQLQuery);
		
	}
	
}


?>