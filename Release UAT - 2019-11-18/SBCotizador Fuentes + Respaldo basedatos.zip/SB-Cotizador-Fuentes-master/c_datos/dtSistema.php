<?php 
class dtSistema{
    public static function getCondicionesBloqueo()
    {
        $SQLquery="EXECUTE dbo.getCondicionesBloqueo";
        return DBFactory::ExecuteSQL($SQLquery);
    }
    public static function getDate()
    {
        $SQLquery="EXECUTE dbo.FechaHoy ;";
        return DBFactory::ExecuteSQLFirst($SQLquery);
    }
    public static function getSicCodeDetail($siccodeid)
    {
        $SQLquery="EXECUTE dbo.getSicCodeDetail @siccodeid = '".$siccodeid."';";
        return DBFactory::ExecuteSQLFirst($SQLquery);
    }
    public static function getSicCode()
    {
        $SQLquery="EXECUTE dbo.getSicCode";
        return DBFactory::ExecuteSQL($SQLquery);
    }
    public static function getComunasAllDetalleByComuna($id_comuna)
    {
        $SQLquery="EXECUTE dbo.getComunasAllDetalleByComuna @id_comuna = '".$id_comuna."';";
        return DBFactory::ExecuteSQLFirst($SQLquery);
    }
    public static function getComunasAllDetalle()
    {
        $SQLquery="EXECUTE dbo.getComunasAllDetalle";
        return DBFactory::ExecuteSQL($SQLquery);
    }
    public static function getComunas()
    {
        $SQLquery="EXECUTE dbo.getComunas";
        return DBFactory::ExecuteSQL($SQLquery);
    }
    public static function getProvincias()
    {
        $SQLquery="EXECUTE dbo.getProvincias";
        return DBFactory::ExecuteSQL($SQLquery);
    }
    public static function getRegiones()
    {
        $SQLquery="EXECUTE dbo.getRegiones";
        return DBFactory::ExecuteSQL($SQLquery);
    }
    
	public static function getAplicacionesSistema()
	{
		$SQLQuery= "EXECUTE dbo.getAplicacionesSistemaMenu; ";
		return DBFactory::ExecuteSQL($SQLQuery);
		
	}
	public static function getAplicacionesBloqueadasSistema()
	{
		$SQLQuery= "EXECUTE dbo.getAplicacionesBloqueadasSistema; ";
		return DBFactory::ExecuteSQL($SQLQuery);
		
	}
	
	public static function getAplicacionCode($codigo)
	{
		$SQLQuery= "EXECUTE dbo.getAplicacionCode @codigo = '".$codigo."'; ";
		return DBFactory::ExecuteSQL($SQLQuery);
		
	}
	
	public static function getAplicacionid($goModulo)
	{
		//no existe 
	    //$sql = "EXECUTE dbo.getAplicacionid('".$goModulo."'); ";
		//return DBFactory::ExecuteSQLFirst($sql);
	}
	
	public static function validaUsuario($correo,$clave)
	{
		
	    $SQLQuery= "EXECUTE dbo.validaUsuarioCorreoClave @codigo = '".$correo."',@clave ='".$clave."'; ";
		//echo $sql;
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}	
	public static function saveBitacoraByOpoeracionNav($tbl,$id_name,$id,$usuario,$tipo,$detalle,$aplicacionid)
    {
    	
        $SQLQuery= "EXECUTE dbo.saveBitacoraNavegacion @navegacionidWEB='".$id."',@tipo_actividad ='".$tipo."',@usuario_modifica='".$usuario."',@detalle='".$detalle."',@moduloid='".$aplicacionid."'; ";
        //echo $SQLQuery;
        DBFactory::ExecuteNonQuery($SQLQuery);
    }
    public static function saveBitacoraByOpoeracion($tbl,$id_name,$id,$usuario,$tipo,$detalle,$aplicacionid)
    {
        
        $SQLQuery= "EXECUTE dbo.saveBitacoraByOpoeracion @navegacionid = '".$id."',@tipo_actividad ='".$tipo."',@usuario_modifica='".$usuario."',@detalle='".$detalle."',@moduloid='".$aplicacionid."'; ";
        //echo $SQLQuery;
        DBFactory::ExecuteNonQuery($SQLQuery);
    }
    
    /**
     * Registra todas las actividades importantes del sistema
     * @param String $pk_id: [opcional]- ID del registro que se esta creando, modificando sino aplica se puede enviar un NA o un 0 
     * @param String $tabla_registro: [opcional]- Tabla asociada al identificador del registro indicado en el campo pk_id, sino aplica se puede enviar un NA o un 0 
     * @param String $modulo: [mandatorio]- Identifica el modulo en donde se esta realizando la acción
     * @param String $registro_tipo [mandatorio]- Identifica el tipo de registro realizado
     * @param Integer $usuarioid [mandatorio]- se debe indicar el usuario que realiza el registro o la acción
     */
    public static function creaSistemaRegistro($pk_id,$tabla_registro,$modulo,$registro_tipo,$usuarioid)
    {
    	//no existe sp en la base de datos
    	//$SQLquery="EXECUTE dbo.creaSistemaRegistro('".$pk_id."','".$tabla_registro."','".$modulo."','".$registro_tipo."','".$usuarioid."')";
    	//echo $SQLquery;
    	//DBFactory::ExecuteNonQuery($SQLquery);
    }
    
    public static function getUsuarioAdminMail()
    {
    	//no existe en la bdd
        //$sql = "EXECUTE dbo.getUsuarioAdminMail; ";
    	//return DBFactory::ExecuteSQL($sql);
    	
    }
    
    /*public static function getSistemaDef()
    {
    	$SQLQuery= "EXECUTE dbo.getSistemaDef; ";
    	return DBFactory::ExecuteSQLFirst($SQLQuery);
    	
    }*/
    public static function getTotDenuncias()
    {
    	//no existe en bdd
        //$SQLquery="EXECUTE dbo.getDenuncias";
    	//return DBFactory::ExecuteSQL($SQLquery);
    }
    public static function getTotDenunciasByUsuario($usuarioid)
    {
    	//no existe en bdd
        //$SQLquery="EXECUTE dbo.getDenunciasByUsuario(".$usuarioid.")";
    	//return DBFactory::ExecuteSQL($SQLquery);
    }
    public static function getTotConsultas()
    {
    	//no existe en bdd
        //$SQLquery="EXECUTE dbo.getConsultas";
    	//return DBFactory::ExecuteSQL($SQLquery);
    }
    public static function getTotConsultasByUsuario($usuarioid)
    {
    	// no existe en la bdd
        //$SQLquery="EXECUTE dbo.getConsltasByUsuario(".$usuarioid.")";
    	//return DBFactory::ExecuteSQL($SQLquery);
    }
    public static function getProyectoscreadoshoy_notif()
    {
    	//no existe en la bdd
    	//$SQLquery="EXECUTE dbo.getProyectoscreadoshoy_notif";
    	//return DBFactory::ExecuteSQL($SQLquery);
    }
    public static function getProyectoscreadoshoyByUser_notif($usuarioid)
    {
    	//no existe en la bdd
        //$SQLquery="EXECUTE dbo.getProyectoscreadoshoyByUser_notif(".$usuarioid.")";
    	//return DBFactory::ExecuteSQL($SQLquery);
    }
    public static function getActividadesPendientesByUser_notif($usuarioid)
    {
        //no existe en la bdd
    	//$SQLquery="EXECUTE dbo.getActividadesPendientesByUser_notif(".$usuarioid.")";
    	//return DBFactory::ExecuteSQL($SQLquery);
    }
    
    
    
}


?>