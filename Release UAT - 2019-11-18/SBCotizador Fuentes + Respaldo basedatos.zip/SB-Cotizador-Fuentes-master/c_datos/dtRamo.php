<?php 
class dtRamo{

    public static function getRamos()
	{
		$SQLQuery= "EXECUTE dbo.getRamos; ";
		return DBFactory::ExecuteSQL($SQLQuery);
		
	}
	
	public static function getRamosxProducto($productoid)
	{
	    $SQLQuery= "EXECUTE dbo.getRamosPorProducto @productoid=".$productoid;
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	    
	}
	
	public static function getRamosPorId($ramoid)
	{
	    $SQLQuery= "EXECUTE dbo.getRamosPorId @ramoid=".$ramoid;
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	    
	}
	public static function ConsultarRamo($codigo, $ramo)
	{
	    $SQLQuery= "EXECUTE dbo.CompletaRamo @codigo='".$codigo."',@ramo='".$ramo."'; ";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function getUrlIntegracionRamo($integracion)
	{
	    $SQLQuery= "EXECUTE dbo.getUrlIntegracionRamo @integracion='".$integracion."'; ";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	    
	}
	public static function updateRamo($coberturas,$codigo,$fecha_vigencia,$codigo_Producto,$codigo_riesgo)
	{
	    $arr = explode("/", $fecha_vigencia) ;
	    $fecha_vigencia = $arr[1]."/".$arr[0]."/".$arr[2];
	    $SQLQuery= "EXECUTE dbo.updateRamo @coberturas='".$coberturas."',@codigo='".$codigo."',@fecha_vigencia='".$fecha_vigencia."',@codigo_Producto='".$codigo_Producto."',@codigo_riesgo='".$codigo_riesgo."'; ";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function insertRamo($nombre,$codigo)
	{
	    $SQLQuery= "EXECUTE dbo.insertRamo @nombre='".$nombre."',@codigo='".$codigo."'; ";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	
}


?>