<?php 
class dtSegmento{

    public static function getsegmentos()
	{
		$SQLQuery= "EXECUTE dbo.getsegmentos; ";
		return DBFactory::ExecuteSQL($SQLQuery);
		
	}
	
}


?>