<?php 
class dtUsuario{

	public static function getUsuario($usuarioid)
	{
		$SQLQuery= "EXECUTE dbo.getUsuario @usuarioid=".$usuarioid."; ";
		return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function getUsuarios()
	{
		$SQLQuery= "EXECUTE dbo.getUsuarios; ";
		return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function validaDisponibilidadUsarioMae($ususario_mae)
	{
		// no existe en bdd
	    //$SQLQuery= "EXECUTE dbo.validaDisponibilidadUsuarioMae @usuario_mae='".$ususario_mae."'; ";
		//return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function creaUsuario($nombre,$apellidos,$mail,$telefono,$ususario_mae,$clave,$usuarioid,$perfil,$avataridPath)
	{
		$SQLQuery= "EXECUTE dbo.creaUsuario @nombre='".$nombre."',@apellidos='".$apellidos."',@mail='".$mail."',@telefono='".$telefono."',@usuario_mae='".$ususario_mae."',@clave_mae='".$clave."',@usuario_crea='".$usuarioid."',@perfilid='".$perfil."',@avatarid='".$avataridPath."'; ";
		return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function modificaaUsuario($nombre,$apellidos,$mail,$telefono,$ususario_mae,$clave,$perfil,$usuarioid,$estado)
	{
		$SQLQuery= "EXECUTE dbo.modificaUsuario @nombre='".$nombre."',@apellidos='".$apellidos."',@mail='".$mail."',@telefono='".$telefono."',@usuario_mae='".$ususario_mae."',@clave_mae='".$clave."',@usuarioid='".$usuarioid."',@perfilid='".$perfil."',@estado='".$estado."'; ";
		DBFactory::ExecuteNonQuery($SQLQuery);
	}
	
	public static function modificaUsuarioPersonal($nombre,$apellidos,$mail,$telefono,$ususario_mae,$clave,$usuarioid,$estado)
	{
	    $SQLQuery= "EXECUTE dbo.modificaUsuarioPersonal @nombre='".$nombre."',@apellidos='".$apellidos."',@mail='".$mail."',@telefono='".$telefono."',@usuario_mae='".$ususario_mae."',@clave_mae='".$clave."',@usuarioid='".$usuarioid."',@estado='".$estado."'; ";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function modificaImagen($usuarioid,$avataridPath)
	{
		// no exiswte en bdd
	    //$SQLQuery= "EXECUTE dbo.modificaImagen('".$avataridPath."','".$usuarioid."'); ";
		//DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function desHabilitaUsuario($usuarioid)
	{
		//no existe bdd
	    $SQLQuery= "EXECUTE dbo.deshabilitaUsuario @usuarioid = '".$usuarioid."'; ";
		DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function eliminarUsuario($usuarioid)
	{
		$SQLQuery= "EXECUTE dbo.eliminarUsuario @usuarioid = '".$usuarioid."'; ";
		DBFactory::ExecuteNonQuery($SQLQuery);
	}
	
    
}


?>