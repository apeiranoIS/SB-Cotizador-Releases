<?php
class dtAtributo{
    
    public static function getAtributos()
    {
        $sql = "EXECUTE dbo.getAtributos;";
        return DBFactory::ExecuteSQL($sql);
    }
    public static function getPosicionMaxAtributo(){
        $sql = "EXECUTE dbo.getPosicionMaxAtributo;";
        return DBFactory::ExecuteSQL($sql);
    }
    public static function addAtributo($atributo,$tipo_atributo,$factorid,$obligatorio,$imprime,$posicion,$factor_monto,$factor_tipo,$modificable){
        $sql = "EXECUTE dbo.addAtributo @atributo='".$atributo."',@tipo_atributo='".$tipo_atributo."', @factorid = ".$factorid.", @obligatorio = '".$obligatorio."', @imprime = '".$imprime."', @posicion = ".$posicion.", @factor_monto = '".$factor_monto."', @factor_tipo = '".$factor_tipo."', @modificable = '".$modificable."';";
        return DBFactory::ExecuteSQL($sql);
    }
    public static function getAtributoXid($atributoid){
        $sql = "EXECUTE dbo.getAtributoXid @atributoid = ".$atributoid.";";
        return DBFactory::ExecuteSQLFirst($sql);
    }
    public static function getValorAtributoXatributoid($atributoid){
        $sql = "EXECUTE dbo.getValorAtributoXatributoid @atributoid = ".$atributoid.";";
        return DBFactory::ExecuteSQL($sql);
    }
    public static function addValorAtributo($valor,$valor_interno_1,$valor_interno_2,$valor_interno_3,$atributoid){
        $sql = "EXECUTE dbo.addValorAtributo @valor='".$valor."',@valor_interno_1='".$valor_interno_1."', @valor_interno_2 = '".$valor_interno_2."', @valor_interno_3 = '".$valor_interno_3."', @atributoid = ".$atributoid.";";
        return DBFactory::ExecuteNonQuery($sql);
    }
    public static function deleteValorAtributo($atributovalorid){
        $sql = "EXECUTE dbo.deleteValorAtributo @atributovalorid = ".$atributovalorid.";";
        return DBFactory::ExecuteNonQuery($sql);
    }
}

?>