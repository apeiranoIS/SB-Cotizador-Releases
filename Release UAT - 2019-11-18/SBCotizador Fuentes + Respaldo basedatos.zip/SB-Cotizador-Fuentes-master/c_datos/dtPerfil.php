<?php 
class dtPerfil{

	
	public static function getPerfiles()
	{
		$SQLQuery= "EXECUTE dbo.getPerfiles; ";
		return DBFactory::ExecuteSQL($SQLQuery);
		
	}
	public static function getPerfil($perfilid)
	{
		$SQLQuery= "EXECUTE dbo.getPerfil @perfilid=".$perfilid."; ";
		return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function getAppsByPerfil($perfilid)
	{
		$SQLquery="EXECUTE dbo.getAppsByPerfil @perfilid='".$perfilid."'";
		return DBFactory::ExecuteSQL($SQLquery);
	}
	public static function getApps()
	{
		$SQLQuery= "EXECUTE dbo.getAplicacionesSistema; ";
		return DBFactory::ExecuteSQL($SQLQuery);
		
	}
	public static function AgregaPerfilRegistro($perfilid,$tipo,$usuarioid)
	{
	    //no se encuentra este procedimiento en la BD
		//$SQLQuery= "EXECUTE dbo.creaPerfilRegistro(".$perfilid.",'".$tipo."','".$usuarioid."'; ";
		//return DBFactory::ExecuteNonQuery($SQLQuery);
		
	}
	public static function creaPerfil($nombre,$descripcion)
	{
		$SQLquery="EXECUTE dbo.creaPerfil @nombre_perfil='".$nombre."',@descripcion='".$descripcion."'";
		return DBFactory::ExecuteSQLFirst($SQLquery);
	}
	public static function editaPerfil($nombre,$descripcion,$perfilid)
	{
		$SQLquery="EXECUTE dbo.editaPerfil @nombre_perfil='".$nombre."',@descripcion='".$descripcion."',@perfilid=".$perfilid."";
		return DBFactory::ExecuteSQLFirst($SQLquery);
	}
	public static function limpiaApssPerfil($perfilid)
	{
		$SQLquery="EXECUTE dbo.limpiaApssPerfil @perfilid=".$perfilid."";
		DBFactory::ExecuteNonQuery($SQLquery);
	}
	public static function addApssPerfil($perfilid,$apliacionid)
	{
		$SQLquery="EXECUTE dbo.addApssPerfil @perfilid=".$perfilid.",@aplicacionid=".$apliacionid."";
		DBFactory::ExecuteNonQuery($SQLquery);
	}
	public static function getUsuariosByPerfil($perfilid)
	{
		$SQLquery="EXECUTE dbo.getUsuariosByPerfil @perfilid=".$perfilid."";
		return DBFactory::ExecuteSQL($SQLquery);
	}
	public static function eliminaPerfil($perfilid)
	{
		$SQLquery="EXECUTE dbo.eliminaPerfil @perfilid=".$perfilid."";
		DBFactory::ExecuteNonQuery($SQLquery);
		
	}
	public static function deshabilitarPerfil($perfilid){
	    $SQLquery="EXECUTE dbo.deshabilitarPerfil @perfilid=".$perfilid."";
	    DBFactory::ExecuteNonQuery($SQLquery);
	}
	public static function habilitarPerfil($perfilid)
	{
	    $SQLquery="EXECUTE dbo.habilitarPerfil @perfilid=".$perfilid."";
	    DBFactory::ExecuteNonQuery($SQLquery);
	}
    
}


?>