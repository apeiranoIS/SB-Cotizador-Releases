<?php 
class dtWorking{

    public static function getItem()
    {
        $SQLQuery= "EXECUTE dbo.getItems; ";
        return DBFactory::ExecuteSQL($SQLQuery);
    }
    public static function GuardaItem($nombre_item)
	{
	    $SQLQuery= "EXECUTE dbo.ItemGuarda @nombre_item='".$nombre_item."';";
	    //echo  $SQLQuery;
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function EliminaItem($idItem)
	{
	    $SQLQuery= "EXECUTE dbo.ItemElimina @idItem=".$idItem."; ";
	    //echo  $SQLQuery;
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function getWordingsPorItem($itemid)
	{
	    $SQLQuery= "EXECUTE dbo.getWordingPorItem @iditem=".$itemid."; ";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function GuardaWording($nombre_wording,$detalle_wording,$itemId)
	{
	    $SQLQuery= "EXECUTE dbo.WordingGuarda @nombre_wording='".$nombre_wording."',@detalle_wording='".$detalle_wording."', @itemId = ".$itemId."; ";
	    //echo  $SQLQuery;
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function getWordingDetail($wordingid)
	{
	    $SQLQuery= "EXECUTE dbo.getWordingDetail @wordingid=".$wordingid.";";
	    //echo  $SQLQuery;
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function EditaWording($nombre_wording,$detalle_wording,$wordingId)
	{
	    $SQLQuery= "EXECUTE dbo.WordingEdita @nombre_wording='".$nombre_wording."',@detalle_wording='".$detalle_wording."', @wordingId = ".$wordingId."; ";
	    echo  $SQLQuery;
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function GuardaSecciones($wordingId,$secciones)
	{
	    $SQLQuery= "EXECUTE dbo.WordingGuardaSecciones @wordingId='".$wordingId."',@secciones='".$secciones."'; ";
	    //echo  $SQLQuery;
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function getSeccionesWording()
	{
	    $SQLQuery= "EXECUTE dbo.getSeccionesWording; ";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getProductosWording($idwording)
	{
	    $SQLQuery= "EXECUTE dbo.getProductosWording @idwording=".$idwording."; ";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getItemDetail($itemid)
	{
	    $SQLQuery= "EXECUTE dbo.getItemsDetail @itemid=".$itemid."; ";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function EditaItem($nombre_item,$itemId)
	{
	    $SQLQuery= "EXECUTE dbo.ItemEdita @nombre_item='".$nombre_item."',@itemId='".$itemId."'; ";
	    //echo  $SQLQuery;
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function addTAG($wordingId,$nombre_tag,$tag)
	{
	    $SQLQuery= "EXECUTE dbo.addTAG @wordingId=".$wordingId.",@nombre_tag='".$nombre_tag."', @tag='".$tag."'; ";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function getTaggWording($wordingId)
	{
	    $SQLQuery= "EXECUTE dbo.getTaggWording  @wordingId=".$wordingId."; ";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function eliminaTAG($tagid)
	{
	    $SQLQuery= "EXECUTE dbo.eliminaTAG @tagid=".$tagid."; ";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function eliminaWording($wordingid)
	{
	    $SQLQuery= "EXECUTE dbo.eliminaWording @wordingid=".$wordingid."; ";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
}


?>