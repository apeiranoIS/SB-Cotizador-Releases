<?php 
class dtMateria{
    
public static function getMaterias()
    {
        $SQLQuery= "EXECUTE dbo.getMaterias; ";
        return DBFactory::ExecuteSQL($SQLQuery);
        
    }
    
    public static function getMateriaPorId($materiaid)
    {
        $SQLQuery= "EXECUTE dbo.getMateriaPorId @materiaid=".$materiaid."; ";
        return DBFactory::ExecuteSQLFirst($SQLQuery);
    }
    public static function getMateriaPorIdMateria($materiaid)
    {
        $SQLQuery= "EXECUTE dbo.getMateriaPorIdMaterias @materiaid=".$materiaid."; ";       
        return DBFactory::ExecuteSQLFirst($SQLQuery);
    }
    public static function getMateriaPorSeccion($seccionesid)
    {
        //$SQLQuery= "EXECUTE dbo.getMateriaPorSeccion @seccionesid=".$seccionesid."; ";
        $SQLQuery= "SELECT ma.materiaid, ma.materia,ma.r_fecha_vigencia FROM materia ma inner join seccion_materia sm on ma.materiaid = sm.materiaid WHERE sm.seccionid in (".$seccionesid."); ";
        return DBFactory::ExecuteSQL($SQLQuery);
    }
    public static function ConsultarMateria($codigo_Producto, $codigo_seccion,$materia,$codigo_Materia,$fecha_Vigencia)
    {
        
        $arr = explode("/", $fecha_Vigencia) ;
        $fecha_Vigencia = $arr[1]."/".$arr[0]."/".$arr[2];
        
        $SQLQuery= "EXECUTE dbo.CompletaMateria @codigo_Producto='".$codigo_Producto."',@codigo_seccion='".$codigo_seccion."',@materia='".$materia."',@codigo_Materia='".$codigo_Materia."',@fecha_Vigencia='".$fecha_Vigencia."'; ";
        DBFactory::ExecuteNonQuery($SQLQuery);
    }
   
    public static function CompletaSeccionMateria()
    {
        $SQLQuery= "EXECUTE dbo.CompletaSeccionMateria; ";
        return DBFactory::ExecuteNonQuery($SQLQuery);
    }
    public static function getMateriasDisponiblesByUbicacionAndLNC($ubicacionid,$cotizacionid)
    {
        $SQLQuery= "EXECUTE dbo.getMateriasDisponiblesByUbicacionAndLNC @ubicacionid='".$ubicacionid."', @cotizacionid=".$cotizacionid."; ";
        return DBFactory::ExecuteSQL($SQLQuery);
    }
    public static function getMateriasLNCByCotizacion($cotizacionid)
    {
        $SQLQuery= "EXECUTE dbo.getMateriasLNCByCotizacion @cotizacionid=".$cotizacionid."; ";
        return DBFactory::ExecuteSQL($SQLQuery);
    }
    public static function getMateriasDisponiblesByUbicacion($ubicacionid,$cotizacionid)
    {
        $SQLQuery= "EXECUTE dbo.getMateriasDisponiblesByUbicacion @ubicacionid='".$ubicacionid."', @cotizacionid=".$cotizacionid."; ";
        return DBFactory::ExecuteSQL($SQLQuery);
    }
    public static function getUrlIntegracionMateria($integracion)
    {
        $SQLQuery= "EXECUTE dbo.getUrlIntegracionMateria @integracion='".$integracion."'; ";
        return DBFactory::ExecuteSQLFirst($SQLQuery);
        
    }
    public static function updateMateria($materia,$codigo_Materia,$fecha_vigencia)
    {
        $arr = explode("/", $fecha_vigencia) ;
        $fecha_vigencia = $arr[1]."/".$arr[0]."/".$arr[2];
        $SQLQuery= "EXECUTE dbo.updateMateria @materia='".$materia."',@codigo_Materia='".$codigo_Materia."',@fecha_vigencia='".$fecha_vigencia."'; ";
        DBFactory::ExecuteNonQuery($SQLQuery);
    }
    public static function insertMateria($materia,$codigo_Materia,$fecha_vigencia,$codigo_seccion,$codigo_Producto)
    {
        $arr = explode("/", $fecha_vigencia) ;
        $fecha_vigencia = $arr[1]."/".$arr[0]."/".$arr[2];
        $SQLQuery= "EXECUTE dbo.insertMateria @materia='".$materia."',@codigo_Materia='".$codigo_Materia."',@fecha_vigencia='".$fecha_vigencia."',@codigo_seccion='".$codigo_seccion."',@codigo_Producto='".$codigo_Producto."'; ";
        DBFactory::ExecuteNonQuery($SQLQuery);
    }
    public static function getMateriasDisponiblesByLineaNegocioComercial($lineanegociocomercialid)
    {
        $SQLQuery= "EXECUTE dbo.getMateriasDisponiblesByLineaNegocioComercial @lineanegociocomercialid='".$lineanegociocomercialid."'; ";
        return DBFactory::ExecuteSQL($SQLQuery);
    }
    public static function getMateriasByLineaNegocioComercial($lineanegociocomercialid)
    {
        $SQLQuery= "EXECUTE dbo.getMateriasByLineaNegocioComercial @lineanegociocomercialid='".$lineanegociocomercialid."'; ";
        return DBFactory::ExecuteSQL($SQLQuery);
    }
    public static function addMateriasByLineaNegocioComercial($lineanegociocomercialid,$materiaid)
    {
        $SQLQuery= "EXECUTE dbo.addMateriasByLineaNegocioComercial @lineanegociocomercialid='".$lineanegociocomercialid."', @materiaid=".$materiaid."; ";

        return DBFactory::ExecuteNonQuery($SQLQuery);
    }
    public static function deleteMateriasByLineaNegocioComercial($lineanegociocomercialid,$materiaid)
    {
        $SQLQuery= "EXECUTE dbo.deleteMateriasByLineaNegocioComercial @lineanegociocomercialid='".$lineanegociocomercialid."', @materiaid=".$materiaid."; ";
        
        return DBFactory::ExecuteNonQuery($SQLQuery);
    }
    public static function getMateriasDisponiblesByWording($wordingid)
    {
        $SQLQuery= "EXECUTE dbo.getMateriasDisponiblesByWording @idwording='".$wordingid."'; ";
        return DBFactory::ExecuteSQL($SQLQuery);
    }
    
    public static function getMateriasByWording($wordingid)
    {
        $SQLQuery= "EXECUTE dbo.getMateriasByWording @idwording='".$wordingid."'; ";
        return DBFactory::ExecuteSQL($SQLQuery);
    }
    public static function addMateriasToByWording($wordingid,$materiaid)
    {
        $SQLQuery= "EXECUTE dbo.addMateriasToByWording @idwording='".$wordingid."', @materiaid=".$materiaid."; ";
        
        return DBFactory::ExecuteNonQuery($SQLQuery);
    }
    public static function deleteMateriasToByWording($wordingid,$materiaid)
    {
        $SQLQuery= "EXECUTE dbo.deleteMateriasToByWording @idwording='".$wordingid."', @materiaid=".$materiaid."; ";
        
        return DBFactory::ExecuteNonQuery($SQLQuery);
    }
}



?>