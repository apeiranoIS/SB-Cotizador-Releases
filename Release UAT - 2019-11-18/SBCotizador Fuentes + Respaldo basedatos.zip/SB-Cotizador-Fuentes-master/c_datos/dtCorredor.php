<?php 
class dtCorredor{

    public static function getCorredores()
	{
	    $SQLQuery= "EXECUTE dbo.getCorredores; ";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getCorredorDetail($corredorid)
	{
	    $SQLQuery= "EXECUTE dbo.getCorredorDetail @corredorid=".$corredorid."; ";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	    
	}
	public static function buscaCorredor($rut,$nombre)
	{
	    $SQLQuery= "EXECUTE dbo.buscaCorredor @rut='".$rut."',@nombre='".$nombre."'; ";
	    return DBFactory::ExecuteSQL($SQLQuery);
	    
	}  
	public static function buscaCorredorInterno($nombre)
	{
	    $SQLQuery= "EXECUTE dbo.buscaCorredorInterno @nombre='".$nombre."'; ";
	    return DBFactory::ExecuteSQL($SQLQuery);	    
	} 
	public static function getExisteCorredorXNombreCompleto($corredor_nombre)
	{
	    $sql = "EXECUTE dbo.existeCorredorNombreCompleto @nombrecompleto ='".$corredor_nombre."';";
	    
	    return DBFactory::ExecuteSQLFirst($sql);
	}
	
	public static function getExisteCorredorXidTI($client_no){
	    //$sql = "EXECUTE dbo.existeCorredorByIdTI @client_no = ".$client_no.";";
	    //return DBFactory::ExecuteSQLFirst($sql);
	}
	public static function creaCorredorIntegrado($corredor_nombre,$corredor_rut){
	    $sql = "EXECUTE dbo.creaCorredorIntegrado 
                @corredor_nombre = '".$corredor_nombre."',
                @corredor_rut = '".$corredor_rut."';   ";
	    //echo $sql;
	    return DBFactory::ExecuteNonQueryReturnId($sql,"corredorid");
	}
	public static function editCorredorIntegrado($corredor_nombre,$corredor_rut){
	    $sql = "EXECUTE dbo.editCorredorIntegrado
                @corredor_nombre = '".$corredor_nombre."',
                @corredor_rut = '".$corredor_rut."';   ";
	    
	    return DBFactory::ExecuteSQLFirst($sql);
	}
	public static function ConsultarCorredor($rut,$nombre)
	{
	    $SQLQuery= "EXECUTE dbo.CompletaCorredor @rut='".$rut."',@=nombre'".$nombre.";";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function getUrlIntegracionCorredor($Integracion)
	{
	    $sql = "EXECUTE dbo.getUrlIntegracionCorredor @integracion=".$Integracion.";";
	    return DBFactory::ExecuteSQLFirst($sql);
	}
	public static function buscaCorredorNombreCompleto($nombre)
	{
	    $SQLQuery= "EXECUTE dbo.buscaCorredorNombreCompleto @nombre='".$nombre."'; ";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function buscaCorredorRutCompleto($rut)
	{
	    $SQLQuery= "EXECUTE dbo.buscaCorredorRutCompleto @nombre='".$rut."'; ";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
}


?>