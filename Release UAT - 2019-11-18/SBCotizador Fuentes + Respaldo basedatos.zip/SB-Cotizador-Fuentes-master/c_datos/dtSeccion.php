<?php 
class dtSeccion{

    public static function getSeccionPorProducto($productoid)
	{
	    $SQLQuery= "EXECUTE dbo.getSeccionesPorProducto @productoid=".$productoid;
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	
	public static function getSecciones()
	{
	    $SQLQuery= "EXECUTE dbo.getSecciones;";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	
	public static function getSeccionPorId($seccionid)
	{
	    $SQLQuery= "EXECUTE dbo.getSeccionPorId @seccionid=".$seccionid.";";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	
	public static function CompletaSecciones($nombreseccion,$codeSeccion,$fechavigencia,$codeProd)
	{
	    $arr = explode("/", $fechavigencia) ;
	    $fechavigencia = $arr[1]."/".$arr[0]."/".$arr[2];
	    
	    $SQLQuery= "EXECUTE dbo.CompletaSecciones @nombre_Seccion='".$nombreseccion."',@codigo='".$codeSeccion."',@fecha_Vigencia='".DateTime::createFromFormat("-", $fechavigencia)."',@codigo_producto='".$codeProd."'; ";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function CompletaProductoSeccioneRelacion()
	{
	    $SQLQuery= "EXECUTE dbo.CompletaProductoSeccioneRelacion; ";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function getUrlIntegracionSecciones($integracion)
	{
	    $SQLQuery= "EXECUTE dbo.getUrlIntegracionSecciones @integracion='".$integracion."'; ";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	    
	}
	public static function updateSecciones($coberturas,$codigo,$fecha_vigencia,$codigo_Producto,$codigo_riesgo)
	{
	    $arr = explode("/", $fecha_vigencia) ;
	    $fecha_vigencia = $arr[1]."/".$arr[0]."/".$arr[2];
	    $SQLQuery= "EXECUTE dbo.updateSecciones @coberturas='".$coberturas."',@codigo='".$codigo."',@fecha_vigencia='".$fecha_vigencia."',@codigo_Producto='".$codigo_Producto."',@codigo_riesgo='".$codigo_riesgo."'; ";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function insertSecciones($nombre_Seccion,$codigo,$fecha_vigencia,$codigo_producto)
	{
	    $arr = explode("/", $fecha_vigencia) ;
	    $fecha_vigencia = $arr[1]."/".$arr[0]."/".$arr[2];
	    $SQLQuery= "EXECUTE dbo.insertSecciones @nombre_Seccion='".$nombre_Seccion."',@codigo='".$codigo."',@fecha_vigencia='".$fecha_vigencia."',@codigo_producto='".$codigo_producto."'; ";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	
}


?>