<?php 
class dtEjecutivo{

    public static function getEjecutivos()
	{
		$SQLQuery= "EXECUTE dbo.getEjecutivos; ";
		return DBFactory::ExecuteSQL($SQLQuery);
		
	}
    public static function getUsuariosNoEjecutivo(){
        $SQLQuery= "EXECUTE dbo.getUsuariosNoEjecutivo ;";
	    return DBFactory::ExecuteSQL($SQLQuery);
    }
    public static function addEjecutivoUsuario($usuarioid){
        $SQLQuery= "EXECUTE dbo.addEjecutivoUsuario @usuarioid=".$usuarioid." ;";
	    return DBFactory::ExecuteNonQuery($SQLQuery);
    }
    public static function deleteEjecutivoUsuario($usuarioid){
        $SQLQuery= "EXECUTE dbo.deleteEjecutivoUsuario @usuarioid=".$usuarioid." ;";
	    return DBFactory::ExecuteNonQuery($SQLQuery);
    }
    public static function habilitaEjecutivoUsuario($usuarioid){
        $SQLQuery= "EXECUTE dbo.habilitaEjecutivoUsuario @usuarioid=".$usuarioid." ;";
	    return DBFactory::ExecuteNonQuery($SQLQuery);
    }
	
}


?>