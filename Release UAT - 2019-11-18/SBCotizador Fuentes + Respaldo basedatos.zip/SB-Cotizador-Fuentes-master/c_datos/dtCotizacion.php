<?php 
class dtCotizacion{
    
    public static function saveSublimite($cotizacionid,$valor,$sublimiteid)
    {
        $SQLQuery= "EXECUTE dbo.saveSublimite @cotizacionid ='".$cotizacionid."', @sublimiteid ='".$sublimiteid."', @sublimite ='".$valor."';";
        //echo $SQLQuery;
        DBFactory::ExecuteNonQuery($SQLQuery);
    }
    public static function saveTasaNetaSublimite($cotizacionid,$valor,$sublimiteid)
    {
        $SQLQuery= "EXECUTE dbo.saveTasaNetaSublimite @cotizacionid ='".$cotizacionid."', @sublimiteid ='".$sublimiteid."', @valor ='".$valor."';";
        //echo $SQLQuery;
        DBFactory::ExecuteNonQuery($SQLQuery);
    }
    public static function saveTasaBrutaSublimite($cotizacionid,$valor,$sublimiteid)
    {
        $SQLQuery= "EXECUTE dbo.saveTasaBrutaSublimite @cotizacionid ='".$cotizacionid."', @sublimiteid ='".$sublimiteid."', @valor ='".$valor."';";
        //echo $SQLQuery;
        DBFactory::ExecuteNonQuery($SQLQuery);
    }
    public static function savePrimaNetaSublimite($cotizacionid,$valor,$sublimiteid)
    {
        $SQLQuery= "EXECUTE dbo.savePrimaNetaSublimite @cotizacionid ='".$cotizacionid."', @sublimiteid ='".$sublimiteid."', @valor ='".$valor."';";
        //echo $SQLQuery;
        DBFactory::ExecuteNonQuery($SQLQuery);
    }
    public static function savePrimaBrutaSublimite($cotizacionid,$valor,$sublimiteid)
    {
        $SQLQuery= "EXECUTE dbo.savePrimaBrutaSublimite @cotizacionid ='".$cotizacionid."', @sublimiteid ='".$sublimiteid."', @valor ='".$valor."';";
        //echo $SQLQuery;
        DBFactory::ExecuteNonQuery($SQLQuery);
    }
    public static function saveDeducible($cotizacionid,$deducibleid,$valorTipo1,$valorTipo2)
    {
        $SQLQuery= "EXECUTE dbo.saveDeducible @cotizacionid = '".$cotizacionid."', @deducibleid='".$deducibleid."', @input_1= '".$valorTipo1."', @input_2='".$valorTipo2."';";
        DBFactory::ExecuteNonQuery($SQLQuery);
        
    }
    public static function editaDeducible($cotizacionid,$deducibleid,$valorTipo1,$valorTipo2,$tipo)
    {
        if($tipo == 1)
        {
            $SQLQuery= "EXECUTE dbo.editaDeducible_1 @cotizacionid = '".$cotizacionid."', @deducibleid='".$deducibleid."',@input_1='".$valorTipo1."';";
        }
        if($tipo == 2)
        {
            $SQLQuery= "EXECUTE dbo.editaDeducible_2 @cotizacionid = '".$cotizacionid."', @deducibleid='".$deducibleid."',@input_2='".$valorTipo2."';";
        }
        DBFactory::ExecuteNonQuery($SQLQuery);
    }
    public static function setTasas($cotizacionid,$tasa_afecta,$tasa_excenta,$tasa_neta)
    {
        $SQLQuery= "EXECUTE dbo.setTasas @cotizacionid='".$cotizacionid."',@tasa_afecta='".$tasa_afecta."',@tasa_excenta='".$tasa_excenta."', @tasa_neta='".$tasa_neta."';";
        DBFactory::ExecuteNonQuery($SQLQuery);
    }
    public static function addCotizacion($aseguradoid, $corredorid, $monedaid, $vigenciadesde, $vigenciahasta, $tipopoliza, $ubicaciones, $comisionafecta, $comisionexenta, $solicitud_corredor, $fecha_recepcion, $fecha_entrega, $lineanegocioid, $segmentoid, $ramoid, $productoid, $ejecutivo)
	{
	    $SQLQuery= "EXECUTE dbo.addCotizacion @aseguradoid=".$aseguradoid.", @corredorid= ".$corredorid.", @monedaid='".$monedaid."',@vigenciadesde='".$vigenciadesde."',@vigenciahasta='".$vigenciahasta."',@tipopoliza='".$tipopoliza."',@ubicaciones=".$ubicaciones.",@comisionafecta=".$comisionafecta.",@comisionexenta=".$comisionexenta.",@solicitud_corredor='".$solicitud_corredor."',@fecha_recepcion='".$fecha_recepcion."',@fecha_entrega='".$fecha_entrega."',@lineanegocioid='".$lineanegocioid."',@segmentoid='".$segmentoid."',@ramoid='".$ramoid."',@productoid='".$productoid."',@ejecutivoid='".$ejecutivo."';";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function editaCotizacion($cotizacionid,$aseguradoid, $corredorid, $monedaid, $vigenciadesde, $vigenciahasta, $tipopoliza, $ubicaciones, $comisionafecta, $comisionexenta, $solicitud_corredor, $fecha_recepcion, $fecha_entrega, $lineanegocioid, $segmentoid, $ramoid, $productoid, $ejecutivo)
	{
	    $SQLQuery= "EXECUTE dbo.editaCotizacion @cotizacionid=".$cotizacionid.",@aseguradoid=".$aseguradoid.", @corredorid= ".$corredorid.", @monedaid='".$monedaid."',@vigenciadesde='".$vigenciadesde."',@vigenciahasta='".$vigenciahasta."',@tipopoliza='".$tipopoliza."',@ubicaciones=".$ubicaciones.",@comisionafecta=".$comisionafecta.",@comisionexenta=".$comisionexenta.",@solicitud_corredor='".$solicitud_corredor."',@fecha_recepcion='".$fecha_recepcion."',@fecha_entrega='".$fecha_entrega."',@lineanegocioid='".$lineanegocioid."',@segmentoid='".$segmentoid."',@ramoid='".$ramoid."',@productoid='".$productoid."',@ejecutivoid='".$ejecutivo."';";
	    //echo $SQLQuery;
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function addCotizacionEstado($cotizacionid, $estado, $usuarioid, $nota,$bloqueo="NO")
	{
	    $SQLQuery= "EXECUTE dbo.addCotizacionEstado @cotizacionid= '".$cotizacionid."',@estado='".$estado."',@usuarioid=".$usuarioid.",@nota='".$nota."',@bloqueo='".$bloqueo."';";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function eliminaCotizacionCobertura($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.eliminaCotizacionCobertura @cotizacionid='".$cotizacionid."';";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function eliminaCotizacionPlan($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.eliminaCotizacionPlan @cotizacionid='".$cotizacionid."';";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function addCotizacionAccion($cotizacionid, $accion, $detalle, $usuarioid)
	{
	    $SQLQuery= "EXECUTE dbo.addCotizacionAccion @cotizacionid='".$cotizacionid."',@accion='".$accion."',@detalle='".$detalle."',@usuarioid='".$usuarioid."';";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function getPlanesCotizaion($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getPlanesCotizaion @cotizacionid='".$cotizacionid."';";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function addPlanToCotizacion($cotizacionid,$planid)
	{
	    $SQLQuery= "EXECUTE dbo.addPlanToCotizacion @cotizacionid='".$cotizacionid."',@planid='".$planid."';";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function addCoberturaToCotizacion($cotizacionid,$coberturaid)
	{
	    $SQLQuery= "EXECUTE dbo.addCoberturaToCotizacion @cotizacionid='".$cotizacionid."',@coberturaid='".$coberturaid."';";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function deleteCoberturaToCotizacion($cotizacionid,$coberturaid)
	{
	    $SQLQuery= "EXECUTE dbo.deleteCoberturaToCotizacion @cotizacionid='".$cotizacionid."',@coberturaid='".$coberturaid."';";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function addSeccionToCotizacion($cotizacionid,$seccionid)
	{
	    $SQLQuery= "EXECUTE dbo.addSeccionToCotizacion @cotizacionid='".$cotizacionid."',@seccionid='".$seccionid."';";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function getCotizacionDetail($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getCotizacionDetail @cotizacionid='".$cotizacionid."';";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function addCotizacionUbicacion( $cotizacionid, $nombre,$usuarioid)
	{
	    $posicion = self::getIdUbicacion($cotizacionid);
	    $SQLQuery="EXECUTE dbo.addCotizacionUbicacion @cotizacionid='".$cotizacionid."',@nombre='".$nombre."',@posicion=".$posicion.";";
	    echo $SQLQuery;    
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function addCotizacionUbicacionAtributo($cotizacionid,$ubicacionid)
	{
	    $SQLQuery="EXECUTE dbo.addCotizacionUbicacionAtributo @cotizacionid='".$cotizacionid."',@ubicacionid=".$ubicacionid.";";
	    echo $SQLQuery;
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function editaCotizacionUbicacion($ubicacionid, $nombre, $usuarioid)
	{
	    $SQLQuery="EXECUTE dbo.editaCotizacionUbicacion @ubicacionid='".$ubicacionid."',@nombre='".$nombre."';";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function getCotizacionUbicacion($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getCotizacionUbicacion @cotizacionid='".$cotizacionid."'; ";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getCotizaciones()
	{
	    $SQLQuery= "EXECUTE dbo.getCotizaciones;";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getCoberturas()
	{
	    $SQLQuery= "EXECUTE dbo.getCoberturas;";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getCoberturasPorProductro($prodId)
	{
	    $SQLQuery= "EXECUTE dbo.getCoberturasPorProductoid @prodId='".$prodId."';";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getTipoCoberturas()
	{
	    $SQLQuery= "EXECUTE dbo.getTipoCoberturas;";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function addCoberturaCotizacion($cotizacionid, $coberturaid)
	{
	    $SQLQuery= "EXECUTE dbo.addCoberturaCotizacion @cotizacionid= ".$cotizacionid.",@coberturaid=". $coberturaid.";";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function getCoberturasCotizacion($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getCoberturasCotizacion @cotizacionid=".$cotizacionid.";";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function addLimite($cotizacionid, $limite_poliza, $limite_todas_polizas_grupo )
	{
	    $SQLQuery= "EXECUTE dbo.addLimite @cotizacionid='".$cotizacionid."',@limite_poliza=". $limite_poliza.",@limite_todas_polizas_grupo=". $limite_todas_polizas_grupo."; ";
	   //echo $SQLQuery;
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function getCotizacionEstadoDef()
	{
	    $SQLQuery= "EXECUTE dbo.getCotizacionEstadoDef;";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getCotizacionEstadoEnProceso($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getCotizacionEstadoEnProceso @cotizacionid=".$cotizacionid.";";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function getCotizacionAccion($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getCotizacionAccion @cotizacionid=".$cotizacionid.";";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getDeducibleDef()
	{
	    $SQLQuery= "EXECUTE dbo.getDeducibleDef;";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getCotizacionDeducible($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getCotizacionDeducible @cotizacionid=".$cotizacionid.";";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getTipoCobAdicionalesSublimite()
	{
	    $SQLQuery= "EXECUTE dbo.getTipoSublimite;";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getCobAdicionalesSublimites()
	{
	    $SQLQuery= "EXECUTE dbo.getSublimites;";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getCobAdicionalesSublimitesByProducto($productoid)
	{
	    $SQLQuery= "EXECUTE dbo.getCobAdicionalesSublimitesByProducto @productoid=".$productoid.";";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getgetCobAdicionalesSublimitesCotizacion($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getSublimitesCotizacion @cotizacionid=".$cotizacionid.";";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getMateriasPorCotiSeccion($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getMateriasCotiSeccion @cotizacionid=".$cotizacionid;
	    
	    return DBFactory::ExecuteSQL($SQLQuery);
	    
	}
	public static function getProductosXramoYln($ramo,$ln){
	    $SQLQuery= "EXECUTE dbo.getProductosXramoYln @ramo=".$ramo.",@ln=".$ln;
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getRamoyLineaXproducto($productoid){
	    $SQLQuery= "EXECUTE dbo.getRamoyLineaXproducto @productoid=".$productoid;
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function getCantUbicacionesPorCotiId($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getCantUbicacionesPorCotiId @cotizacionid='".$cotizacionid."';";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	 public static function getSiniestralidadXcotizacionid($cotizacionid){
        $SQLQuery= "EXECUTE dbo.getSiniestralidadXcotizacionid @cotizacionid=".$cotizacionid.";";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function editSiniestralidad($cotizacionsiniestralidadid,$prima,$tiv,$nro_reclamo,$pagado,$pendiente,$gastos_honorarios)
	{
	        $SQLQuery= "EXECUTE dbo.editSiniestralidad 
	                    @cotizacionsiniestralidadid=".$cotizacionsiniestralidadid.",
	                    @prima = ".$prima.",
	                    @tiv = ".$tiv.",
	                    @nro_reclamo = ".$nro_reclamo.",
	                    @pagado = ".$pagado.",
	                    @pendiente = ".$pendiente.",
	                    @gastos_honorarios = ".$gastos_honorarios." ;";
		    return DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function getUbicacionesByCotizacion($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getUbicacionesByCotizacion @cotizacionid='".$cotizacionid."';";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getIdUbicacion($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getIdUbicacion @cotizacionid='".$cotizacionid."';";
	    
	    $ub = DBFactory::ExecuteSQLFirst($SQLQuery);
	    $ubicacionid =  $ub["cantidad"];
	    
	    return $ubicacionid;
	}
	public static function getUbicacionDetalle($ubicacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getUbicacionDetalle @ubicacionid='".$ubicacionid."';";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function addSiniestralidadCotizacion($cotizacionid,$vigencia){
        $SQLQuery= "EXECUTE dbo.addSiniestralidadCotizacion @cotizacionid=".$cotizacionid." , @vigencia ='".$vigencia."';";
        DBFactory::ExecuteNonQuery($SQLQuery);
    }
    public static function deleteSiniestralidadCotizacion($cotizacionid){
        $SQLQuery= "EXECUTE dbo.deleteSiniestralidadCotizacion @cotizacionid=".$cotizacionid.";";
        DBFactory::ExecuteNonQuery($SQLQuery);
    }
	public static function getEstadoCotizaciones()
	{
	    $SQLQuery= "EXECUTE dbo.getEstadoCotizaciones;";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function limpiaCotizacionSeccion($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.limpiaCotizacionSeccion  @cotizacionid=".$cotizacionid.";";
	    return DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function getCotizacionSecciones($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getCotizacionSecciones @cotizacionid=".$cotizacionid.";";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function addCotizacionUbicacionMateria($cotizacionid,$ubicacionid,$materiaid,$tipo)
	{
	    $SQLQuery= "EXECUTE dbo.addCotizacionUbicacionMateria  @cotizacionid=".$cotizacionid.",@materiaid=".$materiaid.",@ubicacionid=".$ubicacionid.",@tipo='".$tipo."';";
	    return DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function getCotizacionUbicacionMateria($cotizacionid,$ubicacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getCotizacionUbicacionMateria @cotizacionid=".$cotizacionid.", @ubicacionid=".$ubicacionid.";";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function deleteCotizacionUbicacionMateria($cotizacionid,$ubicacionid,$materiaid)
	{
	    $SQLQuery= "EXECUTE dbo.deleteCotizacionUbicacionMateria  @cotizacionid=".$cotizacionid.",@materiaid=".$materiaid.",@ubicacionid=".$ubicacionid.";";
	    return DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function saveMontoMateriaUbicacion($cotizacionid,$ubicacionid,$materiaid,$monto)
	{
	    $SQLQuery= "EXECUTE dbo.saveMontoMateriaUbicacion  @cotizacionid=".$cotizacionid.",@materiaid=".$materiaid.",@ubicacionid=".$ubicacionid.", @monto=".$monto.";";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function getProductosByDeducible($deducibleid)
	{
	    $SQLQuery= "EXECUTE dbo.getProductosByDeducible @deducibleid=".$deducibleid.";";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getProductosDisponibleByDeducible($deducibleid)
	{
	    $SQLQuery= "EXECUTE dbo.getProductosDisponibleByDeducible @deducibleid=".$deducibleid.";";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function addProductosDisponibleByDeducible($deducibleid,$productoid)
	{
	    $SQLQuery= "EXECUTE dbo.addProductosDisponibleByDeducible @deducibleid=".$deducibleid.",  @productoid=".$productoid." ;";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function elminaProductosDisponibleByDeducible($deducibleid,$productoid)
	{
	    $SQLQuery= "EXECUTE dbo.elminaProductosDisponibleByDeducible @deducibleid=".$deducibleid.",  @productoid=".$productoid." ;";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getDeducibleDefByProducto($productoid)
	{
	    $SQLQuery= "EXECUTE dbo.getDeducibleDefByProducto @productoid=".$productoid." ;";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function setCobAdicionSublmitePorProducto($sublimiteid,$productoid)
	{
	    $SQLQuery= "EXECUTE dbo.setCobAdicionSublmitePorProducto @sublimiteid=".$sublimiteid.",  @productoid=".$productoid." ;";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function eliminaCobAdicionSublmitePorProducto($sublimiteid,$productoid)
	{
	    $SQLQuery= "EXECUTE dbo.eliminaCobAdicionSublmitePorProducto  @productoid=".$productoid.",@sublimiteid=".$sublimiteid." ;";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getProductoSublmitePorProducto($sublimiteid)
	{
	    $SQLQuery= "EXECUTE dbo.getProductoSublmitePorProducto @sublimiteid=".$sublimiteid." ;";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getProductoSublmitePorProductoDisponible($sublimiteid)
	{
	    $SQLQuery= "EXECUTE dbo.getProductoSublmitePorProductoDisponible @sublimiteid=".$sublimiteid." ;";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function addCOmentariosCotizacionSiniestralidad($cotizacionid,$comentario_prima,$comentario_siniestral)
	{
	    $SQLQuery= "EXECUTE dbo.addCOmentariosCotizacionSiniestralidad  @cotizacionid=".$cotizacionid.",@comentario_prima='".$comentario_prima."', @comentario_sin='".$comentario_siniestral."' ;";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getSistemawordingposicion()
	{
	    $SQLQuery= "EXECUTE dbo.getSistemawordingposicion;";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function addWordingLibre($cotizacionid,$detalle_wording_add,$posicionid_wl)
	{
	    $SQLQuery= "EXECUTE dbo.addWordingCotizacion @cotizacionid =".$cotizacionid.",  @posicionid =".$posicionid_wl.", @wording ='".$detalle_wording_add."'
                                                    ,@woringid = 0, @tipo='LIBRE' ;";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function addWordingTemplate($cotizacionid,$wordingid,$posicionid,$detalle_wording_add)
	{
	    $SQLQuery= "EXECUTE dbo.addWordingCotizacion @cotizacionid =".$cotizacionid.",  @posicionid =".$posicionid.", @wording ='".$detalle_wording_add."'
                                                    ,@woringid = ".$wordingid.", @tipo='TEMPLATE' ;";
	   
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	    
	}
	public static function getWordingCotizacion($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getWordingCotizacion @cotizacionid=".$cotizacionid.";";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getWordingCotizacionByWording($cotizacionwordingid)
	{
	    $SQLQuery= "EXECUTE dbo.getWordingCotizacionByWording @cotizacionwordingid=".$cotizacionwordingid.";";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function editaWordingCotizacion($cotizacionwordingid,$wording)
	{
	    $SQLQuery= "EXECUTE dbo.editaWordingCotizacion @cotizacionwordingid=".$cotizacionwordingid.", @wording='".$wording."';";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function eliminaWordingCotizacion($cotizacionwordingid)
	{
	    $SQLQuery= "EXECUTE dbo.eliminaWordingCotizacion @cotizacionwordingid=".$cotizacionwordingid.";";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function getWordingByProducto($productoid)
	{
	    $SQLQuery= "EXECUTE dbo.getWordingByProducto @productoid=".$productoid.";";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function addTagCotizacionWorking($cotizacionwordingid,$tag_var,$tagid,$variable)
	{
	    $SQLQuery= "EXECUTE dbo.addTagCotizacionWorking @cotizacionwordingid=".$cotizacionwordingid.", @tagid=".$tagid.", @valor = '".$tag_var."', @variable='".$variable."';";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function getTagCotizacionWorking($cotizacionwordingid)
	{
	    $SQLQuery= "EXECUTE dbo.getTagCotizacionWorking @cotizacionwordingid=".$cotizacionwordingid.";";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getTipoDocumento()
	{
	    $SQLQuery= "EXECUTE dbo.getTipoDocumento;";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function CantidadTipoDocumentos()
	{
	    $SQLQuery= "EXECUTE dbo.CantidadTipoDocumentos;";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function GuardarDirectorioDocumento($tipo_documento,$PathCompleto,$cotizacionid,$nombre_file,$descripcion)
	{
	    $SQLQuery= "EXECUTE dbo.addDirectorioDocumento @tipo_documento=".$tipo_documento.", @PathCompleto='".$PathCompleto."', @cotizacionid = ".$cotizacionid.", @nombre_file='$nombre_file', @descripcion='".$descripcion."';";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function getDirectorio($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getDirectorio @cotizacionid=".$cotizacionid.";";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function eliminaDirectorio($iddirectorio)
	{
	    $SQLQuery= "EXECUTE dbo.eliminaDirectorio @iddirectorio=".$iddirectorio.";";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function getDirectorioByid($iddirectorio)
	{
	    $SQLQuery= "EXECUTE dbo.getDirectorioByid @iddirectorio=".$iddirectorio.";";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function getCoberturasDispByCotizacion($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getCoberturasDispByCotizacion @cotizacionid=".$cotizacionid.";";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getCoberturasByCotizacion($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getCoberturasByCotizacion @cotizacionid=".$cotizacionid.";";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getEjecutivoUsuario()
	{
	        $SQLQuery= "EXECUTE dbo.getEjecutivoUsuario ;";
		    return DBFactory::ExecuteSQL($SQLQuery);
	    }
	public static function addNotaCotizacion($cotizacionid,$nota,$usuarioid)
	{
	    $SQLQuery= "EXECUTE dbo.addNotaCotizacion @cotizacionid=".$cotizacionid.", @nota='".$nota."', @usuarioid=".$usuarioid.";";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function getNotasCotizacion($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getNotasCotizacion @cotizacionid=".$cotizacionid.";";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function addCoaseguroToCotizacion($cotizacionid,$coaseguro,$tc,$pc)
	{
	    $SQLQuery= "EXECUTE dbo.addCoaseguroToCotizacion 
                    @cotizacionid=".$cotizacionid.",
                    @coaseguro = '".$coaseguro."',
                    @tipo = '".$tc."',
                    @porcentaje_sb = ".$pc.";";
	    return DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function addCoaseguroParticipanteToCotizacion($cotizacionid,$coaseguradorid)
	{
	    $SQLQuery= "EXECUTE dbo.addCoaseguroParticipanteToCotizacion
                    @cotizacionid=".$cotizacionid.",
                    @coaseguradorid = ".$coaseguradorid.";";
	    return DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function getCoasegurosDisponiblesByCotizacion($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getCoasegurosDisponiblesByCotizacion @cotizacionid=".$cotizacionid.";";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getCoasegurosByCotizacion($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getCoasegurosByCotizacion @cotizacionid=".$cotizacionid.";";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getCoaseguroCOnfigByCotizacion($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getCoaseguroCOnfigByCotizacion @cotizacionid=".$cotizacionid.";";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function eliminaCoaseguradorCotizacion($cotizacionid,$coaseguradorid)
	{
	    $SQLQuery= "EXECUTE dbo.eliminaCoaseguradorCotizacion
                    @cotizacionid=".$cotizacionid.",
                    @coaseguradorid = '".$coaseguradorid."';";
	    return DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function eliminaCoaseguradorAllCotizacion($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.eliminaCoaseguradorAllCotizacion
                    @cotizacionid=".$cotizacionid.";";
	    return DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function addCoaseguroParticipePorcCotizacion($cotizacionid,$coaseguradorid,$pc)
	{
	    $SQLQuery= "EXECUTE dbo.addCoaseguroParticipePorcCotizacion
                    @cotizacionid=".$cotizacionid.",
                    @coaseguradorid = '".$coaseguradorid."',
                    @porcentaje = ".$pc." ;";
	    return DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function saveParticipacionCoasegurador($cotizacionid,$coaseguradorid,$tipo)
	{
	    
	    $SQLQuery= "EXECUTE dbo.saveParticipacionCoasegurador
                    @cotizacionid=".$cotizacionid.",
                    @coaseguradorid = '".$coaseguradorid."',
                    @tipo = '".$tipo."' ;";
	    return DBFactory::ExecuteNonQuery($SQLQuery);
	    
	}
	public static function eliminaTipoCoaseguradorAllCotizacion($cotizacionid,$tipo)
	{
	    
	    $SQLQuery= "EXECUTE dbo.eliminaTipoCoaseguradorAllCotizacion
                    @cotizacionid=".$cotizacionid.",
                    @tipo = '".$tipo."' ;";
	    return DBFactory::ExecuteNonQuery($SQLQuery);
	    
	}
	public static function saveTipoMateriaUbicacion($cotizacionid,$materiaid,$tipo,$ubicacionid)
	{
	    $SQLQuery= "EXECUTE dbo.saveTipoMateriaUbicacion
                    @cotizacionid=".$cotizacionid.",
                    @tipo = '".$tipo."',
                    @materiaid = ".$materiaid.",
                    @ubicacionid = ".$ubicacionid." ;";
	    return DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function getMisCotizaciones()
	{
	    $SQLQuery= "EXECUTE dbo.getMisCotizaciones @ejecutivoid=".$_SESSION["IGT-usuarioid"].";";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getMisCotizacionesEnCurso()
	{
	    $SQLQuery= "EXECUTE dbo.getMisCotizacionesEnCurso @ejecutivoid=".$_SESSION["IGT-usuarioid"].";";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function eliminaUbicacionCotizacion($cotizacionid,$ubicacionid)
	{
	    $SQLQuery= "EXECUTE dbo.eliminaUbicacionCotizacion @cotizacionid=".$cotizacionid.", @ubicacionid=".$ubicacionid.";";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getAtributosByUbicacion($cotizacionid, $ubicacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getAtributosByUbicacion @cotizacionid=".$cotizacionid.", @ubicacionid=".$ubicacionid.";";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function saveAttrToUbicacion($cotizacionid,$ubicacionid,$attr,$attrid,$tipo)
	{
	    
	    $SQLQuery= "EXECUTE dbo.saveAttrToUbicacion
                    @cotizacionid=".$cotizacionid.",
                    @ubicacionid = ".$ubicacionid.",
                    @valor = '".$attr."',
                    @attrid = ".$attrid." ;";
	    
	    return DBFactory::ExecuteNonQuery($SQLQuery);
	    
	}
	public static function getSistemaAtributoDetail($atributoid)
	{
	    $SQLQuery= "EXECUTE dbo.getSistemaAtributoDetail @atributoid=".$atributoid.";";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function saveFactorCotizacionUbicacion($cotizacionid,$ubicacionid,$factorid,$valor_compara_1,$valor_compara_2)
	{
	    
	    $SQLQuery= "EXECUTE dbo.saveFactorCotizacionUbicacion
                    @cotizacionid=".$cotizacionid.",
                    @ubicacionid = ".$ubicacionid.",
                    @factorid = '".$factorid."',
                    @valor_compara_1 = ".$valor_compara_1.",
                    @valor_compara_2 = ".$valor_compara_2."

                     ;";
	 
	    return DBFactory::ExecuteNonQuery($SQLQuery);
	    
	}
	public static function saveFactorMatrixCotizacionUbicacion($cotizacionid,$ubicacionid,$factorid,$valor_compara_1_2,$valor_compara_ad_1,$valor_compara_ad_2)
	{
	    
	    $SQLQuery= "EXECUTE dbo.saveFactorMatrixCotizacionUbicacion
                    @cotizacionid=".$cotizacionid.",
                    @ubicacionid = ".$ubicacionid.",
                    @factorid = '".$factorid."',
                    @valor_compara_1_2 = ".$valor_compara_1_2.",
                    @valor_compara_ad_1 = '".$valor_compara_ad_1."',
                    @valor_compara_ad_2 = '".$valor_compara_ad_2."'
                        
                     ;";
	    
	    return DBFactory::ExecuteNonQuery($SQLQuery);
	    
	}
	public static function getSistemaFactorCustom($tabla,$filtro="")
	{
	    $SQLQuery = "select * from ".$tabla."
                      where ".$filtro.";";
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getSistemaFactorCustomFiltro($tabla,$filtro)
	{
	    $SQLQuery = "select * 
                       from ".$tabla."
                      where ".$filtro.";";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function getAtributoDetailByUbicacion($cotizacionid, $ubicacionid,$atributoid)
	{
	    $SQLQuery= "EXECUTE dbo.getAtributoDetailByUbicacion @cotizacionid=".$cotizacionid.", @ubicacionid=".$ubicacionid.", @atributoid=".$atributoid." ;";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}	
	public static function getAtributoValorDetailByUbicacion($cotizacionid, $ubicacionid,$atributoid)
	{
	    $SQLQuery= "EXECUTE dbo.getAtributoValorDetailByUbicacion @cotizacionid=".$cotizacionid.", @ubicacionid=".$ubicacionid.", @atributoid=".$atributoid." ;";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function getMontoPrimaCotizacionUbicacionMateria($cotizacionid, $ubicacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getMontoPrimaCotizacionUbicacionMateria @cotizacionid=".$cotizacionid.", @ubicacionid=".$ubicacionid." ;";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
	public static function addCotizacionDeducibleFijo($cotizacionid)
	{
	    
	    $SQLQuery= "EXECUTE dbo.addCotizacionDeducibleFijo
                    @cotizacionid=".$cotizacionid.";";
	    
	    return DBFactory::ExecuteNonQuery($SQLQuery);
	    
	}
	public static function getDeduciblesFijosByCotizacion($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getDeduciblesFijosByCotizacion
                    @cotizacionid=".$cotizacionid.";";
	    
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function saveDeducibleFijoCotizacion($cotizacionid,$valor,$deduciblefijoid)
	{
	    $SQLQuery= "EXECUTE dbo.saveDeducibleFijoCotizacion
                    @cotizacionid=".$cotizacionid.",
                    @valor = ".$valor.",
                    @deduciblefijoid = ".$deduciblefijoid."
                     ;";
	    
	    return DBFactory::ExecuteNonQuery($SQLQuery);
	    
	}
	public static function getTiposMateriaByCotrizacion($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getTiposMateriaByCotrizacion
                    @cotizacionid=".$cotizacionid.";";
	    
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function getTiposTasasByCotrizacion($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getTiposTasasByCotrizacion
                    @cotizacionid=".$cotizacionid.";";
	    
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
	public static function eliminaCoberturaAdicionalConfig($sublimiteid)
	{
	    $SQLQuery= "EXECUTE dbo.eliminaCoberturaAdicionalConfig
                    @sublimiteid=".$sublimiteid."
                     ;";
	    
	    return DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function creaCoberturaSublimite($coberturaNombre,$tipo)
	{
	    $SQLQuery= "EXECUTE dbo.creaCoberturaSublimite
                    @sublimite       ='".$coberturaNombre."',
                    @sublimitetipoid =".$tipo."
                     ;";
	    
	    return DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function saveMateriaAdicionalSubLimiteTasaNeta($sublimiteid,$tasa)
	{
	    $SQLQuery= "EXECUTE dbo.saveMateriaAdicionalSubLimiteTasaNeta
                    @sublimiteid       =".$sublimiteid.",
                    @tasa =".$tasa."
                     ;";
	    
	    return DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function saveMateriaAdicionalSubLimiteTasaBruta($sublimiteid,$tasa)
	{
	    $SQLQuery= "EXECUTE dbo.saveMateriaAdicionalSubLimiteTasaBruta
                    @sublimiteid       =".$sublimiteid.",
                    @tasa =".$tasa."
                     ;";
	    
	    return DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function saveTasaCalculada($cotizacionid,$tipotasaid,$tasa)
	{
	    $SQLQuery= "EXECUTE dbo.saveTasaCalculada
                    @cotizacionid   =".$cotizacionid.",
                    @tipotasaid     =".$tipotasaid.",
                    @valor           =".$tasa."
                     ;";
	    return DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function saveTasaInput($cotizacionid,$tipotasaid,$tasa)
	{
	    $SQLQuery= "EXECUTE dbo.saveTasaInput
                    @cotizacionid   =".$cotizacionid.",
                    @tipotasaid     =".$tipotasaid.",
                    @valor           =".$tasa."
                     ;";
	    return DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function saveTipoTasaCotizacion($cotizacionid,$tipotasa)
	{
	    $SQLQuery= "EXECUTE dbo.saveTipoTasaCotizacion
                    @cotizacionid =".$cotizacionid.",
                    @tipotasa     ='".$tipotasa."'
                     ;";
	    return DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function saveCotizacionTasaFijaVersion($cotizacionid,$tasa_afecta,$tasa_excenta,$tasa_neta,$usuarioid)
	{
	    $SQLQuery= "EXECUTE dbo.saveCotizacionTasaFijaVersion
                    @cotizacionid   =".$cotizacionid.",
                    @tasa_afecta    =".$tasa_afecta.",
                    @tasa_excenta   =".$tasa_excenta.",
                    @tasa_neta      =".$tasa_neta.",
                    @usuarioid      =".$usuarioid."
                     ;";
	    return DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function getCotizacionTasaFijaVersion($cotizacionid)
	{
	    $SQLQuery= "EXECUTE dbo.getCotizacionTasaFijaVersion
                    @cotizacionid=".$cotizacionid.";";
	    
	    return DBFactory::ExecuteSQL($SQLQuery);
	}
}

?>