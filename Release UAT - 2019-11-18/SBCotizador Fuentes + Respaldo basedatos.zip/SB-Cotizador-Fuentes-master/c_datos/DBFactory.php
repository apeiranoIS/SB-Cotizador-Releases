<?php
include ('DBConnection.php');

class DBFactory {
	
	public static function ExecuteSQL($SQLQuery,$Conexion=null)
	{
		//echo "<hr />".$SQLQuery."<hr />";	    
	    $Conexion = new DBConnection;
	    $Conexion=$Conexion->Connect();
	    $rs = sqlsrv_query($Conexion,$SQLQuery);
	    $arr = array();
	    $entro = false;
	    while($obj = sqlsrv_fetch_array($rs, SQLSRV_FETCH_ASSOC)) {
	        $arr[] = $obj;
	        $entro = true;
	    }
	    if($entro == true){sqlsrv_free_stmt($rs);}
	    sqlsrv_close($Conexion);  
	    return $arr;
	}
	
	public static function ExecuteSQLFirst($SQLQuery,$Conexion=null)
	{
	    //echo "<hr />".$SQLQuery."<hr />";	    
	    $Conexion = new DBConnection;
	    $Conexion=$Conexion->Connect();
	    $rs = sqlsrv_query($Conexion,$SQLQuery);
	    $arr = array();
	    $entro = false;
	    while($obj = sqlsrv_fetch_array($rs, SQLSRV_FETCH_ASSOC)) {
	        $entro = true;
	        $arr[] = $obj;
	    }
	    if($entro == true){sqlsrv_free_stmt($rs);}
	    sqlsrv_close($Conexion);
	    return ($entro? $arr[0]:$arr);
	}
	
	public static function ExecuteNonQueryReturnId($SQLQuery,$id,$Conexion=null)
	{
		
	    $Conexion = new DBConnection;
	    $Conexion=$Conexion->Connect();
	    $arr = array();
	    $entro = false;
	    $insertReview = sqlsrv_query($Conexion, $SQLQuery);
	    if($insertReview == FALSE)
	        die(FormatErrors( sqlsrv_errors()));
	        
	        while($obj = sqlsrv_fetch_array($insertReview, SQLSRV_FETCH_ASSOC)) {
	            $entro = true;
	            $arr[] = $obj;
	        }
	        if($entro == true){sqlsrv_free_stmt($insertReview);}
	        sqlsrv_close($Conexion); 
	        
	        return $arr[0][$id];
	}
	
	public static function ExecuteNonQuery($SQLQuery,$Conexion=null)
	{
	    $Conexion = new DBConnection;
	    $Conexion=$Conexion->Connect();
	    $insertReview = sqlsrv_query($Conexion, $SQLQuery);
	    if($insertReview == FALSE)
	        die( print_r( sqlsrv_errors(), true));
	        
	        sqlsrv_fetch_array($insertReview, SQLSRV_FETCH_ASSOC);
	        
	        sqlsrv_free_stmt($insertReview);
	        sqlsrv_close($Conexion);
	        
	        
	        
	}
	
	
	
}


?>