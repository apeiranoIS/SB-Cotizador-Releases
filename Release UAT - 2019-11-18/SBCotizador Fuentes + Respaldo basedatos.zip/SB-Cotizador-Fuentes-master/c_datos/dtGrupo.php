<?php 
class dtGrupo{

    public static function getGrupos()
	{
		$SQLQuery= "EXECUTE dbo.getGrupos; ";
		return DBFactory::ExecuteSQL($SQLQuery);
		
	}
	public static function creaGrupo($grupo)
	{
	    $SQLQuery= "EXECUTE dbo.creaGrupo @grupo='".$grupo."'; ";
	    DBFactory::ExecuteNonQuery($SQLQuery);
	}
	public static function getGrupoDetalle($grupoid)
	{
	    $SQLQuery= "EXECUTE dbo.getGrupoDetalle @grupoid=".$grupoid."; ";
	    return DBFactory::ExecuteSQLFirst($SQLQuery);
	}
}


?>