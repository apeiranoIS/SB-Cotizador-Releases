<?php
class negProducto{
    
    
    
    public static function getProductos()
    {
        return dtProducto::getProductos();
    }
    public static function getProductosLista()
    {
        return dtProducto::getProductosLista();
    }
    public static function getProductoPorId($productoid)
    {
        return dtProducto::getProductoPorId($productoid);
    }
    public static function ConsultarProducto()
    {
        $integracion = 'get_producto';
        $url = dtProducto::getUrlIntegracionProducto($integracion);
       
        $consultaSB =  file_get_contents($url['url']);
        //$ConfigProd =  file_get_contents('http://104.211.29.91:9080/producto/getConfiguracionProducto');
        $consultaLocal = dtProducto::getProductos();
       // $lineaNegocio = negLineaNegocio::getLineaNegocio();
        
        
        $array = json_decode($consultaSB, true);
        //$arrCP = json_decode($ConfigProd, true);
        
        if($array["statusCode"] == "200")//RESPUESTA OK
        {
            $productos  = $array["result"];
            //$cproductos  = $arrCP["result"];
            
           foreach ($productos as $sb)// recorre Productos
            {
              $existe = 'NO';
              foreach($consultaLocal as $local)//recorre BDD local Productos 
                  {
                     
                      
                      if($sb["codigo"] == $local["r_codigo_producto"] && $sb["fecha_vigencia"] == $local["r_fecha_fmt"])
                      {
                          $existe = 'SI';
                          
                          if($sb["nombre_producto"] != $local["producto"])
                          {  
                              //echo "[UP". $sb["nombre_producto"].",".$sb["codigo"].",".$sb["fecha_vigencia"].",".$sb["linea_negocio"].",".$sb["cod_Lob"].",".$sb["ramo"].",".$sb["cod_ramo"]."<-<br />";
                              dtProducto::UPdateProducto($sb["nombre_producto"],$sb["codigo"],$sb["fecha_vigencia"],$sb["linea_negocio"],$sb["cod_Lob"],$sb["ramo"],$sb["cod_ramo"]);
                          }
                          else
                          {
                              //echo "PRODUCTO IGUAL NO SE HACE CAMBIO [] <br />++++++<br />";
                          }
                       }
                   }
                   if($existe == 'NO')
                   {//echo "Inster (Nuevo Producto) --> ". $sb["nombre_producto"].",".$sb["codigo"].",".$sb["fecha_vigencia"].",".$sb["linea_negocio"].",".$sb["cod_Lob"].",".$sb["ramo"].",".$sb["cod_ramo"]."<br />************************<br />";
                       dtProducto::INsertProducto($sb["nombre_producto"],$sb["codigo"],$sb["fecha_vigencia"],$sb["linea_negocio"],$sb["cod_Lob"],$sb["ramo"],$sb["cod_ramo"]);
                   }
                   //echo "<hr />";
               }
        }
    }
    public static function getProductosVigentes()
    {
        $prod = dtProducto::getProductos();
        $objAnterior;
        $prodAnterior = "";
        $arr = array();
        $cont = 0;
        foreach ($prod as $p)
        {
            $cont++;
            if($p["producto"] != $prodAnterior && $prodAnterior != "")
            {
                $arr[] = $objAnterior;
            }
            $objAnterior  = $p;
            $prodAnterior = $p["producto"];            
        }
        
        if($cont > 0)
        {
            $arr[] = $objAnterior;
        }
        return $arr;
    }
    public static function getProductosLineaComercialValida($lnc_comecialid)
    {
        return dtProducto::getProductosLineaComercialValida($lnc_comecialid);
    }
    public static function getUsuariosByLineaNegocioComercialConfig($lnc_comecialid)
    {
        return dtProducto::getUsuariosByLineaNegocioComercialConfig($lnc_comecialid);
    }
    public static function getProductosByusuarioLineaNegocio($usuarioid)
    {
        return dtProducto::getProductosByusuarioLineaNegocio($usuarioid);
    }
    public static function getLineaNegocioComercialByProductoid($productoid)
    {
        return dtProducto::getLineaNegocioComercialByProductoid($productoid);
    }
    
}



?>