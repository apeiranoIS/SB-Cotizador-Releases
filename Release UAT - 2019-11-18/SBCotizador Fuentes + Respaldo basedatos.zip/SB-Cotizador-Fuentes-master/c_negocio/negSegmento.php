<?php
class negSegmento{
    
    public static function getsegmentos()
    {
        return dtSegmento::getsegmentos();     
    }
    
    
}



?>