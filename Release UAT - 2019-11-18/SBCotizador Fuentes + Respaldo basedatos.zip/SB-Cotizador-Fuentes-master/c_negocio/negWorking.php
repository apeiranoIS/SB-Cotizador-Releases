<?php
class negWorking{
    
    public static function getItem()
    {
        return dtWorking::getItem();
    }
    public static function GuardaItem($nombre_item)
    {
       dtWorking::GuardaItem($nombre_item);
    }
    public static function EliminaItem($idItem)
    {
        
        $wordings = negWorking::getWordingsPorItem($idItem);
        foreach ($wordings as $w)
        {
            self::eliminaWording($w["id"]);
        }
        dtWorking::EliminaItem($idItem);
    }
    public static function getWordingsPorItem($itemid)
    {
        return dtWorking::getWordingsPorItem($itemid);
    }
    public static function GuardaWording($nombre_wording,$detalle_wording,$itemId)
    {
        dtWorking::GuardaWording($nombre_wording,$detalle_wording,$itemId);
    }
    public static function getWordingDetail($wordingid)
    {
        return dtWorking::getWordingDetail($wordingid);
    }
    public static function EditaWording($nombre_wording,$detalle_wording,$wordingId)
    {
        dtWorking::EditaWording($nombre_wording,$detalle_wording,$wordingId);
    }
    public static function GuardaSecciones($wordingId,$secciones)
    {
        if($secciones != "")
        {
            foreach ($secciones as $sec)
            {
                dtWorking::GuardaSecciones($wordingId,$sec);
            }
        }
        
    }
    public static function getSeccionesWording()
    {
        return dtWorking::getSeccionesWording();
    }
    public static function getProductosWording($idwording)
    {
        return dtWorking::getProductosWording($idwording);
    }
    public static function getItemDetail($itemid)
    {
        return dtWorking::getItemDetail($itemid);
    }
    public static function EditaItem($nombre_item,$itemId)
    {
        dtWorking::EditaItem($nombre_item,$itemId);
    }
    public static function addTAG($wordingId,$nombre_tag,$tag)
    {
        dtWorking::addTAG($wordingId,$nombre_tag,$tag);
    }
    public static function getTaggWording($wordingId)
    {
        return dtWorking::getTaggWording($wordingId);
    }
    public static function eliminaTAG($tagid)
    {
        dtWorking::eliminaTAG($tagid);
    }
    public static function eliminaWording($wordingid)
    {
        dtWorking::eliminaWording($wordingid);
    }
}



?>