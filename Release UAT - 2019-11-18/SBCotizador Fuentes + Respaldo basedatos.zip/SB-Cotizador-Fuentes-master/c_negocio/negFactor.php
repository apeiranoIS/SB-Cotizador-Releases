<?php
class negFactor{
    
    public static function CreaFactor($nombre,$tipo_tasa,$tipo)
    {
        return dtFactor::CreaFactor($nombre,$tipo_tasa,$tipo);
    }
    public static function GetFactoresxEstado($estado)
    {
        return dtFactor::GetFactoresxEstado($estado);
    }
    public static function EliminarFactor($factorid)
    {
        return dtFactor::EliminarFactor($factorid);
    }
    public static function GetFactorxid($factorid)
    {
        return dtFactor::GetFactorxid($factorid);
    }
    public static function ModificaFactor($factorid,$nombre,$tipo_tasa,$tipo)
    {
        return dtFactor::ModificaFactor($factorid,$nombre,$tipo_tasa,$tipo);
    }
    public static function AgregarValores($factorid,$valor_muestra_1,$valor_muestra_2,$valor_compara_1,$valor_compara_2,$factor,$tipo_factor,$valor_compara_ad_1,$valor_compara_ad_2)
    {
        return dtFactor::AgregarValores($factorid,$valor_muestra_1,$valor_muestra_2,$valor_compara_1,$valor_compara_2,$factor,$tipo_factor,$valor_compara_ad_1,$valor_compara_ad_2);
    }
    public static function GetValoresXFactor($factorid)
    {
        return dtFactor::GetValoresXFactor($factorid);
    }
    public static function EliminaValorFactor($factorvalorid)
    {
        return dtFactor::EliminaValorFactor($factorvalorid);
    }
}



?>