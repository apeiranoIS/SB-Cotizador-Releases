<?php
class negAtributo{
    
    public static function getAtributos()
    {
        return dtAtributo::getAtributos();
    }
    public static function getPosicionMaxAtributo(){
        return dtAtributo::getPosicionMaxAtributo();
    }
    public static function addAtributo($atributo,$tipo_atributo,$factorid,$obligatorio,$imprime,$posicion,$factor_monto,$factor_tipo,$modificable){
        dtAtributo::addAtributo($atributo,$tipo_atributo,$factorid,$obligatorio,$imprime,$posicion,$factor_monto,$factor_tipo,$modificable);
    }
    public static function getAtributoXid($atributoid){
        return dtAtributo::getAtributoXid($atributoid);
    }
    public static function getValorAtributoXatributoid($atributoid){
        return dtAtributo::getValorAtributoXatributoid($atributoid);
    }
    public static function addValorAtributo($valor,$valor_interno_1,$valor_interno_2,$valor_interno_3,$atributoid){
        dtAtributo::addValorAtributo($valor,$valor_interno_1,$valor_interno_2,$valor_interno_3,$atributoid);
    }
    public static function deleteValorAtributo($atributovalorid){
        dtAtributo::deleteValorAtributo($atributovalorid);
    }
}

?>