<?php
class negGrupo{
    
    public static function getGrupos()
    {
        return dtGrupo::getGrupos();     
    }
    
    public static function creaGrupo($grupo)
    {
        dtGrupo::creaGrupo($grupo);
    }
    
    public static function getGrupoDetalle($grupoid)
    {
        return dtGrupo::getGrupoDetalle($grupoid);
    }
    
}



?>