<?php 
class negTipoDocumento{
    
public static function getTipoDocuemnto()
    {
        return dtTipoDocumento::getTipoDocuemnto();
    }
   
}

?>