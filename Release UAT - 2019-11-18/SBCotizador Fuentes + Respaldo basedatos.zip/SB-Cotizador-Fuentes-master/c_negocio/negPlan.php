<?php
class negPlan{
    
    public static function getPlanes()
    {
        return dtPlan::getPlanes();
    }
    
    
}



?>