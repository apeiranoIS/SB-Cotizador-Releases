<?php
class negAsegurado{
    
    public static function validaRutAsegurado($rut)
    {
        $v = dtAsegurado::validaRutAsegurado($rut);
        $salida = "ERROR";
        if($v["valida"] == "0")
        {
            $salida = "OK";
        }
        
        return $salida;
    }
    
    public static function creaAsegurado($rut,$nombre,$apellidos,$giro,$grupo,$mail,$telefono)
    {
        dtAsegurado::creaAsegurado($rut,$nombre,$apellidos,$giro,$grupo,$mail,$telefono);
    }
    public static function getAsegurados()
    {
        return dtAsegurado::getAsegurados();
    }
    public static function getAsegurado($aseguradoid)
    {
        return dtAsegurado::getAsegurado($aseguradoid);
    }
    public static function buscaAsegurado($rut,$nombre)
    {
        if($rut   ==""){$rut   ="#SIN_DATOS_BUSQUEDA#";}
        if($nombre==""){$nombre="#SIN_DATOS_BUSQUEDA#";}
        return dtAsegurado::buscaAsegurado($rut,$nombre);
    }
    public static function buscaAseguradoInterno($nombre)
    {
        if($nombre==""){$nombre="#SIN_DATOS_BUSQUEDA#";}
        return dtAsegurado::buscaAseguradoInterno($nombre);
    }
    public static function getAseguradoDetail($corredorid)
    {
        return dtAsegurado::getAseguradoDetail($corredorid);
    }
    public static function getExisteAseguradoXidTI($client_no){
        return dtAsegurado::getExisteAseguradoXidTI($client_no);
    }
    
    public static function creaAseguradoIntegrado($cliente_nombre,$cliente_rut,$cliente_no){
        return dtAsegurado::creaAseguradoIntegrado($cliente_nombre,$cliente_rut,$cliente_no);
    }
    public static function editAseguradoIntegrado($cliente_nombre,$cliente_rut,$cliente_no,$aseguradoid){
        dtAsegurado::editAseguradoIntegrado($cliente_nombre,$cliente_rut,$cliente_no,$aseguradoid);
    }
    public static function getAseguradosListaxId($cotiid)
    {
        return dtAsegurado::getAseguradosListaxId($cotiid);
    }
    public static function AddAseguradoCotizacion($aid,$cotiid)
    {
        dtAsegurado::AddAseguradoCotizacion($aid,$cotiid);
    }
    public static function existeAseguradoCotizacion($cotiid)
    {
        return dtAsegurado::existeAseguradoCotizacion($cotiid);
    }
    public static function eliminarAseguradoCoti($aseguradoid,$cotiid)
    {
        dtAsegurado::eliminarAseguradoCoti($aseguradoid,$cotiid);
    }
    public static function ConsultarAsegurado($nombre,$rut)
    {        
       // $consulta =  file_get_contents("http://104.211.29.91:9080/clientes/getCliente/'.$rut.'/'.$nombre.'");
        
        $integracion = 'get_producto';
        $url = dtProducto::getUrlIntegracion($integracion);
        if(!empty($nombre))
        {
            $url += "/NULL/".$nombre;
            echo "NOmbre --> ".$url;
        }
        else
        {
            $url += "/".$rut."/NULL";
            echo "RUT --> ".$url;
        }
        
        $consultaSB =  file_get_contents($url['url']);
        //$ConfigProd =  file_get_contents('http://104.211.29.91:9080/producto/getConfiguracionProducto');
        $consultaLocal = dtAsegurado::getAsegurados();
        
        $array = json_decode($consultaSB, true);
        //$arrCP = json_decode($ConfigProd, true);
        
        if($array["statusCode"] == "200")//RESPUESTA OK
        {
            $asegurado  = $array["result"];
            //$cproductos  = $arrCP["result"];
            
            foreach ($asegurado as $s)// recorre Productos
            {
                $existe = 'NO';               
                
                foreach($consultaLocal as $local)//recorre BDD local Productos
                {
                    //echo "AnteDelIF-Codigos(UP-BDD) --> ". $sb["codigo"]." = ".$local["r_codigo_producto"]."|";
                    // echo "AnteDelIF-Nombres(UP-BDD) --> ". $sb["nombre_producto"]." = ".$local["producto"]."| ";
                    // echo "AnteDelIF-Fecha(UP-BDD) --> ". $sb["fecha_vigencia"]." = ".$local["r_fecha_fmt"]."<br />++++++<br />  ";
                    
                    if($sb["codigo"] == $local["r_codigo_producto"] && $sb["fecha_vigencia"] == $local["r_fecha_fmt"])
                    {
                        $existe = 'SI';
                        //echo "ENCONTRO <br />linea_negocio  SB   --> ". $sb["linea_negocio"]."<br />";
                        //echo "linea_negocio LOCAL --> ".$ln["lineanegocio"]."<br />++++++<br /> ";
                        
                        if($s["nombre_producto"] != $local["producto"])
                        {  echo "UP-Codigos(UP-BDD) --> ". $s["codigo"].",".$s["codigo"].",".$s["fecha_vigencia"]."<br />----- ------- ------- --<br />";
                        //dtProducto::UPdateProducto($s["client_no"], $s["rut"],$s["apellido"],$s["nombre"],$s["tipo_persona"]);
                        }
                        else
                        {
                            echo "PRODUCTO IGUAL NO SE HACE CAMBIO [] <br />++++++<br />";
                        }
                    }
                }
                if($existe == 'NO')
                {echo "Inster (Nuevo Producto) --> ". $s["nombre_producto"].",".$s["codigo"].",".$s["fecha_vigencia"]."<br />************************<br />";
                // dtProducto::INsertProducto($s["client_no"], $s["rut"],$s["apellido"],$s["nombre"],$s["tipo_persona"]);
                }
                echo "<hr />";
            }
        }
        
    }
    public static function getAseguradoDetailByCotizacion($aseguradoid,$cotizacionid)
    {
        return dtAsegurado::getAseguradoDetailByCotizacion($aseguradoid,$cotizacionid);
    }
    public static function validaClienteBaseDatos($datoCliente)
    {
        //Valida con el nombre
        $resultado = dtAsegurado::buscaAseguradoNombreCompletoBD($datoCliente);
        
        if(count($resultado) == 0)
        {
            //valida con el RUT
            $resultado = dtAsegurado::buscaAseguradoRutCompletoBD($datoCliente);
        }
        
        
        return $resultado;
        
    }
    public static function validaAseguradoByIDTI($cliente_no)
    {
        $cliente_no = (int)$cliente_no;
        $salida =  dtAsegurado::validaAseguradoByIDTI($cliente_no);
        return $salida;
        
    }
    public static function creaAseguradoIntegracion($tipoCliente,$rut,$nombre,$apellidos,$giro,$direccion,$mail,$telefono,$ciudad,$pais,$fecha_nacimiento,$codigo_ocupacion,$estadoCivil,$exento,$celular)
    {
        return dtAsegurado::creaAseguradoIntegracion($tipoCliente,$rut,$nombre,$apellidos,$giro,$direccion,$mail,$telefono,$ciudad,$pais,$fecha_nacimiento,$codigo_ocupacion,$estadoCivil,$exento,$celular);
    }
}

?>