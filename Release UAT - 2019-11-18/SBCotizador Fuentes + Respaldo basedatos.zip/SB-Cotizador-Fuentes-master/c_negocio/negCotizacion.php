<?php 
class negCotizacion{
    
    public static function saveSublimite($cotizacionid,$valor,$sublimiteid)
    {
        dtCotizacion::saveSublimite($cotizacionid,$valor,$sublimiteid);
    }
    public static function saveTasaNetaSublimite($cotizacionid,$valor,$sublimiteid)
    {
        dtCotizacion::saveTasaNetaSublimite($cotizacionid,$valor,$sublimiteid);
    }
    public static function saveTasaBrutaSublimite($cotizacionid,$valor,$sublimiteid)
    {
        dtCotizacion::saveTasaBrutaSublimite($cotizacionid,$valor,$sublimiteid);
    }
    public static function savePrimaNetaSublimite($cotizacionid,$valor,$sublimiteid)
    {
        dtCotizacion::savePrimaNetaSublimite($cotizacionid,$valor,$sublimiteid);
    }
    public static function savePrimaBrutaSublimite($cotizacionid,$valor,$sublimiteid)
    {
        dtCotizacion::savePrimaBrutaSublimite($cotizacionid,$valor,$sublimiteid);
    }
    public static function saveDeducible($cotizacionid,$valor,$deducibleid,$tipo)
    {
        $valorTipo1=0;
        $valorTipo2=0;
        
        if($tipo==1){$valorTipo1=$valor;}else{$valorTipo2=$valor;}
        
        $existe = "N";
        $deducibles = negCotizacion::getCotizacionDeducible($cotizacionid);
        foreach ($deducibles as  $d)
        {
            if($d["deducibleid"] == $deducibleid){$existe = "S";}
        }
        
        if($existe == "N")
        {
            dtCotizacion::saveDeducible($cotizacionid,$deducibleid,$valorTipo1,$valorTipo2,$tipo);
        }else
        {
            dtCotizacion::editaDeducible($cotizacionid,$deducibleid,$valorTipo1,$valorTipo2,$tipo);
            
        }
        
        
    }
    public static function setTasas($cotizacionid,$tasa_afecta,$tasa_excenta,$tasa_neta)
    {
        dtCotizacion::setTasas($cotizacionid,$tasa_afecta,$tasa_excenta,$tasa_neta);
        
        $cot = negCotizacion::getCotizacionDetail($cotizacionid);
        if($cot["tasa_manual"]=="SI")
        {
            $usuarioid = $_SESSION["IGT-usuarioid"];
            //GUARDA VERSION DE TASAS INGRESADAS MANUALMENTE
            self::saveCotizacionTasaFijaVersion($cotizacionid,$tasa_afecta,$tasa_excenta,$tasa_neta,$usuarioid);
        }
    }
    public static function saveCotizacionTasaFijaVersion($cotizacionid,$tasa_afecta,$tasa_excenta,$tasa_neta,$usuarioid)
    {
        dtCotizacion::saveCotizacionTasaFijaVersion($cotizacionid,$tasa_afecta,$tasa_excenta,$tasa_neta,$usuarioid);
    }
    public static function addCotizacion($aseguradoid, $corredorid, $monedaid, $vigenciadesde, $vigenciahasta, $tipopoliza, $ubicaciones, $comisionafecta, $comisionexenta,$usuarioid,$solicitud_corredor,$fecha_recepcion,$fecha_entrega,$lineanegocioid,$segmentoid,$ramoid,$productoid,$ejecutivo)
	{
	    if($comisionafecta==""){$comisionafecta="NULL";}else{$comisionafecta=str_replace(",",".",str_replace(".", "", $comisionafecta));}
	    if($comisionexenta==""){$comisionexenta="NULL";}else{$comisionexenta=str_replace(",",".",str_replace(".", "", $comisionexenta));}
	    $cotOb = dtCotizacion::addCotizacion($aseguradoid, $corredorid, $monedaid, $vigenciadesde, $vigenciahasta, $tipopoliza, $ubicaciones, $comisionafecta, $comisionexenta, $solicitud_corredor, $fecha_recepcion, $fecha_entrega, $lineanegocioid, $segmentoid, $ramoid, $productoid, $ejecutivo);
	    
	    dtCotizacion::addCotizacionAccion($cotOb["cotizacionid"], "CREA COTIZACIÓN", "Se crea cotización", $usuarioid);
	    dtCotizacion::addCotizacionEstado($cotOb["cotizacionid"], "RESERVA", $usuarioid, "Se crea cotización #".$cotOb["cotizacionid"]." (nota automatica)","NO");
	    negCotizacion::addCoaseguroToCotizacion($cotOb["cotizacionid"],"NO","",0);
	    
	    
	    
	    return $cotOb;
	}
	public static function editCotizacion($cotizacionid,$aseguradoid, $corredorid, $monedaid, $vigenciadesde, $vigenciahasta, $tipopoliza, $ubicaciones, $comisionafecta, $comisionexenta,$usuarioid,$solicitud_corredor,$fecha_recepcion,$fecha_entrega,$lineanegocioid,$segmentoid,$ramoid,$productoid,$ejecutivo,$secciones)
	{
	    if($comisionafecta==""){$comisionafecta="NULL";}else{$comisionafecta=str_replace(",",".",str_replace(".", "", $comisionafecta));}
	    if($comisionexenta==""){$comisionexenta="NULL";}else{$comisionexenta=str_replace(",",".",str_replace(".", "", $comisionexenta));}
	    
	    dtCotizacion::editaCotizacion($cotizacionid,$aseguradoid, $corredorid, $monedaid, $vigenciadesde, $vigenciahasta, $tipopoliza, $ubicaciones, $comisionafecta, $comisionexenta, $solicitud_corredor, $fecha_recepcion, $fecha_entrega, $lineanegocioid, $segmentoid, $ramoid, $productoid, $ejecutivo);
	    dtCotizacion::addCotizacionAccion($cotizacionid, "EDITA COTIZACIÓN", "Se editan los datos de la cotización cotización", $usuarioid);
	   
	    dtCotizacion::limpiaCotizacionSeccion($cotizacionid);
	    if($secciones != "")
	    {
	        
	        foreach ($secciones as $a)
	        {
	            dtCotizacion::addSeccionToCotizacion($cotizacionid,$a);
	        }
	    }
	    
	   
	}
	public static function getCotizacionDetail($cotizacionid)
	{
	    return dtCotizacion::getCotizacionDetail($cotizacionid);
	}
	public static function getPlanesCotizaion($cotizacionid)
	{
	    return dtCotizacion::getPlanesCotizaion($cotizacionid);
	}
	public static function addCoberturaToCotizacion($cotizacionid,$coberturaid)
	{
	    return dtCotizacion::addCoberturaToCotizacion($cotizacionid,$coberturaid);
	}
	public static function deleteCoberturaToCotizacion($cotizacionid,$coberturaid)
	{
	    return dtCotizacion::deleteCoberturaToCotizacion($cotizacionid,$coberturaid);
	}
	public static function addCotizacionUbicacion($cotizacionid, $nombre, $usuarioid)
	{
	    $idUbica = dtCotizacion::addCotizacionUbicacion($cotizacionid, $nombre,$usuarioid);
	    dtCotizacion::addCotizacionAccion($cotizacionid, "CREA UBICACIÓN", "Se agrega ubicación [".$nombre."] a la cotizacion", $usuarioid);
	    
	    echo json_encode($idUbica);
	    
	    $ubicacionid = $idUbica["ubicacionid"];
	    dtCotizacion::addCotizacionUbicacionAtributo($cotizacionid,$ubicacionid);
	    dtCotizacion::addCotizacionAccion($cotizacionid, "CREA ATRIBUTOS DE LA UBICACIÓN", "Se agregan los atributos de la ubicación [".$nombre."] a la cotizacion, esto hace el sistema de forma automatica", $usuarioid);
	    
	   
	    return $ubicacionid;
	}
	public static function editaCotizacionUbicacion($ubicacionid, $nombre, $usuarioid, $cotizacionid)
	{
	    dtCotizacion::editaCotizacionUbicacion($ubicacionid, $nombre,  $usuarioid);
	    dtCotizacion::addCotizacionAccion($cotizacionid, "MODIFICA DATOS DE LA UBICACIÓN", "Se modifican los datos de la ubicación [".$nombre."]", $usuarioid);
	}
	public static function getCotizacionUbicacion($cotizacionid)
	{
	    return dtCotizacion::getCotizacionUbicacion($cotizacionid);
	}
	public static function getCotizaciones()
	{
	    return dtCotizacion::getCotizaciones();
	}
	public static function getCoberturas()
	{
	    return dtCotizacion::getCoberturas();
	}
	public static function getCoberturasPorProductro($prodId)
	{
	    return dtCotizacion::getCoberturasPorProductro($prodId);
	}
	public static function getTipoCoberturas()
	{
	    return dtCotizacion::getTipoCoberturas();
	}
	public static function addCoberturaCotizacion($cotizacionid, $coberturaid, $sublimite, $tasaneta, $tasabruta, $primaneta, $primabruta)
	{
	    dtCotizacion::addCoberturaCotizacion($cotizacionid, $coberturaid, $sublimite, $tasaneta, $tasabruta, $primaneta, $primabruta);
	}
	public static function getCoberturasCotizacion($cotizacionid)
	{
	    return dtCotizacion::getCoberturasCotizacion($cotizacionid);
	}
	public static function addLimite($cotizacionid, $limite_poliza, $limite_todas_polizas_grupo)
	{
	    dtCotizacion::addLimite($cotizacionid, $limite_poliza, $limite_todas_polizas_grupo);
	}
	public static function volverReservaCotizacion($cotizacionid,$comentario,$usuarioid)
	{
	    dtCotizacion::addCotizacionAccion($cotizacionid, "VOLVER COTIZACIÓN A RESERVA", "Se Vuelve a dejar la cotización en el estado Reserva", $usuarioid);
	    dtCotizacion::addCotizacionEstado($cotizacionid, "RESERVA", $usuarioid, "La cotización #".$cotizacionid." se vuelve a dejar en el estado <strong>Reserva </strong>  <br /> Comentario del usuario\"".$comentario."\" ","NO");
	}
	public static function aprobarCotizacionToEnCurso($cotizacionid,$comentario,$usuarioid)
	{
	    dtCotizacion::addCotizacionAccion($cotizacionid, "SE APRUEBA COTIZACIÓN EN CURSO", "Se deja aprobada la cotización en el estado En Curso", $usuarioid);
	    dtCotizacion::addCotizacionEstado($cotizacionid, "EN CURSO", $usuarioid, "La cotización #".$cotizacionid." se deja en el estado <strong>En Curso</strong> pero desbloqueada para editar  <br /> Comentario del usuario\"".$comentario."\" ","NO");
	}
	public static function validaCotizacionEnReserva($cotizacionid,$usuarioid)
	{
	    $cot = negCotizacion::getCotizacionDetail($cotizacionid);
	    $contError = 0;
	    $mensaje = '<div class="alert alert-danger" role="alert">
												<strong>Error</strong> - La cotización presenta los siguientes errores.
					</div><hr/>';
	    $salida = "OK";
	    if($cot["aseguradoid"] == "" || $cot["aseguradoid"] == "0"){$contError++; $mensaje.= $contError."- Debe ingresar al asegurado <br />";}
	    if($cot["corredorid"] == "" || $cot["corredorid"] == "0"){$contError++; $mensaje.= $contError."- Debe ingresar al corredor <br />";}
	    if($cot["monedaid"] == ""){$contError++; $mensaje.= $contError."- Debe seleccionar la moneda de la cotización <br />";}
	    if($cot["vigenciadesde"] == null || $cot["vigenciadesde"] == "000-00-00"){$mensaje.= $contError."- Debe ingresar la vigencia desde <br />";}
	    if($cot["vigenciahasta"] == null || $cot["vigenciahasta"] == "000-00-00"){$mensaje.= $contError."- Debe ingresar la vigencia hasta <br />";}
	    if($cot["tipopoliza"] == "" || $cot["tipopoliza"] == "0"){$contError++; $mensaje.= $contError."- Debe seleccionar la característica de la póliza <br />";}
	    if($cot["ubicaciones"] == "" || $cot["ubicaciones"] == "0"){$contError++; $mensaje.= $contError."- Debe ingresar la cantidad de ubicaciones <br />";}
	    if(((float)$cot["comisionafecta"]+(float)$cot["comisionexcenta"]) == 0){$contError++; $mensaje.= $contError."- Debe ingresar la comisión del corredor <br />";}
	    if($cot["solicitud_corredor"] == ""){$contError++; $mensaje.= $contError."- Debe ingresar la solicitud del corredor <br />";}
	    
	    if($cot["fecha_recepcion"] == null || $cot["fecha_recepcion"] == "000-00-00"){$mensaje.= $contError."- Debe ingresar la fecha de recepción <br />";}
	    if($cot["fecha_entrega"] == null || $cot["fecha_entrega"] == "000-00-00"){$mensaje.= $contError."- Debe ingresar la fecha de entrega <br />";}
	    
	    if($cot["lineanegocioid"] == "" || $cot["lineanegocioid"] == "0"){$contError++; $mensaje.= $contError."- Debe ingresar la linea de negocio <br />";}
	    if($cot["ramoid"] == "" || $cot["ramoid"] == "0"){$contError++; $mensaje.= $contError."- Debe ingresar el ramo <br />";}
	    if($cot["productoid"] == "" || $cot["productoid"] == "0"){$contError++; $mensaje.= $contError."- Debe ingresar el producto <br />";}
	    if($cot["ejecutivoid"] == "" || $cot["ejecutivoid"] == "0"){$contError++; $mensaje.= $contError."- Debe indicar el ejecutivo asociado a la cotización <br />";}
	    
	    
	     $ubicaciones = negCotizacion::getCotizacionUbicacion($cotizacionid);
	    if(count($ubicaciones) == 0){{$contError++; $mensaje.= $contError."- Debe seleccionar agregar al menos 1 ubicación <br />";}}
	    if(count($ubicaciones) != (float)$cot["ubicaciones"] ){{$contError++; $mensaje.= $contError."- Se ha indicado que la cotización debe tener [".$cot["ubicaciones"]."] ubicaciones, y tiene configuradas [".count($ubicaciones)."], por favor configura la misma cantidad de ubicaciones declaras en la cotización <br />";}}
	    
	    
	    
	    
	    if($contError > 0)
	    {
	        $salida = $mensaje;
	    }
	    else{
	        
	        $bloqueo = self::validaBloqueoCotizacionEnReserva($cotizacionid);
	        $bloq = "";
	        $ms_bloq = "";
	        if($bloqueo == "OK"){$bloq = ""; }else{ $bloq = "SI"; $ms_bloq = $bloqueo;}
	        
	        dtCotizacion::addCotizacionAccion($cotizacionid, "COTIZACIÓN EN CURSO", "Se deja la cotización en el estado En Curso", $usuarioid);
	        dtCotizacion::addCotizacionEstado($cotizacionid, "EN CURSO", $usuarioid, "La cotización #".$cotizacionid." se encunetra en estado <strong>En Curso</strong>  <br /> ".$ms_bloq." ",$bloq);
	        
	    }
	    return $salida;
	     
	     
	}
	
	public static function validaCotizacionYAdjudica($cotizacionid,$usuarioid)
	{
	    $cot = negCotizacion::getCotizacionDetail($cotizacionid);
	    $contError = 0;
	    $mensaje = '<div class="alert alert-danger" role="alert">
												<strong>Error</strong> - La cotización presenta los siguientes errores.
					</div><hr/>';
	    $salida = "OK";
	    if($cot["aseguradoid"] == "" || $cot["aseguradoid"] == "0"){$contError++; $mensaje.= $contError."- Debe ingresar al asegurado <br />";}
	    if($cot["corredorid"] == "" || $cot["corredorid"] == "0"){$contError++; $mensaje.= $contError."- Debe ingresar al corredor <br />";}
	    if($cot["monedaid"] == ""){$contError++; $mensaje.= $contError."- Debe seleccionar la moneda de la cotización <br />";}
	    if($cot["vigenciadesde"] == null || $cot["vigenciadesde"] == "000-00-00"){$mensaje.= $contError."- Debe ingresar la vigencia desde <br />";}
	    if($cot["vigenciahasta"] == null || $cot["vigenciahasta"] == "000-00-00"){$mensaje.= $contError."- Debe ingresar la vigencia hasta <br />";}
	    if($cot["tipopoliza"] == "" || $cot["tipopoliza"] == "0"){$contError++; $mensaje.= $contError."- Debe seleccionar la característica de la póliza <br />";}
	    if($cot["ubicaciones"] == "" || $cot["ubicaciones"] == "0"){$contError++; $mensaje.= $contError."- Debe ingresar la cantidad de ubicaciones <br />";}
	    if(((float)$cot["comisionafecta"]+(float)$cot["comisionexcenta"]) == 0){$contError++; $mensaje.= $contError."- Debe ingresar la comisión del corredor <br />";}
	    if($cot["solicitud_corredor"] == ""){$contError++; $mensaje.= $contError."- Debe ingresar la solicitud del corredor <br />";}
	    
	    if($cot["fecha_recepcion"] == null || $cot["fecha_recepcion"] == "000-00-00"){$mensaje.= $contError."- Debe ingresar la fecha de recepción <br />";}
	    if($cot["fecha_entrega"] == null || $cot["fecha_entrega"] == "000-00-00"){$mensaje.= $contError."- Debe ingresar la fecha de entrega <br />";}
	    
	    if($cot["lineanegocioid"] == "" || $cot["lineanegocioid"] == "0"){$contError++; $mensaje.= $contError."- Debe ingresar la linea de negocio <br />";}
	    if($cot["ramoid"] == "" || $cot["ramoid"] == "0"){$contError++; $mensaje.= $contError."- Debe ingresar el ramo <br />";}
	    if($cot["productoid"] == "" || $cot["productoid"] == "0"){$contError++; $mensaje.= $contError."- Debe ingresar el producto <br />";}
	    if($cot["ejecutivoid"] == "" || $cot["ejecutivoid"] == "0"){$contError++; $mensaje.= $contError."- Debe indicar el ejecutivo asociado a la cotización <br />";}
	    
	    $ubicaciones = negCotizacion::getCotizacionUbicacion($cotizacionid);
	    if(count($ubicaciones) == 0){{$contError++; $mensaje.= $contError."- Debe seleccionar agregar al menos 1 ubicación <br />";}}
	    if(count($ubicaciones) != (float)$cot["ubicaciones"] ){{$contError++; $mensaje.= $contError."- Se ha indicado que la cotización debe tener [".$cot["ubicaciones"]."] ubicaciones, y tiene configuradas [".count($ubicaciones)."], por favor configura la misma cantidad de ubicaciones declaras en la cotización <br />";}}
	    /*
	    $coberturas = negCotizacion::getCoberturasCotizacion($cotizacionid);
	    if(count($coberturas) == 0){{$contError++; $mensaje.= $contError."- Debe configurar al menos 1 cobertura <br />";}}
	    */
	    if($contError > 0)
	    {
	        $salida = $mensaje;
	    }
	    else{
	        $bloq = "NO";
	        
	        dtCotizacion::addCotizacionAccion($cotizacionid, "COTIZACIÓN ADJUDICADA", "La cotización fue adjudicada", $usuarioid);
	        dtCotizacion::addCotizacionEstado($cotizacionid, "ADJUDICADA", $usuarioid, "La cotización #".$cotizacionid." se deja <strong>Adjudicada</strong>  <br /> ",$bloq);
	        
	    }
	    return $salida;
	    
	    
	}
	public static function alertasCotizacionEnReserva($cotizacionid)
	{
	    $cot = negCotizacion::getCotizacionDetail($cotizacionid);
	    $contError = 0;
	    $mensaje = '<div class="alert alert-warning" role="alert">
												<strong>Información</strong> - Hemos detectado que no se han ingresado una serie de datos, que si bien no condicionan la creación de la cotización, le queremos informar que todos estos son los datos que usted no ha configurado. <hr/>
					';
	    $salida = "OK";
	  
	    if((float)$cot["limite_poliza"] == 0){$contError++; $mensaje.= $contError."- No ha ingresado limite de la poliza (Monto) <br />";}
	    
	    if((float)$cot["limite_todas_polizas"] == 0){$contError++; $mensaje.= $contError."- No ha ingresado el Limite todas las Polizas del Grupo (Monto) <br />";}
	    if((float)$cot["deducible_incendio"] == 0){$contError++; $mensaje.= $contError."- No ha ingresado el Deducible Incendio (%)  <br />";}
	    if((float)$cot["min_deducible_incendio"] == 0){$contError++; $mensaje.= $contError."- No ha ingresado el Min Deducible Incendio (Monto) <br />";}
	    if((float)$cot["deducible_sismo"] == 0){$contError++; $mensaje.= $contError."- No ha ingresado el Deducible Sismo (%) <br />";}
	    if((float)$cot["min_deducible_sismo"] == 0){$contError++; $mensaje.= $contError."- No ha ingresado el Min Deducible Sismo (Monto) <br />";}
	    if((float)$cot["periodo_indemnizable_pxp"] == 0){$contError++; $mensaje.= $contError."- No ha ingresado el Periodo Indemnizable PxP (Meses) <br />";}
	    if((float)$cot["deducible_pxp"] == 0){$contError++; $mensaje.= $contError."- No ha ingresado el Deducible PxP (Wating Period) (días) <br />";}
	    if((float)$cot["sublimite_averia_maquinaria"] == 0){$contError++; $mensaje.= $contError."- No ha ingresado el Sublimite Avería de Maquinaria (Monto) <br />";}
	    
	    if($contError > 0)
	    {
	        $mensaje.= '</div>';
	        $salida = $mensaje;
	    }
	    return $salida;
	  
	    
	}
	
	public static function validaBloqueoCotizacionEnReserva($cotizacionid)
	{
	    $cot = negCotizacion::getCotizacionDetail($cotizacionid);
	    $condBloqueo =  negSistema::getCondicionesBloqueo();
	    $contError = 0;
	    $mensaje = '<div class="alert alert-primary" role="alert">
												<strong>Importante</strong> - La cotización quedará a la espera de aprobación ya que encontramos los siguientes problemas. <hr/>
					';
	    $salida = "OK";
	    $ubicaciones = negCotizacion::getCotizacionUbicacion($cotizacionid);
	    
	    foreach ($ubicaciones as $u)
	    {
	        //PENDIENTE VALIDACIONES COMERCIALES
	        /*
	        $msjAlert = util::getCondicionBloqueo($condBloqueo,"MONTO TIV",$cot["monedaid"],$u["total"]);
	        if($msjAlert != "")
	        {
	            $contError++; $mensaje.= $contError."- Para la ubicación [".$u["nombre"]."] - ".$msjAlert." <br />";
	        }
	        */
	    }
	    
	    if($contError > 0)
	    {
	        $mensaje.= '</div>';
	        $salida = $mensaje;
	    }
	    return $salida;
	}
	public static function pintaProcesoCotizacion($cotizacionid,$aprobacion,$adjudicacion='NO')
	{
	    $cotEs =negCotizacion::getCotizacionEstadoEnProceso($cotizacionid);
	    $estados = negCotizacion::getCotizacionEstadoDef();
	    $salida = '<div class="col-md-8 float-right" >
                		<div class="color-controls-1  float-right">
                			<div class="btn-group btn-group-toggle btn-group-custom-radio simplefilter color-controls-1" data-toggle="buttons">';
	    if($cotEs["estado"] !=""){
	    foreach ($estados as $e)
	    {
	        if($e["tipo"]== "normal")
	        {
	            $active = 'btn-secondary color-controls-1';
	            if($cotEs["estado"] == $e["estado"])
	            {
	                $active = 'btn-success color-controls-1 active';
	            }
	            $salida .= '    <label class="btn btn-sm '.$active.'">
                					 '.$e["estado"].'
                				</label>';
	        }
	        
	    }
	    
	    if($cotEs["bloqueo"] == "SI" && $aprobacion=="NO")
	    {
	        //REDIRECCIONA COTIZACION A PAGINA DE APROBACIÓN
	        $url = util::creaURLApp(1, "aprueba_cotizacion","&cotizacionid=".$cotizacionid);
	        
	        echo '
                <script type="text/javascript">
                    goto(\''.$url.'\');
                </script>
            ';
	        //exit(header('Location: ' . $url, true, 301));
	        
	    }
	    
	    if($cotEs["estado"] == "ADJUDICADA" && $adjudicacion =='NO' )
	    {
	        //REDIRECCIONA COTIZACION A PAGINA DE APROBACIÓN
	        $url = util::creaURLApp(1, "adjudicada_cotizacion","&cotizacionid=".$cotizacionid);
	       
	        echo '
                <script type="text/javascript">
                    goto(\''.$url.'\');
                </script>
            ';
	        
	        //exit(header('Location: ' . $url, true, 301));
	        
	    }
	    
	    
	    $salida.= '		</div>
                		</div>
                	</div>';
	    }else{
	        echo '
                <script type="text/javascript">
                   
                </script>
            ';
	        $salida.= '		</div>
                		</div>
                	</div>';
	        
	    }
	    return $salida;
	}
	
	public static function getCotizacionEstadoDef()
	{
	    return dtCotizacion::getCotizacionEstadoDef();
	}
	public static function getCotizacionEstadoEnProceso($cotizacionid)
	{
	    return dtCotizacion::getCotizacionEstadoEnProceso($cotizacionid);
	}
	public static function getCotizacionAccion($cotizacionid)
	{
	    return dtCotizacion::getCotizacionAccion($cotizacionid);
	
	}
	public static function getDeducibleDef()
	{
	    return dtCotizacion::getDeducibleDef();
	}
	public static function getCotizacionDeducible($cotizacionid)
	{
	    return dtCotizacion::getCotizacionDeducible($cotizacionid);
	}
	public static function getTipoCobAdicionalesSublimite()
	{
	    return dtCotizacion::getTipoCobAdicionalesSublimite();
	}
	public static function getCobAdicionalesSublimites()
	{
	    return dtCotizacion::getCobAdicionalesSublimites();
	}
	public static function getCobAdicionalesSublimitesByProducto($productoid)
	{
	    return dtCotizacion::getCobAdicionalesSublimitesByProducto($productoid);
	}
	public static function getgetCobAdicionalesSublimitesCotizacion($cotizacionid)
	{
	    return dtCotizacion::getgetCobAdicionalesSublimitesCotizacion($cotizacionid);
	}
	public static function getMateriasPorCotiSeccion($cotizacionid)
	{
	    return dtCotizacion::getMateriasPorCotiSeccion($cotizacionid);
	}
	public static function getProductosXramoYln($ramo,$ln){
	    $prod = dtCotizacion::getProductosXramoYln($ramo,$ln);
	    
	    
	    $objAnterior;
	    $prodAnterior = "";
	    $arr = array();
	    $cont = 0;
	    foreach ($prod as $p)
	    {
	        $cont++;
	        if($p["producto"] != $prodAnterior && $prodAnterior != "")
	        {
	            $arr[] = $objAnterior;
	        }
	        $objAnterior  = $p;
	        $prodAnterior = $p["producto"];
	    }
	    
	    if($cont > 0)
	    {
	        $arr[] = $objAnterior;
	    }
	    return $arr;
	    
	    
	    
	}
	public static function getRamoyLineaXproducto($productoid){
	    return dtCotizacion::getRamoyLineaXproducto($productoid);
	}
	public static function getCantUbicacionesPorCotiId($cotizacionid)
	{
	    return dtCotizacion::getCantUbicacionesPorCotiId($cotizacionid);
	}
	public static function getSiniestralidadXcotizacionid($cotizacionid){
        	return dtCotizacion::getSiniestralidadXcotizacionid($cotizacionid);
	}
	public static function editSiniestralidad($cotizacionsiniestralidadid,$prima,$tiv,$nro_reclamo,$pagado,$pendiente,$gastos_honorarios)
	{
	        dtCotizacion::editSiniestralidad($cotizacionsiniestralidadid,$prima,$tiv,$nro_reclamo,$pagado,$pendiente,$gastos_honorarios);
	}
	public static function getUbicacionesByCotizacion($cotizacionid)
	{
	    return dtCotizacion::getUbicacionesByCotizacion($cotizacionid);
	}
	public static function getIdUbicacion($cotizacionid)
	{
	    return dtCotizacion::getIdUbicacion($cotizacionid);
	}
	public static function getUbicacionDetalle($ubicacionid)
	{
	    return dtCotizacion::getUbicacionDetalle($ubicacionid);
	}
	public static function getEstadoCotizaciones()
	{
	    return dtCotizacion::getEstadoCotizaciones();
	}
	/*public static function getUltimaUbicacion($cotizacionid)
	{
	    return dtCotizacion::getCotizacionDetail($cotizacionid);
	}*/
	public static function addSiniestralidadCotizacion($cotizacionid,$ultimo_anio,$nro_anios){
        $dato_compara = ($ultimo_anio - $nro_anios);
        $anio = "";
        $vigencia = "";
        dtCotizacion::deleteSiniestralidadCotizacion($cotizacionid);
	        for($i=(int)$ultimo_anio; $i>(int)$dato_compara; $i--)
		{
	           $anio = $i;
	           $vigencia = ($i-1)."/".$i;
	           dtCotizacion::addSiniestralidadCotizacion($cotizacionid,$vigencia);
        	}
	}
	
	public static function getCotizacionSecciones($cotizacionid)
	{
	    return dtCotizacion::getCotizacionSecciones($cotizacionid);
	}
	public static function addCotizacionUbicacionMateria($cotizacionid,$ubicacionid,$materiaid)
	{
	    
	    //Se debe ir a obtener el tipo
	    $tipo = '';
	    return dtCotizacion::addCotizacionUbicacionMateria($cotizacionid,$ubicacionid,$materiaid,$tipo);
	}
	
	public static function getCotizacionUbicacionMateria($cotizacionid,$ubicacionid)
	{
	    return dtCotizacion::getCotizacionUbicacionMateria($cotizacionid,$ubicacionid);
	}
	public static function deleteCotizacionUbicacionMateria($cotizacionid,$ubicacionid,$materiaid)
	{  
	    return dtCotizacion::deleteCotizacionUbicacionMateria($cotizacionid,$ubicacionid,$materiaid);
	}
	public static function saveMontoMateriaUbicacion($cotizacionid,$ubicacionid,$materiaid,$monto)
	{
	    
	     dtCotizacion::saveMontoMateriaUbicacion($cotizacionid,$ubicacionid,$materiaid,$monto);
	     self::saveFactoresMontosCotizacion($cotizacionid,$ubicacionid);
	}
	public static function getProductosByDeducible($deducibleid)
	{
	    return dtCotizacion::getProductosByDeducible($deducibleid);
	}
	public static function getProductosDisponibleByDeducible($deducibleid)
	{
	    return dtCotizacion::getProductosDisponibleByDeducible($deducibleid);
	}
	public static function addProductosDisponibleByDeducible($deducibleid,$productoid)
	{
	    return dtCotizacion::addProductosDisponibleByDeducible($deducibleid,$productoid);
	}
	public static function elminaProductosDisponibleByDeducible($deducibleid,$productoid)
	{
	    return dtCotizacion::elminaProductosDisponibleByDeducible($deducibleid,$productoid);
	}
	public static function getDeducibleDefByProducto($productoid)
	{
	    return dtCotizacion::getDeducibleDefByProducto($productoid);
	}
	public static function setCobAdicionSublmitePorProducto($sublimiteid,$productoid)
	{
	    return dtCotizacion::setCobAdicionSublmitePorProducto($sublimiteid,$productoid);
	}
	public static function eliminaCobAdicionSublmitePorProducto($sublimiteid,$productoid)
	{
	    return dtCotizacion::eliminaCobAdicionSublmitePorProducto($sublimiteid,$productoid);
	}
	public static function getProductoSublmitePorProducto($sublimiteid)
	{
	    return dtCotizacion::getProductoSublmitePorProducto($sublimiteid);
	}
	public static function getProductoSublmitePorProductoDisponible($sublimiteid)
	{
	    return dtCotizacion::getProductoSublmitePorProductoDisponible($sublimiteid);
	}
	public static function addCOmentariosCotizacionSiniestralidad($cotizacionid,$comentario_prima,$comentario_siniestral)
	{
	    return dtCotizacion::addCOmentariosCotizacionSiniestralidad($cotizacionid,$comentario_prima,$comentario_siniestral);
	}
	public static function getSistemawordingposicion()
	{
	    return dtCotizacion::getSistemawordingposicion();
	}
	public static function addWordingLibre($cotizacionid,$detalle_wording_add,$posicionid_wl)
	{
	    return dtCotizacion::addWordingLibre($cotizacionid,$detalle_wording_add,$posicionid_wl);
	}
	public static function addWordingTemplate($cotizacionid,$wordingid,$posicionid,$detalle_wording_add)
	{
	    return dtCotizacion::addWordingTemplate($cotizacionid,$wordingid,$posicionid,$detalle_wording_add);
	}
	public static function getWordingCotizacion($cotizacionid)
	{
	    return dtCotizacion::getWordingCotizacion($cotizacionid);
	}
	public static function getWordingCotizacionByWording($cotizacionwordingid)
	{
	    $wording = dtCotizacion::getWordingCotizacionByWording($cotizacionwordingid);
	    $tag = dtCotizacion::getTagCotizacionWorking($cotizacionwordingid);
	    
	    if($wording["tipo"] == "TEMPLATE")
	    {
	        foreach ($tag as $t)
	        {
	            $variable  = $t["variable"];
	            $valor     = $t["valor"];
	            $wording["wording"] = str_replace($variable, $valor, $wording["wording"]) ;
	        }
	        
	    }
	    
	    return $wording;
	}
	public static function editaWordingCotizacion($cotizacionwordingid,$wording)
	{
	    return dtCotizacion::editaWordingCotizacion($cotizacionwordingid,$wording);
	}
	public static function eliminaWordingCotizacion($cotizacionwordingid)
	{
	    dtCotizacion::eliminaWordingCotizacion($cotizacionwordingid);
	}
	public static function getWordingByProducto($productoid)
	{
	    return dtCotizacion::getWordingByProducto($productoid);
	}
	public static function addTagCotizacionWorking($cotizacionwordingid,$tag_var,$tagid,$variable)
	{
	    return dtCotizacion::addTagCotizacionWorking($cotizacionwordingid,$tag_var,$tagid,$variable);
	}
	public static function getTipoDocumento()
	{
	    return dtCotizacion::getTipoDocumento();
	}
	public static function getUrlIntegracionCliente($nombre,$rut)
	{
	    
	    $nombre = urlencode($nombre);
	    $rut = urlencode($rut);
	    
	    $integracion = 'get_cliente';
	    $url = dtAsegurado::getUrlIntegracionCliente($integracion);
	    
	    if ($nombre != "NULL")
	    {
	        $url["url"] .= "/NULL/".$nombre;
	    }
	    else 
	     {
	         $url["url"] .= "/".$rut."/NULL";
	     }
	     
	     
	    return $url;
	}
	public static function getUrlIntegracionCorredor($nombre,$rut)
	{
	    $integracion = 'get_corredor';
	    $nombre = urlencode($nombre);
	    $rut = urlencode($rut);
	    
	    $url = dtCorredor::getUrlIntegracionCorredor($integracion);
	    
	    if ($nombre != "NULL")
	    {
	        $url["url"] .= "/NULL/".$nombre;
	    }
	    else
	    {
	        $url["url"] .= "/".$rut."/NULL";
	    }
	    return $url;
	}
	public static function CantidadTipoDocumentos()
	{
	    return dtCotizacion::CantidadTipoDocumentos();
	}
	public static function GuardarDirectorioDocumento($tipo_documento,$PathCompleto,$cotizacionid,$nombre_file,$descripcion)
	{
	    return dtCotizacion::GuardarDirectorioDocumento($tipo_documento,$PathCompleto,$cotizacionid,$nombre_file,$descripcion);
	}
	public static function getDirectorio($cotizacionid)
	{
	    return dtCotizacion::getDirectorio($cotizacionid);
	}
	public static function eliminaDirectorio($iddirectorio)
	{
	    dtCotizacion::eliminaDirectorio($iddirectorio);
	}
	public static function getCoberturasDispByCotizacion($cotizacionid)
	{
	    $cobExt = negCotizacion::getCoberturasByCotizacion($cotizacionid);
	    
	    $cob = dtCotizacion::getCoberturasDispByCotizacion($cotizacionid);
	    
	    $objAnterior;
	    $cobAnterior = "";
	    $cobCodAnt = "";
	    $arr = array();
	    $cont = 0;
	    foreach ($cob as $p)
	    {
	        $pint = 'SI';
	        $cont++;
	        if( ($p["r_codigo_cobertura"] != $cobCodAnt && $cobCodAnt != "") && ($p["cobertura"] != $cobAnterior && $cobAnterior != "") )
	        {
	            foreach($cobExt as $ce)
	            {
	                if($ce["r_codigo_cobertura"] == $cobCodAnt )
	                {
	                    $pint = 'NO';
	                }
	            }
	            
	            if($pint == 'SI')
	            {
	                $arr[] = $objAnterior;
	            }   
	            
	        }
	        $objAnterior  = $p;
	        $cobAnterior = $p["cobertura"];
	        $cobCodAnt = $p["r_codigo_cobertura"];
	    }
	    
	    if($cont > 0)
	    {
	        $pint = 'SI';
	        
	        foreach($cobExt as $ce)
	        {
    	        if($ce["r_codigo_cobertura"] == $cobCodAnt )
    	        {
    	            $pint = 'NO';
    	        }
	        }
	        if($pint == 'SI')
	        {
	            $arr[] = $objAnterior;
	        }   
	        
	    }
	    return $arr;
	}
	public static function getCoberturasByCotizacion($cotizacionid)
	{
	    return dtCotizacion::getCoberturasByCotizacion($cotizacionid);
	}
	public static function getDirectorioByid($iddirectorio)
	{
	    return dtCotizacion::getDirectorioByid($iddirectorio);
	}
	public static function getEjecutivos()
	{
        	return dtCotizacion::getEjecutivoUsuario();
    }
	public static function addNotaCotizacion($cotizacionid,$nota,$usuarioid)
	{
	    return dtCotizacion::addNotaCotizacion($cotizacionid,$nota,$usuarioid);
	}
	public static function getNotasCotizacion($cotizacionid)
	{
	    return dtCotizacion::getNotasCotizacion($cotizacionid);
	}
	
	public static function addCoaseguroToCotizacion($cotizacionid,$coaseguro,$tc,$pc)
	{
	    
	    if($pc == ""){$pc = 0;}else{$pc=str_replace(".", "", $pc);$pc=str_replace(",", ".", $pc);}
	    
	    if($coaseguro == "NO")
	    {
	        //ELIMINA TODOS LOS PARTICIPANTES DEL COASEGURO DE LA COTIZACION
	        dtCotizacion::eliminaCoaseguradorAllCotizacion($cotizacionid);
	    }else
	    {
	        if($tc=='L')
	        {
	            dtCotizacion::eliminaTipoCoaseguradorAllCotizacion($cotizacionid,"PARICIPANTE");
	        }
	    }
	    
	    return dtCotizacion::addCoaseguroToCotizacion($cotizacionid,$coaseguro,$tc,$pc);
	}
	public static function addCoaseguroParticipanteToCotizacion($cotizacionid,$coaseguradorid)
	{
	    dtCotizacion::addCoaseguroParticipanteToCotizacion($cotizacionid,$coaseguradorid);
	}
	public static function getCoasegurosDisponiblesByCotizacion($cotizacionid)
	{
	    return dtCotizacion::getCoasegurosDisponiblesByCotizacion($cotizacionid);
	}
	public static function getCoasegurosByCotizacion($cotizacionid)
	{
	    return dtCotizacion::getCoasegurosByCotizacion($cotizacionid);
	}
	public static function getCoaseguroCOnfigByCotizacion($cotizacionid)
	{
	    return dtCotizacion::getCoaseguroCOnfigByCotizacion($cotizacionid);
	}
	public static function eliminaCoaseguradorCotizacion($cotizacionid,$coaseguradorid)
	{
	    return dtCotizacion::eliminaCoaseguradorCotizacion($cotizacionid,$coaseguradorid);
	}
	public static function addCoaseguroParticipePorcCotizacion($cotizacionid,$coaseguradorid,$pc)
	{   
	    if($pc == ""){$pc = 0;}
	    return dtCotizacion::addCoaseguroParticipePorcCotizacion($cotizacionid,$coaseguradorid,$pc);
	}
	public static function saveParticipacionCoasegurador($cotizacionid,$coaseguradorid,$tipo)
	{
	    return dtCotizacion::saveParticipacionCoasegurador($cotizacionid,$coaseguradorid,$tipo);
	}
	public static function saveTipoMateriaUbicacion($cotizacionid,$materiaid,$tipo,$ubicacionid)
	{
	    return dtCotizacion::saveTipoMateriaUbicacion($cotizacionid,$materiaid,$tipo,$ubicacionid);
	}
	public static function getMisCotizaciones()
	{
	    return dtCotizacion::getMisCotizaciones();
	}
	public static function getMisCotizacionesEnCurso()
	{
	    return dtCotizacion::getMisCotizacionesEnCurso();
	}
	public static function eliminaUbicacionCotizacion($cotizacionid,$ubicacionid)
	{
	    
	    $materias = negCotizacion::getCotizacionUbicacionMateria($cotizacionid,$ubicacionid);
	    foreach($materias as $m)
	    {
	        $materiaid = $m["materiaid"];
	        negCotizacion::deleteCotizacionUbicacionMateria($cotizacionid,$ubicacionid,$materiaid);
	    }
	    
	    dtCotizacion::eliminaUbicacionCotizacion($cotizacionid,$ubicacionid);
	}
	/****
	 * Pinta atributos en la vista html del formulario
	 * @param int $cotizacionid
	 * @param int $ubicacionid
	 */
	public static function setHTMLAtributosByUbicacion($cotizacionid, $ubicacionid)
	{
	    $html = '';
	    $atributos = self::getAtributosByUbicacion($cotizacionid, $ubicacionid);
	    
	    foreach ($atributos as $a)
	    {
	        $tipo  = $a["tipo"];
	        $ob    = '';
	        $valor = $a["valor"];
	    
	        if($a["obligatorio"] == 'SI')
	        {
	            $ob = '<strong><span style="color:red;" >* </span></strong>';
	        }
	        
	        switch ($tipo) {
	            case "direccion":
                    $dir = "";
                    $com = "";
	                if($valor != "")
	                {
	                    $arr = explode("|", $valor);
	                    $dir = $arr[0];
	                    $com = $arr[1];
	                    
	                }
	                $html .= '<div  class="row" style="border: 1px solid #d2d2d2; padding:10px;margin-left: 15px;margin-right: 15px;width: 100%;    margin-bottom: 15px;">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="nombre">'.$ob.' <strong> DIRECCIÓN </strong></label>
                                        <input type="text"  value="'.$dir.'" class="form-control" class="form-control" id="direccion_'.$ubicacionid.'" name="direccion_'.$ubicacionid.'" placeholder="" onchange="saveAttr_'.$ubicacionid.'('.$ubicacionid.',\''.$tipo.'\','.$a["atributoid"].')">
                                    </div>
                                  </div>
                                  <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="nombre">Comuna</label>
                                        <select class="form-control" id="comuna_'.$ubicacionid.'" name="comuna_'.$ubicacionid.'" style="font-family: monospace;" onchange="saveAttr_'.$ubicacionid.'('.$ubicacionid.',\''.$tipo.'\','.$a["atributoid"].')">
                                            <option value="0">-- SELECICONE --</option>';
	                                        $comunas = negSistema::getComunasAllDetalle();
                        	                foreach ($comunas as $c) {
                        	                    $sel = '';
                        	                    if($com == $c["id_comuna"])
                        	                    {
                        	                        $sel = ' SELECTED="SELECTED" ';
                        	                    }
                        	                    $html.='<option '.$sel.' value="'.$c["id_comuna"].'">'.strtoupper($c["id_comuna"]).'</option>';
                        	                }
	                $html.='
                                        </select>
                                    </div>
                                  </div>
             		              <div class="col-md-6">
                        			<div class="form-group">
                        				<label for="nombre"> Ciudad</label> 
                        					<input style="text-decoration: none; color: black;" type="text" disabled="disabled" class="form-control" id="ciudad_sh_'.$ubicacionid.'" name="ciudad_sh" placeholder=""> 
                        					<input type="hidden" class="form-control" id="ciudad_'.$ubicacionid.'" name="ciudad" placeholder="">
                        			</div>
                        		  </div>
                                  <div class="col-md-6">
                        			<div class="form-group">
                        				<label for="nombre"> Region</label> 
                        					<input style="text-decoration: none; color: black;" type="text" disabled="disabled" class="form-control" id="region_sh_'.$ubicacionid.'" name="region_sh" placeholder=""> 
                        					<input type="hidden" class="form-control" id="region_'.$ubicacionid.'" name="ciudad" placeholder="">
                        			</div>
                        		  </div>
                                </div>

                                
                              ';
	                
	            break;
	            case "input":
	                
	                $html.= '<div class="col-md-6">
	                			<div class="form-group">
	                				<label for="nombre">'.$ob.''.$a["atributo"].'</label> 
	                					<input type="text" class="form-control" value="'.$valor.'" class="form-control" id="attr_'.$a["atributoid"].'_'.$ubicacionid.'" name="attr_'.$a["atributoid"].'_'.$ubicacionid.'" onchange="saveAttr_'.$ubicacionid.'('.$ubicacionid.',\''.$tipo.'\','.$a["atributoid"].')">
	                			</div>
	                		</div>';
	            break;
	            case "annio":
	                $html.= '<div class="col-md-6">
	                			<div class="form-group">
	                				<label for="nombre">'.$ob.''.$a["atributo"].'</label>
	                					<input type="text" class="form-control" value="'.$valor.'" class="form-control" id="attr_'.$a["atributoid"].'_'.$ubicacionid.'" name="attr_'.$a["atributoid"].'_'.$ubicacionid.'" onchange="saveAttr_'.$ubicacionid.'('.$ubicacionid.',\''.$tipo.'\','.$a["atributoid"].')">
	                			</div>
	                		</div>';
	                break;
	            case "numero":
	                if($valor!="")
	                {
	                   $valor = number_format($valor,0,",",".");
	                }
	                $html.= '<div class="col-md-6">
	                			<div class="form-group">
	                				<label for="nombre">'.$ob.''.$a["atributo"].'</label>
	                					<input type="text" class="form-control" value="'.$valor.'" class="form-control" id="attr_'.$a["atributoid"].'_'.$ubicacionid.'" name="attr_'.$a["atributoid"].'_'.$ubicacionid.'" onchange="saveAttr_'.$ubicacionid.'('.$ubicacionid.',\''.$tipo.'\','.$a["atributoid"].')">
	                			</div>
	                		</div>';
	                break;
	            case "decimal":
	                if($valor!="")
	                {
	                   $valor = number_format($valor,4,",",".");
	                }
	                $html.= '<div class="col-md-6">
	                			<div class="form-group">
	                				<label for="nombre">'.$ob.''.$a["atributo"].'</label>
	                					<input type="text" class="form-control" value="'.$valor.'" class="form-control" id="attr_'.$a["atributoid"].'_'.$ubicacionid.'" name="attr_'.$a["atributoid"].'_'.$ubicacionid.'" onchange="saveAttr_'.$ubicacionid.'('.$ubicacionid.',\''.$tipo.'\','.$a["atributoid"].')">
	                			</div>
	                		</div>';
	                break;
	            case "lista":
	                
	                $html.= '<div class="col-md-6">
	                			<div class="form-group">
	                				<label for="nombre">'.$ob.''.$a["atributo"].'</label>
                                        <select class="form-control" id="attr_'.$a["atributoid"].'_'.$ubicacionid.'" name="attr_'.$a["atributoid"].'_'.$ubicacionid.'" onchange="saveAttr_'.$ubicacionid.'('.$ubicacionid.',\''.$tipo.'\','.$a["atributoid"].')" style="font-family: monospace;">
									       <option value="0">-- SELECICONE --</option>';
	                $valores = dtCotizacion::getSistemaFactorCustom("sistema_atributo_valor"," atributoid=".$a["atributoid"]." ");
	                foreach ($valores as $c) {
	                    $sel = "";
	                    if($valor == $c["atributovalorid"])
	                    {
	                        $sel = ' SELECTED="SELECTED" ';
	                    }
	                    $html.= '<option '.$sel.' value="'.$c["atributovalorid"].'">' . strtoupper($c["valor"]) . '</option>';
	                }
	                $html.= '	</select>
	                			</div>
	                		</div>';
	                
	                break;
	            case "lista_custom":
	                if($a["atributo"]=="SIC CODE")
	                {
	                    $siccodem = "";
	                    if($valor != "")
	                    {
	                        $sc = negSistema::getSicCodeDetail($valor);
	                       $siccodem = $sc["familia_3"];
	                    }
	                    $html .= '<div  class="row" style="border: 1px solid #d2d2d2; padding:10px;margin-left: 15px;margin-right: 15px;width: 100%;    margin-bottom: 15px;">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        	<label for="nombre">'.$ob.''.$a["atributo"].' <button type="button" class="btn btn-sm btn-primary waves-effect waves-light" data-toggle="modal" data-target="#mod_addSICCODE" data-backdrop="static" data-keyboard="false" onclick="buscaSC('.$ubicacionid.','.$a["atributoid"].')" >Buscar SIC CODE</button></label>
	                					    <input value="'.$siccodem.'" style="text-decoration: none; color: black;" type="text" disabled="disabled" class="form-control" id="sic_code_sh_'.$ubicacionid.'" name="sic_code_sh_'.$ubicacionid.'" placeholder="">
	                			    </div>
                                  </div>
                                </div>
                              ';
	                }else 
	                {
	                    $html.= '<div class="col-md-6">
	                			<div class="form-group">
	                				<label for="nombre">'.$ob.''.$a["atributo"].'</label>
                                        <select class="form-control" id="attr_'.$a["atributoid"].'_'.$ubicacionid.'" name="attr_'.$a["atributoid"].'_'.$ubicacionid.'" onchange="saveAttr_'.$ubicacionid.'('.$ubicacionid.',\''.$tipo.'\','.$a["atributoid"].')" style="font-family: monospace;">
									       <option value="0">-- SELECICONE --</option>';
	                                        $atd = self::getSistemaAtributoDetail($a["atributoid"]);
	                                        $valores = dtCotizacion::getSistemaFactorCustom($atd["tabla_valor"]," factorid=".$atd["factorid"]." ");
	                                        foreach ($valores as $c) {
	                                            $sel = "";
	                                            if($valor == $c["factorvalorid"])
	                                            {
	                                                $sel = ' SELECTED="SELECTED" ';
	                                            }
	                                            $html.= '<option '.$sel.' value="'.$c["factorvalorid"].'">' . strtoupper($c["valor_muestra_1"]) . '</option>';
                                            }
                       $html.= '	</select>                                         
	                			</div>
	                		</div>';
	                }
	                
	                
	                
	                break;
	                
	        }
	    }
	    
	    $html.='<script type="text/javascript">
                    function saveAttr_'.$ubicacionid.'(ubid,tipo,attid)
                    {
                        var cont_error = 0;
                        var valor=\'\';
                        if( tipo==\'direccion\')
                        {
                            valor = $("#direccion_"+ubid).val()+\'|\'+$("#comuna_"+ubid).val();
                            getUbicacionComunaEdita(ubid);
                        }else
                        {
                            valor = $("#attr_"+attid+"_"+ubid).val();
                        }
                        $("#attr").val(valor);
                        $("#attrid").val(attid);
                        $("#tipo").val(tipo);

                        if( tipo==\'annio\' || tipo==\'numero\')
                        {
                            if(validarSiNumero(valor)=="ERROR")
                            {
                                  mensajeAlerta("Error ","Debe ingresar solo valores numéricos<br />"); 
                                  $("#attr_"+attid+"_"+ubid).val("");
                                  cont_error++;     
                            }
                        }
                        if( tipo==\'decimal\')
                        {
                            valor = replaceAll(valor,".","");
                            if(validaNumeroDecimal(valor, ",")=="ERROR")
                    		{		
                    			mensajeAlerta("Error ","Debe ingresar valores numericos con decimales con el siguiente formato NNNN,DD (245899,98) <br />");
                    			$("#attr_"+attid+"_"+ubid).val("");
                                cont_error++; 
                    		}else
                            {
                                valor =  formatLatino(valor);
                                $("#attr").val(valor);
                                $("#attr_"+attid+"_"+ubid).val(valor);
                            }
                        }
                        

                        /*SE GUARDAN LOS DATOS*/
                        if( cont_error == 0)
                        {
                            mensaje("Guardar Cambios","El cambio se ha guardado correctamente<br />");
                            msjError = "Error 0002";
        					urlIn = "../c_srv/cotizacion.php";
        					formalioID = "frm_modifica_ubicacion_'.$ubicacionid.'";
        					srv="SAVEATTRTOUBICACION";
        					var urlEnv = getDataJsonSbm(urlIn,formalioID,srv,msjError);
			        

                        }                               
                    }
                </script>
                
                  ';
	    
	    return $html;
	}
	public static function getAtributosByUbicacion($cotizacionid, $ubicacionid)
	{
	    return dtCotizacion::getAtributosByUbicacion($cotizacionid, $ubicacionid);
	}
	public static function getSistemaAtributoDetail($atributoid)
	{
	    return dtCotizacion::getSistemaAtributoDetail($atributoid);
	}
	
	public static function saveFactoresMontosCotizacion($cotizacionid,$ubicacionid)
	{ 
	    $atributos = self::getAtributosByUbicacion($cotizacionid, $ubicacionid);
	    foreach ($atributos as $atd)
	    {
	        if($atd["factor_monto"]=="SI")
	        {
	            if($atd["atributoid"]=="20")//TIPO CONSTRUCCIÓN RMS
	            {
	                self::setFactorTipoConstruccion($cotizacionid,$ubicacionid,$atd);
	            }
	        }
	    }
	}
	public static function setFactorTipoConstruccion($cotizacionid,$ubicacionid,$atd)
	{
	    //1- Se debe ir a buscar el valor del atributo del tipo de construcción
	    $atv = dtCotizacion::getAtributoValorDetailByUbicacion($cotizacionid, $ubicacionid,$atd["atributoid"]);
	    $valor_compara_ad_1 =$atv["valor"];
	    //2- Se debe ir a buscar la comuna asociada a la ubicación
	    $atv = dtCotizacion::getAtributoDetailByUbicacion($cotizacionid, $ubicacionid,3);
	    if($atv["valor"] != "")
	    {
	        $arr = explode("|", $atv["valor"]);
	        $valor_compara_ad_2 = $arr[1];
	        
	        //3- Obtiene valor del monto de la ubicación
	        $mto = dtCotizacion::getMontoPrimaCotizacionUbicacionMateria($cotizacionid, $ubicacionid);
	        $valor_compara_1_2 = $mto["monto"];
	        
	        //SE GUARDA FACTOR PARA ESTE ATRIBUTO
	        dtCotizacion::saveFactorMatrixCotizacionUbicacion($cotizacionid,$ubicacionid,$atd["factorid"],$valor_compara_1_2,$valor_compara_ad_1,$valor_compara_ad_2);
	        
	    }
	}
	
	
	public static function saveAttrToUbicacion($cotizacionid,$ubicacionid,$attr,$attrid,$tipo)
	{   
	    if($tipo=="decimal")
	    {
	        $attr = str_replace(".", "_", $attr);
	        $attr = str_replace(",", ".", $attr);
	    }
	    dtCotizacion::saveAttrToUbicacion($cotizacionid,$ubicacionid,$attr,$attrid,$tipo);
	    
	    $atd = self::getSistemaAtributoDetail($attrid);
	    if($atd["factorid"]!="0")
	    {
	        $valor = $attr;
	        if($atd["tipo"]=="lista_custom")
	        {
	            $vb = $atd["valor_busqueda"]; 
	            $vm = $atd["valor_muestra"];
	            $filtro = " ".$vb."='".$valor."' ";
	            $v = dtCotizacion::getSistemaFactorCustomFiltro($atd["tabla_valor"],$filtro);
	            if($vm == "sic")
	            {
	                $valor = $v["sic"];
	            }else
	            {
	                $valor = $v["valor_compara_1"];
	            }
	        }
	        
	        if($atd["factor_tipo"]=="MATRIZ")//Atributo especial que maneja los factores en una matriz
	        {
	            if($atd["atributoid"]=="20")//TIPO CONSTRUCCIÓN RMS
	            {
	                
	                self::setFactorTipoConstruccion($cotizacionid,$ubicacionid,$atd);
	            }
	            
	        }else {
	        
	            //PARA TODOS SE GUARDAN LOS FACTORES
	            $valor_compara_1 = (int)$valor;
	            $valor_compara_2 = "0";
	            dtCotizacion::saveFactorCotizacionUbicacion($cotizacionid,$ubicacionid,$atd["factorid"],$valor_compara_1,$valor_compara_2);
	        }
	        
	        
	    }
	    if($atd["tipo"]=="direccion")//SETEA EL FACTOR POR MONTO ASOCIADO A LA COMUNA
	    {
	        self::saveFactoresMontosCotizacion($cotizacionid,$ubicacionid);
	    }
	}
	public static function addCotizacionDeducibleFijo($cotizacionid)
	{
	    dtCotizacion::addCotizacionDeducibleFijo($cotizacionid);
	}
	public static function getDeduciblesFijosByCotizacion($cotizacionid)
	{
	    return dtCotizacion::getDeduciblesFijosByCotizacion($cotizacionid);
	}
	public static function saveDeducibleFijoCotizacion($cotizacionid,$valor,$deduciblefijoid)
	{
	    dtCotizacion::saveDeducibleFijoCotizacion($cotizacionid,$valor,$deduciblefijoid);
	}
	public static function getTiposMateriaByCotrizacion($cotizacionid)
	{
	   return  dtCotizacion::getTiposMateriaByCotrizacion($cotizacionid);
	}
	public static function getTiposTasasByCotrizacion($cotizacionid)
	{
	    return  dtCotizacion::getTiposTasasByCotrizacion($cotizacionid);
	}
	public static function getTasaMotor($tasaid,$nombre,$cotizacionid)
	{
	    $tasa = 0;
	    $saveTC = "SI";
	    switch ($tasaid) {
	    case "1"://Tasa Afecta DM
	        $tasa = 1;
	        
	        $cobCotiza = negCotizacion::getgetCobAdicionalesSublimitesCotizacion($cotizacionid);
	        $primaneta  = 0;
	        foreach ($cobCotiza as $cc)
	        {
	            $primaneta = $primaneta + $cc["primaneta"];
	        }
	        
	        $cotiza = self::getCotizacionDetail($cotizacionid);
	        //Se obtiene TASA AFECTA
	        $taDM = 10;
	        
	        $factores = dtCotizacion::getSistemaFactorCustom("cotizacion_factor"," factorid in(1,2,3,4) ");
	        foreach ($factores as $c) {
	            $taDM = (float)$taDM*(float)$c["factor"];
	        }
	        
	        
	        //Se debe obtener el total de los montos para obtener las primas
	        $ubicaciones = self::getUbicacionesByCotizacion($cotizacionid);
	        $mtoDM  = 0; 
	        $mtoPxP = 0; 
	        foreach ($ubicaciones as $u)
	        {
	            $ubicacionid = $u["ubicacionid"];
	            $montos = self::getCotizacionUbicacionMateria($cotizacionid,$ubicacionid);
	            foreach ($montos as $m)
	            {
	                if($m["tipo"] == "1")
	                {
	                    $mtoDM = (float)$mtoDM + (float)$m["monto"];
	                }
	                
	                if($m["tipo"] == "2")
	                {
	                    $mtoPxP = (float)$mtoPxP + (float)$m["monto"];
	                }
	                
	            }
	        }
	        
	        $primaA_DM = ((float)$mtoDM*(float)$taDM)/1000;
	        
	        $primaA_DM =  $primaA_DM + $primaneta;
	        
	        
	        $factor = dtCotizacion::getSistemaFactorCustomFiltro("sistema_factor_valor"," factorid=8 and valor_compara_1=1 ");
	        $margin = (float)$factor["factor"];
	        $factor = dtCotizacion::getSistemaFactorCustomFiltro("sistema_factor_valor"," factorid=8 and valor_compara_1=2 ");
	        $goe = (float)$factor["factor"];
	        
	        //echo "primaA_DM:".$primaA_DM."<hr />";
	        //echo "mtoDM:".$mtoDM."<hr />";
	        if((float)$mtoDM > 0){
	            $tasa = (float)($primaA_DM/(float)$mtoDM)*1000;
	            $tasa = (float)$tasa/(100-$margin-$goe-(float)$cotiza["comisionafecta"]);
	        }else
	        {
	            $tasa = 0;
	        }
	        

	     break;
	     
	    case "2"://Tasa Exenta DM
	        $tasa = 1;
	        $tasaRMS = self::getTasaMotor(8,$nombre,$cotizacionid);
	        $cotiza = self::getCotizacionDetail($cotizacionid);
	        if((float)$tasaRMS == 0)
	        {
	            
	            $teDM = 1;
	            $factores = dtCotizacion::getSistemaFactorCustom("cotizacion_factor"," factorid in(19) ");
	            foreach ($factores as $c) {
	                $teDM = (float)$c["factor"];
	            }
	            
	            $mtoDM  = 0;
	            $ubicaciones = self::getUbicacionesByCotizacion($cotizacionid);
	            foreach ($ubicaciones as $u)
	            {
	                $ubicacionid = $u["ubicacionid"];
	                $montos = self::getCotizacionUbicacionMateria($cotizacionid,$ubicacionid);
	                foreach ($montos as $m)
	                {
	                    if($m["tipo"] == "1")
	                    {
	                        $mtoDM = (float)$mtoDM + (float)$m["monto"];
	                    }
	                    
	                }
	            }
	            $factor = dtCotizacion::getSistemaFactorCustomFiltro("sistema_factor_valor"," factorid=8 and valor_compara_1=1 ");
	            $margin = (float)$factor["factor"];
	            $factor = dtCotizacion::getSistemaFactorCustomFiltro("sistema_factor_valor"," factorid=8 and valor_compara_1=2 ");
	            $goe = (float)$factor["factor"];
	            
	            if( (float)$mtoDM > 0 && (100-$margin-$goe-(float)$cotiza["comisionexcenta"]) > 0){
	                $primaE_DM = ((float)$mtoDM*(float)$teDM)/1000;
	                $tasa = (float)($primaE_DM/(float)$mtoDM)*1000;
	                $tasa = (float)$tasa/(100-$margin-$goe-(float)$cotiza["comisionexcenta"]);
	            }else
	            {
	                $tasa = 0;
	            }
	            
	            
	            
	        }else
	        {
	            $factor = dtCotizacion::getSistemaFactorCustomFiltro("sistema_factor_valor"," factorid=8 and valor_compara_1=1 ");
	            $margin = (float)$factor["factor"];
	            $factor = dtCotizacion::getSistemaFactorCustomFiltro("sistema_factor_valor"," factorid=8 and valor_compara_1=2 ");
	            $goe = (float)$factor["factor"];
	            $tasa = (float)$tasaRMS/(100-$margin-$goe-(float)$cotiza["comisionexcenta"]); //PONGO EL 100 por que son porcentajes
	        }
	        
	        
	        break;
	        
	    case "3"://Tasa Afecta PxP
	        $tasa = 1;
	        $cotiza = self::getCotizacionDetail($cotizacionid);
	        //Se obtiene TASA AFECTA PXP
	        $taDM = 1;
	        $tasaAfDm = self::getTasaMotor(1,$nombre,$cotizacionid);
	        $factores = dtCotizacion::getSistemaFactorCustom("cotizacion_factor"," factorid in(9,5) ");
	        foreach ($factores as $c) {
	            $taDM = (float)$taDM*((float)$c["factor"]/100);
	        }
	        
	        $taDM = (float)$taDM*(float)$tasaAfDm;
	        
	        //Se debe obtener el total de los montos para obtener las primas
	        $ubicaciones = self::getUbicacionesByCotizacion($cotizacionid);
	        $mtoPxP = 0;
	        foreach ($ubicaciones as $u)
	        {
	            $ubicacionid = $u["ubicacionid"];
	            $montos = self::getCotizacionUbicacionMateria($cotizacionid,$ubicacionid);
	            foreach ($montos as $m)
	            {
	                if($m["tipo"] == "2")
	                {
	                    $mtoPxP = (float)$mtoPxP + (float)$m["monto"];
	                }
	                
	            }
	        }
	        
	        $primaA_DM = ((float)$mtoPxP*(float)$taDM)/1000;
	        
	        
	        $factor = dtCotizacion::getSistemaFactorCustomFiltro("sistema_factor_valor"," factorid=8 and valor_compara_1=1 ");
	        $margin = (float)$factor["factor"];
	        $factor = dtCotizacion::getSistemaFactorCustomFiltro("sistema_factor_valor"," factorid=8 and valor_compara_1=2 ");
	        $goe = (float)$factor["factor"];
	        
	        //echo "primaA_DM:".$primaA_DM."<hr />";
	        //echo "mtoDM:".$mtoDM."<hr />";
	        if((float)$mtoPxP > 0)
	        {
	            $tasa = (float)($primaA_DM/(float)$mtoPxP)*1000; 
	            $tasa = (float)$tasa/(100-$margin-$goe-(float)$cotiza["comisionafecta"]);
	        }
	        else
	        {
	            $tasa = 0;
	        }
	        
	        break;
	        
	    case "4"://Tasa Exenta PxP
	        $tasa = 1;
	        $tasa = 1;
	        $factor = dtCotizacion::getSistemaFactorCustomFiltro("sistema_factor_valor"," factorid=8 and valor_compara_1=1 ");
	        $margin = (float)$factor["factor"];
	        $factor = dtCotizacion::getSistemaFactorCustomFiltro("sistema_factor_valor"," factorid=8 and valor_compara_1=2 ");
	        $goe = (float)$factor["factor"];
	        $tasaRMS = self::getTasaMotor(8,$nombre,$cotizacionid);
	        $cotiza = self::getCotizacionDetail($cotizacionid);
	        if((float)$tasaRMS == 0)
	        {
	            
	            $teDM = 1;
	            
	            $tasaExDm = self::getTasaMotor(2,$nombre,$cotizacionid);
	            $tasaExDm = (float)$tasaExDm * ((100-$margin-$goe-(float)$cotiza["comisionexcenta"]));
	            
	            $factores = dtCotizacion::getSistemaFactorCustom("cotizacion_factor"," factorid in(9) ");
	            foreach ($factores as $c) {
	                $teDM = (float)$teDM*((float)$c["factor"]/100);
	            }
	            
	            $teDM = (float)$teDM*(float)$tasaExDm;
	            
	            
	            
	            $mtoDM  = 0;
	            $ubicaciones = self::getUbicacionesByCotizacion($cotizacionid);
	            foreach ($ubicaciones as $u)
	            {
	                $ubicacionid = $u["ubicacionid"];
	                $montos = self::getCotizacionUbicacionMateria($cotizacionid,$ubicacionid);
	                foreach ($montos as $m)
	                {
	                    if($m["tipo"] == "2")
	                    {
	                        $mtoDM = (float)$mtoDM + (float)$m["monto"];
	                    }
	                    
	                }
	            }
	             
	            if( (float)$mtoDM > 0)
	            {
	                $primaE_DM = ((float)$mtoDM*(float)$teDM)/1000;
	                $tasa = (float)($primaE_DM/(float)$mtoDM)*1000;
	                $tasa = (float)$tasa/(100-$margin-$goe-(float)$cotiza["comisionexcenta"]);
	            }
	            else
	            {
	                $tasa = 0;
	            }
	            
	            
	        }else
	        {
	            
	            $tasa = (float)$tasaRMS/(100-$margin-$goe-(float)$cotiza["comisionexcenta"]); //PONGO EL 100 por que son porcentajes
	        }
	        
	        
	        
	        break;
        case "5"://Tasa Afecta
            $tasa = 1;
            //PRIMA AF TOT + PRIMANETA  COB AD
            $cobCotiza = negCotizacion::getgetCobAdicionalesSublimitesCotizacion($cotizacionid);
            $primaneta  = 0;
            foreach ($cobCotiza as $cc)
            {
                $primaneta = $primaneta + $cc["primaneta"]; 
            }
            
            $cotiza = self::getCotizacionDetail($cotizacionid);
            //Se obtiene TASA AFECTA DM
            $taDM = 10;
            
            $factores = dtCotizacion::getSistemaFactorCustom("cotizacion_factor"," factorid in(1,2,3,4) ");
            foreach ($factores as $c) {
                $taDM = (float)$taDM*(float)$c["factor"];
            }
            
            
            //Se debe obtener el total de los montos para obtener las primas
            $ubicaciones = self::getUbicacionesByCotizacion($cotizacionid);
            $mtoDM  = 0;
            $mtoPxP = 0;
            foreach ($ubicaciones as $u)
            {
                $ubicacionid = $u["ubicacionid"];
                $montos = self::getCotizacionUbicacionMateria($cotizacionid,$ubicacionid);
                foreach ($montos as $m)
                {
                    if($m["tipo"] == "1")
                    {
                        $mtoDM = (float)$mtoDM + (float)$m["monto"];
                    }
                    
                    if($m["tipo"] == "2")
                    {
                        $mtoPxP = (float)$mtoPxP + (float)$m["monto"];
                    }
                    
                }
            }
            
            $primaA_DM = ((float)$mtoDM*(float)$taDM)/1000;
            
            $primaA_DM =  $primaA_DM + $primaneta;
            
            //Se OBTIENE TASA AFECTA PXP
            $taDM = 1;
            $tasaAfDm = self::getTasaMotor(1,$nombre,$cotizacionid);
            $factores = dtCotizacion::getSistemaFactorCustom("cotizacion_factor"," factorid in(9,5) ");
            foreach ($factores as $c) {
                $taDM = (float)$taDM*((float)$c["factor"]/100);
            }
            
            $taDM = (float)$taDM*(float)$tasaAfDm;
            
            //Se debe obtener el total de los montos para obtener las primas
            $mtoPxP = 0;
            foreach ($ubicaciones as $u)
            {
                $ubicacionid = $u["ubicacionid"];
                $montos = self::getCotizacionUbicacionMateria($cotizacionid,$ubicacionid);
                foreach ($montos as $m)
                {
                    if($m["tipo"] == "2")
                    {
                        $mtoPxP = (float)$mtoPxP + (float)$m["monto"];
                    }
                    
                }
            }
            
            $primaA_PXP = ((float)$mtoPxP*(float)$taDM)/1000;
            
            
            
            if( (float)$mtoPxP + (float)$mtoDM  > 0)
            {
                $primaA_DM = (float)$primaA_DM + (float)$primaA_PXP;
                $valor =  (float)$primaA_DM / ((float)$mtoPxP + (float)$mtoDM ); 
                $valor = (float)$valor * 1000;
                $factor = dtCotizacion::getSistemaFactorCustomFiltro("sistema_factor_valor"," factorid=8 and valor_compara_1=1 ");
                $margin = (float)$factor["factor"];
                $factor = dtCotizacion::getSistemaFactorCustomFiltro("sistema_factor_valor"," factorid=8 and valor_compara_1=2 ");
                $goe = (float)$factor["factor"];
                $tasa = (float)$valor/(100-$margin-$goe-(float)$cotiza["comisionafecta"]); //PONGO EL 100 por que son porcentajes
            }
            else
            {
                $tasa = 0;
            }
            
	        break;
        case "6":
            $tasa = 1;
            $factor = dtCotizacion::getSistemaFactorCustomFiltro("sistema_factor_valor"," factorid=8 and valor_compara_1=1 ");
            $margin = (float)$factor["factor"];
            $factor = dtCotizacion::getSistemaFactorCustomFiltro("sistema_factor_valor"," factorid=8 and valor_compara_1=2 ");
            $goe = (float)$factor["factor"];
            $tasaRMS = self::getTasaMotor(8,$nombre,$cotizacionid);
            $cotiza = self::getCotizacionDetail($cotizacionid);
            if((float)$tasaRMS == 0)
            {
                
                $teDM = 1;
                $factores = dtCotizacion::getSistemaFactorCustom("cotizacion_factor"," factorid in(19) ");
                foreach ($factores as $c) {
                    $teDM = (float)$teDM*(float)$c["factor"];
                }
                
                $mtoDM  = 0;
                $ubicaciones = self::getUbicacionesByCotizacion($cotizacionid);
                foreach ($ubicaciones as $u)
                {
                    $ubicacionid = $u["ubicacionid"];
                    $montos = self::getCotizacionUbicacionMateria($cotizacionid,$ubicacionid);
                    foreach ($montos as $m)
                    {
                        if($m["tipo"] == "1")
                        {
                            $mtoDM = (float)$mtoDM + (float)$m["monto"];
                        }
                        
                    }
                }
                $primaE_DM = ((float)$mtoDM*(float)$teDM)/1000;
                
                
                //PRIMA EX PXP
                $tePXP = 1;
                
                $tasaExDm = self::getTasaMotor(2,$nombre,$cotizacionid);
                $tasaExDm = (float)$tasaExDm * ((100-$margin-$goe-(float)$cotiza["comisionexcenta"]));
                
                $factores = dtCotizacion::getSistemaFactorCustom("cotizacion_factor"," factorid in(9) ");
                foreach ($factores as $c) {
                    $tePXP = (float)$tePXP*((float)$c["factor"]/100);
                }
                
                $tePXP = (float)$tePXP*(float)$tasaExDm;
                
                $mtoPXP  = 0;
                foreach ($ubicaciones as $u)
                {
                    $ubicacionid = $u["ubicacionid"];
                    $montos = self::getCotizacionUbicacionMateria($cotizacionid,$ubicacionid);
                    foreach ($montos as $m)
                    {
                        if($m["tipo"] == "2")
                        {
                            $mtoPXP = (float)$mtoPXP + (float)$m["monto"];
                        }
                        
                    }
                }
                $primaE_PXP = ((float)$mtoPXP*(float)$tePXP)/1000;
                
                if( (float)$mtoPXP+(float)$mtoDM > 0)
                {
                    $valorEx = (float)$tasaExDm +(float)$primaE_PXP;
                    $valorEx = (float)$valorEx/((float)$mtoPXP+(float)$mtoDM);
                    $valorEx = (float)$valorEx * 1000;
                    $tasa = (float)$valorEx/(100-$margin-$goe-(float)$cotiza["comisionexcenta"]); //PONGO EL 100 por que son porcentajes
                }
                else
                {
                    $tasa = 0;
                }
                
               
                
            }else
            {
               
                $tasa = (float)$tasaRMS/(100-$margin-$goe-(float)$cotiza["comisionexcenta"]); //PONGO EL 100 por que son porcentajes
            }
            
            
            
            break;
        case "7":
            
            $tasaRMS = self::getTasaMotor(8,$nombre,$cotizacionid);
            $tasaAF = self::getTasaMotor(5,$nombre,$cotizacionid);
            $tasaEX = self::getTasaMotor(6,$nombre,$cotizacionid);
            
            if((float)$tasaRMS==0)
            {
                $tasa = (float)$tasaAF + (float)$tasaEX;
            }else
            {
                $tasa = $tasaEX;
            }
            
            $cotiza = self::getCotizacionDetail($cotizacionid);
            if($cotiza["tasa_manual"]!="SI")//SAVETASACALCULADAPOLIZA
            {
                self::setTasas($cotizacionid,$tasaAF,$tasaEX,$tasa);
            }
            
            
            
            break;
            
        case "8": //TASA RMS
            $saveTC = "NO";
            
            $tasa = dtCotizacion::getSistemaFactorCustomFiltro("cotizacion_tasa_input"," cotizacionid=".$cotizacionid." and tipotasaid=".$tasaid." ");
            if(count($tasa)>0)
            {
                $tasa = (float)$tasa["tasa"];
            }else{
                $tasa = 0;
            }
            
            
            
            
            break;
        
	    }
	    
	    //GUARDA TASA CALCULADA
	    if($saveTC == "SI")
	    {
	        dtCotizacion::saveTasaCalculada($cotizacionid,$tasaid,$tasa);
	    }
	   
	    
	    
	    return $tasa;
	    
	}
	
	public static function saveTasaCalculada($cotizacionid,$tasaid,$tasa)
	{
	    dtCotizacion::saveTasaCalculada($cotizacionid,$tasaid,$tasa);
	}
	public static function saveTasaInput($cotizacionid,$tasaid,$tasa)
	{
	    dtCotizacion::saveTasaInput($cotizacionid,$tasaid,$tasa);
	}
	public static function eliminaCoberturaAdicionalConfig($sublimiteid)
	{
	    dtCotizacion::eliminaCoberturaAdicionalConfig($sublimiteid);
	}
	public static function creaCoberturaSublimite($coberturaNombre,$tipo)
	{
	    dtCotizacion::creaCoberturaSublimite($coberturaNombre,$tipo);
	}
	public static function saveMateriaAdicionalSubLimiteTasaNeta($sublimiteid,$tasa)
	{
	    dtCotizacion::saveMateriaAdicionalSubLimiteTasaNeta($sublimiteid,$tasa);
	}
	public static function saveMateriaAdicionalSubLimiteTasaBruta($sublimiteid,$tasa)
	{
	    dtCotizacion::saveMateriaAdicionalSubLimiteTasaBruta($sublimiteid,$tasa);
	}
	public static function saveTipoTasaCotizacion($cotizacionid,$tipotasa)
	{
	    dtCotizacion::saveTipoTasaCotizacion($cotizacionid,$tipotasa);
	}
	public static function getCotizacionTasaFijaVersion($cotizacionid)
	{
	    return dtCotizacion::getCotizacionTasaFijaVersion($cotizacionid);
	}
}
?>