<?php
class negCoaseguro{
    
    public static function ConsultarCoasegurador()
    {
        $integracion = 'get_coasegurador';
        $url = dtLineaNegocio::getUrlIntegracionLineaNegocio($integracion);
        
        $consultaSB =  file_get_contents($url['url']);
        $consultaLocal = dtCoaseguro::getCoaseguradores();
        $array = json_decode($consultaSB, true);
        
        if($array["statusCode"] == "200")
        {
            $coaseguradores  = $array["result"];
            
            foreach ($coaseguradores as $sb)
            {
                $existe = 'NO';
                
                foreach($consultaLocal as $local)
                {
                    if($sb["coasegurador"] == $local["coasegurador"] && $sb["rut_coasegurador"] == $local["rut_coasegurador"])
                    {
                        $existe = 'SI';
                    }
                }
                
                if($existe == 'NO')
                { 
                    dtCoaseguro::insertCoaseguradorIntegrado($sb["coasegurador"],$sb["codigo"],$sb["rut_coasegurador"]);
                }
                else
                {
                    
                }
                
            }
        }
    }
    
    public static function getCoaseguradores()
    {
        return dtCoaseguro::getCoaseguradores();
    }
  
}



?>