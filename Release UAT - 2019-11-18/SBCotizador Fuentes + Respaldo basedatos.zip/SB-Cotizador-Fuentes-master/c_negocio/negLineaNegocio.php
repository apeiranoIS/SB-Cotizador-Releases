<?php
class negLineaNegocio{
    
    public static function getLineaNegocio()
    {
        return dtLineaNegocio::getLineaNegocio();     
    }
    
    public static function getLineaNegocioPorId($lineanegocioid)
    {
        return dtLineaNegocio::getLineaNegocioPorId($lineanegocioid);
    }
   /* public static function Consultarln(){
        $consulta =  file_get_contents('http://104.211.29.91:9080/producto/getLineaNegocio');
        
        $array = json_decode($consulta, true);
        
        if($array["statusCode"] == "200")//RESPUESTA OK
        {
            $ln  = $array["result"];
            
            foreach ($ln as $s)
            {
                dtLineaNegocio::ConsultarLN($s["codigo"], $s["nombre"]);
            }
        }
        
    }
    */
    public static function Consultarln()
    {
        $integracion = 'get_lineanegocio';
        $url = dtLineaNegocio::getUrlIntegracionLineaNegocio($integracion);
        
        $consultaSB =  file_get_contents($url['url']);
        $consultaLocal = dtLineaNegocio::getLineaNegocio();
        
        $array = json_decode($consultaSB, true);
        
        if($array["statusCode"] == "200")//RESPUESTA OK
        {
            $lineanegocio  = $array["result"];
            
            foreach ($lineanegocio as $sb)// recorre $lineanegocio
            {
                $existe = 'NO';
                
                foreach($consultaLocal as $local)//recorre BDD local $lineanegocio
                {                    
                   if($sb["nombre"] == $local["lineanegocio"] && $sb["codigo"] == $local["codigo_LN"])
                    {   
                        $existe = 'SI';
                    }
                }
                if($existe == 'NO')
                { 
                    dtLineaNegocio::insertLineaNegocio($sb["nombre"],$sb["codigo"]);
                }
                else 
                {
                    
                }
                
            }
         }
      }
      
      public static function CreaLineaNegocioComercial($nombre_lnc,$usuarioid)
      {
         $ln_comercialid =  dtLineaNegocio::CreaLineaNegocioComercial($nombre_lnc);
         //self::guardaUsuarioCreaLineaNegocioComercial($ln_comercialid,$usuarioid);
                  
      }
      public static function guardaProductoLineaNegocioComercial($ln_comercialid,$productos)
      { 
          foreach ($productos as $prod)
           {
               dtLineaNegocio::guardaProductoLineaNegocioComercial($ln_comercialid,$prod);
           }
      }
      public static function guardaUsuarioCreaLineaNegocioComercial($ln_comercialid,$usuarioid)
      {
          dtLineaNegocio::guardaUsuarioCreaLineaNegocioComercial($ln_comercialid,$usuarioid);
      }
      public static function getLineaNegocioComercial()
      {
          return dtLineaNegocio::getLineaNegocioComercial();
      }
      
      public static function getLineaNegocioComercialDetail($lineanegociocomercialid)
      {
          return dtLineaNegocio::getLineaNegocioComercialDetail($lineanegociocomercialid);
      }
      
      public static function getProductoLineanegocioComercial($lineanegociocomercialid)
      {
          return dtLineaNegocio::getProductoLineanegocioComercial($lineanegociocomercialid);
      }
      
      public static function guardaNuevoNombreLnc($lnc_comecialid, $nuevo_nombre_lnc)
      {
         dtLineaNegocio::guardaNuevoNombreLnc($lnc_comecialid, $nuevo_nombre_lnc);
      }
      
      public static function eliminaProductoLNC($lnc_comecialid, $productos)
      {    
          foreach ($productos as $prod)
          {
              dtLineaNegocio::eliminaProductoLNC($lnc_comecialid, $prod);
          }
      }
      public static function eliminaLNC($lnc_comecialid)
      {
          dtLineaNegocio::eliminaLNC($lnc_comecialid);
      }
      public static function productosByLineaNegocioDisp($lnc_comecialid)
      {
          $productosLNC = negLineaNegocio::getProductoLineanegocioComercial($lnc_comecialid);
          $productos = negProducto::getProductosVigentes();
          $arr = array();
         
          $cont = 0;
          foreach ($productos as $p)
          {
              $mueestra = "SI";
              $cont ++;
              
              foreach ($productosLNC as $plnc)
              {
                  if($plnc["productoid"] == $p["productoid"])
                  {
                      $mueestra = "NO";
                  }
              }
              
              if($mueestra == "SI")
              {
                  $arr[] = $p;
              }
          }
         
          return $arr;
      }
      
      public static function getUsuariosByLineaNegocioComercial($lnc_comecialid)
      {   
          return dtLineaNegocio::getUsuariosByLineaNegocioComercial($lnc_comecialid);
      }
      public static function getUsuariosByLineaNegocioComercialConfig($lnc_comecialid)
      {
          return dtLineaNegocio::getUsuariosByLineaNegocioComercialConfig($lnc_comecialid);
      }
      public static function addUsuariosToLineaNegocioComercialConfig($lnc_comecialid,$usuarioid)
      {
          return dtLineaNegocio::addUsuariosToLineaNegocioComercialConfig($lnc_comecialid,$usuarioid);
      }
      public static function elimnaUsuariosToLineaNegocioComercialConfig($lnc_comecialid,$usuarioid)
      {
          return dtLineaNegocio::elimnaUsuariosToLineaNegocioComercialConfig($lnc_comecialid,$usuarioid);
      }
      public static function getFactoresNegocioByLineaComercial($lnc_comecialid)
      {
          return dtLineaNegocio::getFactoresNegocioByLineaComercial($lnc_comecialid);
      }
      public static function getFactoresDisponiblesNegocioByLineaComercial($lnc_comecialid)
      {
          return dtLineaNegocio::getFactoresDisponiblesNegocioByLineaComercial($lnc_comecialid);
      }
      public static function addFactoresNegocioByLineaComercial($lnc_comecialid,$factorid)
      {
          return dtLineaNegocio::addFactoresNegocioByLineaComercial($lnc_comecialid,$factorid);
      }
      public static function eliminaFactoresNegocioByLineaComercial($lnc_comecialid,$factorid)
      {
          return dtLineaNegocio::eliminaFactoresNegocioByLineaComercial($lnc_comecialid,$factorid);
      }
      public static function GetTasasMontoxLinea($lnc_comecialid)
      {
          return dtLineaNegocio::GetTasasMontoxLinea($lnc_comecialid);
      }
      public static function EliminaMontoTasa($lnc_comecialid,$tipo_monto,$tipo_tasa)
      {
          return dtLineaNegocio::EliminaMontoTasa($lnc_comecialid,$tipo_monto,$tipo_tasa);
      }
      public static function AgregarTipoMontoTasa($lnc_comecialid,$tipo_monto,$tipo_tasa)
      {
          return dtLineaNegocio::AgregarTipoMontoTasa($lnc_comecialid,$tipo_monto,$tipo_tasa);
      }
      public static function GetMateriasDisponiblesxLN($lnc_comecialid)
      {
          return dtLineaNegocio::GetMateriasDisponiblesxLN($lnc_comecialid);
      }
      public static function addMateriaTipoMT($lnc_comecialid,$tipo,$tipo_monto,$tipo_tasa,$materiaid)
      {
          return dtLineaNegocio::addMateriaTipoMT($lnc_comecialid,$tipo,$tipo_monto,$tipo_tasa,$materiaid);
      }
      public static function EliminarMateriaTipoMT($lnc_comecialid,$tipo_monto,$tipo_tasa,$materiaid)
      {
          return dtLineaNegocio::EliminarMateriaTipoMT($lnc_comecialid,$tipo_monto,$tipo_tasa,$materiaid);
      }
      
}



?>