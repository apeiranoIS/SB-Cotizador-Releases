<?php 
class negCuenta
{
	public static function validaUsuario($usuario, $clave)
	{
		 		 
		 $cuenta =  dtCuenta::validaUsuario($usuario, $clave);
		 if(count($cuenta) > 0)
		 {
		 	self::setSession($cuenta["usuarioid"]);		 	
		 }else
		 {
		 	session_unset();
		 	session_destroy();		 	
		 	
		 }
		 
		 return $cuenta;
	}
	
	public static function setSession($usuarioid)
	{
		$usr = self::getUsuario($usuarioid);
		
		$perfilObj  = dtCuenta::getAppsByPerfil($usr["perfilid"]);
		$getSistemaDefObj  = dtCuenta::getSistemaDef();
		$_SESSION["IGT-getSistemaDef"] =$getSistemaDefObj;
		$_SESSION["usuarioid"] = $usr["usuarioid"];
		$_SESSION["usuario_obj"] = $usr;
		$_SESSION["IGT-usuarioid"] = $usr["usuarioid"];
		$_SESSION["IGT-perfilid"] = $usr["perfilid"];
		$_SESSION["IGT-mail"] = $usr["mail"];
		$_SESSION["IGT-estado"] = $usr["estado"];
		$_SESSION["IGT-nombre"] = $usr["nombre"];
		$_SESSION["IGT-apellidos"] = $usr["apellidos"];
		$_SESSION["IGT-telefono"] = $usr["telefono"];
		$_SESSION["IGT-usuario_mae"] = $usr["usuario_mae"];
		$_SESSION["IGT-tipousuarioid"] = $usr["tipousuarioid"];
		$_SESSION["IGT-avatarid"] = $usr["avatarid"];
		$_SESSION["IGT-nombre_completo"] = $usr["nombre"]." ".$usr["apellidos"];
		$_SESSION["IGT-perfil_obj"] = $perfilObj;
		
	}
	
	public static function getUsuario($usuarioid)
	{
		return dtCuenta::getUsuario($usuarioid);		
	}
	
	public static function recuperaCuenta($correo)
	{
		$cta =  dtCuenta::getUsuarioByCorreo($correo);
		$salida = "ERROR - El correo indicado No existe en el sistema o no esta activo en el sistema!!!";
		if(count($cta) > 0)
		{
			//INIICIO PROCESO RECUPERACION DE CLAVE
			
			$sis = negSistema::getSistemaDef();
			$hoy= date("dmY[His]_");
			$url_env = "RECUPERA_CLAVE_".$cta["usuarioid"]."_".$hoy;
			$url_env_limpia = $url_env;
			$url_env = util::encodeParamURL($url_env);
			dtCuenta::saveProcesoRecuperaClave($cta["usuarioid"],$correo,$url_env,$url_env_limpia);
			$body = 'Estimad@ <strong>'.$cta["nombre"].'</strong>, para poder reestablecer la clave de acceso debe acceder al siguiente enlace que tiene una duración de 48 horas. <br /><br /> <strong>'.$sis["url_acceso_recupera_cuenta"].'?'.$url_env.'</strong> ';
			negSistema::sendMailSMTPSB($correo,"CYCLO - Recuperacion de clave de acceso",$body,$cta["usuarioid"]);
			
			$salida = "OK";
		}
		
		return $salida;
	}
	public static function getRecuperaClaveByURL($valida_url)
	{
		return dtCuenta::getRecuperaClaveByURL($valida_url);
		
	}
	public static function creaNuevaClaveusuario($usuarioid,$clave,$valida_url)
	{
		return dtCuenta::creaNuevaClaveusuario($usuarioid,$clave,$valida_url);
		
	}
	public static function validaCorreousuarioCrea($correo)
	{
		return dtCuenta::validaCorreousuarioCrea($correo);
		
	}
	public static function validaUsuarioCrea($usuario)
	{
		return dtCuenta::validaUsuarioCrea($usuario);
		
	}
	public static function creaCuenta($usuario,$clave,$correo,$nombre,$tipo_cliente,$organizacion,$tipo_cuenta='FREE')
	{
		if($organizacion==''){$organizacion='null';}
		dtCuenta::creaCuenta($usuario,$clave,$correo,$nombre,$tipo_cliente,$organizacion, $tipo_cuenta);
	
		$avataridPath = "";
		negUsuario::creaUsuario($nombre,"",$correo,"",$usuario,$clave,"2",$avataridPath);
		
		$cta =  dtCuenta::getCuentaMaster($correo);
		if(count($cta) > 0)
		{
			//INIICIO PROCESO RECUPERACION DE CLAVE
			
			$sis = negSistema::getSistemaDef();
			$body = 'Estimad@ <strong>'.$cta["nombre"].'</strong>, su cuenta ha sido creada de forma correcta, para acceder utilice los siguientes datos de acceso. <br /><br /><strong>Usuario: '.$cta["usuario_login"].' </strong><br /> <strong>Clave: '.$cta["clave_login"].'</strong><br /> <strong>Acceso al sistema:'.$sis["url_base_sistema"].'</strong> ';
			negSistema::sendMailSMTPSB($correo,"CYCLO - Creación de cuenta",$body,$cta["clienteid"]);
		
		}
	}
	
	
}

?>