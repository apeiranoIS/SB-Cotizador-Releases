<?php
class negCorredor{
    
    public static function getCorredores()
    {
        return dtCorredor::getCorredores();     
    }
    public static function getCorredorDetail($corredorid)
    {
        return dtCorredor::getCorredorDetail($corredorid);
    }
    public static function buscaCorredor($rut,$nombre)
    {
        if($rut   ==""){$rut   ="#SIN_DATOS_BUSQUEDA#";}
        if($nombre==""){$nombre="#SIN_DATOS_BUSQUEDA#";}
        return dtCorredor::buscaCorredor($rut,$nombre);
    }
    public static function buscaCorredorInterno($nombre)
    {
        if($nombre==""){$nombre="#SIN_DATOS_BUSQUEDA#";}
        return dtCorredor::buscaCorredorInterno($nombre);
    }
    public static function getExisteCorredorXidTI($client_no){
        return dtCorredor::getExisteCorredorXNombreCompleto($client_no);
    }
    public static function getExisteCorredorXNombreCompleto($corredor_nombre){
        return dtCorredor::getExisteCorredorXNombreCompleto($corredor_nombre);
    }
    public static function creaCorredorIntegrado($corredor_nombre,$corredor_rut){
        return dtCorredor::creaCorredorIntegrado($corredor_nombre,$corredor_rut);
    }
    public static function editCorredorIntegrado($corredor_nombre,$corredor_rut){
        dtCorredor::editCorredorIntegrado($corredor_nombre,$corredor_rut);
    }
    public static function ConsultarCorredor(){
        $consulta =  file_get_contents('AGREGAR LINK CORRESPONDIENTE');
        
        $array = json_decode($consulta, true);
        
        if($array["statusCode"] == "200")//RESPUESTA OK
        {
            $corredores  = $array["result"];
            
            foreach ($corredores as $s)
            {
               dtCorredor::ConsultarCorredor($s["nombre"], $s["rut"]);
            }
        }
        
    }
    public static function buscaCorredorEnBaseDatos($valor)
    {
        //Valida con el nombre
        $resultado = dtCorredor::buscaCorredorNombreCompleto($valor);
        
        if(count($resultado) == 0)
        {
            //valida con el RUT
            $resultado = dtCorredor::buscaCorredorRutCompleto($valor);
        }
        
        
        return $resultado;
        
    }
}

?>