<?php 
class negIntegracion{
    
public static function getIntegracionUrl()
    {
        return dtIntegracion::getIntegracionUrl();
    }
    public static function EditaUrl($claveIntegracion,$nuevaUrl)
    {
        dtIntegracion::EditaUrl($claveIntegracion,$nuevaUrl);
    }
    
}

?>