<?php
class negRamo{
    
    public static function getRamos()
    {
        return dtRamo::getRamos();
    }
    
    public static function getRamoPorProducto($productoid)
    {
        return dtRamo::getRamosxProducto($productoid);
    }
    
    public static function getRamoPorId($ramoid)
    {
        return dtRamo::getRamosPorId($ramoid);
    }
    /*public static function ConsultarRamo(){
        $consulta =  file_get_contents('http://104.211.29.91:9080/producto/getRamo');
        
        $array = json_decode($consulta, true);
        
        if($array["statusCode"] == "200")//RESPUESTA OK
        {
            $ramo  = $array["result"];
            
            foreach ($ramo as $s)
            {
               dtRamo::ConsultarRamo($s["codigo"], $s["ramo"]);
            }
        }
        
    }*/
    public static function ConsultarRamo()
    {
        $integracion = 'get_ramo';
        $url = dtRamo::getUrlIntegracionRamo($integracion);
        
        $consultaSB =  file_get_contents($url['url']);
        //$ConfigProd =  file_get_contents('http://104.211.29.91:9080/producto/getConfiguracionProducto');
        $consultaLocal = dtRamo::getRamos();
        
        $array = json_decode($consultaSB, true);
        //$arrCP = json_decode($ConfigProd, true);
        
        if($array["statusCode"] == "200")//RESPUESTA OK
        {
            $ramo  = $array["result"];
            //$cproductos  = $arrCP["result"];
            
            foreach ($ramo as $sb)// recorre $ramo
            {
                $existe = 'NO';
                
                foreach($consultaLocal as $local)//recorre BDD local $ramo
                {
                    if($sb["ramo"] != $local["ramo"] && $sb["codigo"] != $local["r_codigo_ramo"])
                    {
                        $existe = 'SI';
                    }
                }
                if($existe == 'NO')
                { //echo "Inster (Nuevo Linea Negocio) --> ". $sb["nombre"].",".$sb["codigo"]."<br />************************";
                    dtRamo::insertRamo($sb["ramo"],$sb["codigo"]);
                }
                else
                {
                    echo "YA EXISTE RAMO --> ". $sb["ramo"].",".$sb["codigo"]."<br />************************";
                }
                
            }
        }
    }
    
}



?>