<?php 
class negMateria{
    
public static function getMaterias()
    {
        return dtMateria::getMaterias();
    }
    
    public static function getMateriaPorId($materiaid)
    {
        return dtMateria::getMateriaPorId($materiaid);
    }
    public static function getMateriaPorIdMateria($materiaid)
    {
        return dtMateria::getMateriaPorIdMateria($materiaid);
    }
    
    public static function getMateriaPorSeccion($seccionesid)
    {
        return dtMateria::getMateriaPorSeccion($seccionesid);
    }
    /*public static function ConsultarMateria(){
        $consulta =  file_get_contents('http://104.211.29.91:9080/producto/getMateria');
        
        $array = json_decode($consulta, true);
        
        if($array["statusCode"] == "200")//RESPUESTA OK
        {
            
            $materias  = $array["result"];
           // echo json_encode($materias, true);
            foreach ($materias as $s)
            {
                dtMateria::ConsultarMateria($s["codigo_Producto"],$s["codigo_seccion"],$s["materia"],$s["codigo_Materia"],$s["fecha_Vigencia"]);
               
            }
            
            self::CompletaSeccionMateria();
        }
        
    }*/
    public static function ConsultarMateria()
    {
        $integracion = 'get_materia';
        $url = dtMateria::getUrlIntegracionMateria($integracion);
        
        $consultaSB =  file_get_contents($url['url']);
        //$ConfigProd =  file_get_contents('http://104.211.29.91:9080/producto/getConfiguracionProducto');
        $consultaLocal = dtMateria::getMaterias(); 
        
        $array = json_decode($consultaSB, true);
        //$arrCP = json_decode($ConfigProd, true);
        
        if($array["statusCode"] == "200")//RESPUESTA OK
        {
            $materias  = $array["result"];
            //$cproductos  = $arrCP["result"];
            
            foreach ($materias as $sb)// recorre materias
            {
                $existe = 'NO';
               
                foreach($consultaLocal as $local)//recorre BDD local materias
                {
                    //echo "AnteDelIF-Codigos(UP-BDD) --> ". $sb["codigo"]." = ".$local["r_codigo_producto"]."|";
                    // echo "AnteDelIF-Nombres(UP-BDD) --> ". $sb["nombre_producto"]." = ".$local["producto"]."| ";
                    // echo "AnteDelIF-Fecha(UP-BDD) --> ". $sb["fecha_vigencia"]." = ".$local["r_fecha_fmt"]."<br />++++++<br />  ";
                    
                    $fecha_vigencia = explode("/", $sb["fecha_Vigencia"]);
                    $fecha_vigwncia = $fecha_vigencia[2]."-".$fecha_vigencia[1]."-".$fecha_vigencia[0];
                    
                    if($sb["codigo_Materia"] == $local["r_codigo_materia"] && $fecha_vigwncia == $local["fecha_vigencia_fmt"])
                    {
                        $existe = 'SI';
                       //echo "ENCONTRO <br />linea_negocio  SB   --> <br />";
                        //echo "linea_negocio LOCAL --> ".$ln["lineanegocio"]."<br />++++++<br /> ";
                        
                        if($sb["materia"] != $local["materia"] && $sb["codigo_Materia"] == $local["r_codigo_materia"] )
                        {  //echo "UP-MAteria(UP-BDD) --> ". $sb["materia"].",".$sb["codigo_Materia"].",".$sb["fecha_Vigencia"]."<br />----- ------- ------- --";
                        dtMateria::updateMateria($sb["materia"],$sb["codigo_Materia"],$sb["fecha_Vigencia"]);
                        }
                        else
                        {
                            //echo "PRODUCTO IGUAL NO SE HACE CAMBIO [] -++++++<br />";
                            
                        }
                    }
                }
                
                if($existe == 'NO')
                {//echo "Inster (Nuevo MAteria) --> ". $sb["materia"].",".$sb["codigo_Materia"].",".$sb["fecha_Vigencia"]."<br />************************";
                dtMateria::insertMateria($sb["materia"],$sb["codigo_Materia"],$sb["fecha_Vigencia"],$sb["codigo_seccion"],$sb["codigo_Producto"]);
               
                }
                //echo "<hr />";
            }
            self::CompletaSeccionMateria();
        }
    }
    
    public static function CompletaSeccionMateria()
    {
        dtMateria::CompletaSeccionMateria();
    }
    
    public static function getMateriasDisponiblesByUbicacion($ubicacionid,$cotizacionid)
    {
        //SE VALIDA SI LA LNC TIENE CONFIGURADAS MATERIAS PARA LA COTIZACIÓN
        if(count(dtMateria::getMateriasLNCByCotizacion($cotizacionid))>0)
        {
            $matDisp = dtMateria::getMateriasDisponiblesByUbicacionAndLNC($ubicacionid,$cotizacionid); 
        }else
        {
            $matDisp =  dtMateria::getMateriasDisponiblesByUbicacion($ubicacionid,$cotizacionid);
        }
        
        return $matDisp;
    }
    public static function getMateriasDisponiblesByLineaNegocioComercial($lineanegociocomercialid)
    {
        return dtMateria::getMateriasDisponiblesByLineaNegocioComercial($lineanegociocomercialid);
    }
    public static function getMateriasByLineaNegocioComercial($lineanegociocomercialid)
    {
        return dtMateria::getMateriasByLineaNegocioComercial($lineanegociocomercialid);
    }
    public static function addMateriasByLineaNegocioComercial($lineanegociocomercialid,$materiaid)
    {
        return dtMateria::addMateriasByLineaNegocioComercial($lineanegociocomercialid,$materiaid);
    }
    public static function deleteMateriasByLineaNegocioComercial($lineanegociocomercialid,$materiaid)
    {
        return dtMateria::deleteMateriasByLineaNegocioComercial($lineanegociocomercialid,$materiaid);
    }
    public static function getMateriasDisponiblesByWording($wordingid)
    {
        return dtMateria::getMateriasDisponiblesByWording($wordingid);
    }
    public static function getMateriasByWording($wordingid)
    {
        return dtMateria::getMateriasByWording($wordingid);
    }
    public static function addMateriasToByWording($wordingid,$materiaid)
    {
        return dtMateria::addMateriasToByWording($wordingid,$materiaid);
    }
    public static function deleteMateriasToByWording($wordingid,$materiaid)
    {
        return dtMateria::deleteMateriasToByWording($wordingid,$materiaid);
    }
    
    

}

?>