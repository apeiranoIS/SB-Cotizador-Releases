<?php 
class negCobertura{
    
    public static function getCoberturas()
    {
        return dtCobertura::getCoberturas();
    }
    
    public static function getCoberturaPorId($coberturaid)
    {
        return dtCobertura::getCoberturaPorId($coberturaid);
    }
    
    public static function getCoberturaPorMateria($materiasid)
    {
        return dtCobertura::getCoberturaPorMateria($materiasid);
    }
   /* public static function ConsultarCobertura(){
        $consulta =  file_get_contents('http://104.211.29.91:9080/producto/getCobertura');
        
        $array = json_decode($consulta, true);
        
        if($array["statusCode"] == "200")//RESPUESTA OK
        {
            $cobertura  = $array["result"];
           
            foreach ($cobertura as $s)
            {
                
               dtCobertura::ConsultarCobertura($s["codigo_producto"], $s["codigo_seccion"],$s["codigo_riesgo"],$s["coberturas"],
                    $s["codigo"], $s["fecha_Vigencia"],$s["tipoCobertura"],$s["nombre_ramo"],$s["codigo_ramo"]);
            }
            
        }
        
        
    }*/
    public static function ConsultarCobertura()
    {
        $integracion = 'get_cobertura';
        $url = dtCobertura::getUrlIntegracionCobertura($integracion);
        
        $consultaSB =  file_get_contents($url['url']);
        //$ConfigProd =  file_get_contents('http://104.211.29.91:9080/producto/getConfiguracionProducto');
        $consultaLocal = dtCobertura::getCoberturas();
        
        $array = json_decode($consultaSB, true);
        //$arrCP = json_decode($ConfigProd, true);
        
        if($array["statusCode"] == "200")//RESPUESTA OK
        {
            $coberturas  = $array["result"];
            //$cproductos  = $arrCP["result"];
            
            foreach ($coberturas as $sb)// recorre $coberturas
            {
                $existe = 'NO';
                                
                foreach($consultaLocal as $local)//recorre BDD local $coberturas
                {             
                    
                    if($sb["codigo_riesgo"] == $local["codigo_riesgo"] && $sb["codigo"] == $local["r_codigo_cobertura"] && $sb["fecha_Vigencia"] == $local["fecha_vigencia_fmt"] && $sb["codigo_producto"] == $local["codigo_producto"])
                    {
                        $existe = 'SI';
                        
                        
                        if($sb["codigo_riesgo"] == $local["codigo_riesgo"] && $sb["coberturas"] != $local["cobertura"] && $sb["codigo"] == $local["r_codigo_cobertura"] && $sb["codigo_producto"] == $local["codigo_producto"] )
                        { //echo "UP-MAteria(UP-BDD) --> ". $sb["coberturas"].",".$sb["codigo"].",".$sb["fecha_Vigencia"]."<br />----- ------- ------- --";
                          dtCobertura::updateCobertura($sb["coberturas"],$sb["codigo"],$sb["fecha_Vigencia"],$sb["codigo_producto"],$sb["codigo_riesgo"]);
                        }
                        else
                        {
                            //echo "PRODUCTO IGUAL NO SE HACE CAMBIO [] -++++++<br />";
                            
                        }
                    }
                }
                
                if($existe == 'NO')
                {//echo "Inster (Nuevo MAteria) --> ". $sb["coberturas"].",".$sb["codigo"].",".$sb["fecha_Vigencia"]."<br />************************";
                  dtCobertura::insertCobertura($sb["coberturas"],$sb["codigo"],$sb["fecha_Vigencia"],$sb["codigo_seccion"],$sb["codigo_producto"],$sb["codigo_riesgo"],$sb["tipoCobertura"],$sb["nombre_ramo"],$sb["codigo_ramo"]);
                }
               // echo "<hr />";
            }
            self::CompletaSeccionCobertura();
        }
    }
    public static function CompletaSeccionCobertura()
    {
        dtCobertura::CompletaSeccionCobertura();
    }

}

?>