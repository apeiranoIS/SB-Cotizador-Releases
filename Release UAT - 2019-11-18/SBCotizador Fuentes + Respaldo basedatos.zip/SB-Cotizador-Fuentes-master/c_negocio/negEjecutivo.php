<?php
class negEjecutivo{
    
    public static function getEjecutivos()
    {
        return dtEjecutivo::getEjecutivos();
    }
    public static function getUsuariosNoEjecutivo(){
        return dtEjecutivo::getUsuariosNoEjecutivo();
    }
    public static function addEjecutivoUsuario($usuarioid){
        dtEjecutivo::addEjecutivoUsuario($usuarioid);
    }
    public static function deleteEjecutivoUsuario($usuarioid){
        dtEjecutivo::deleteEjecutivoUsuario($usuarioid);
    }
    public static function habilitaEjecutivoUsuario($usuarioid){
        dtEjecutivo::habilitaEjecutivoUsuario($usuarioid);
    }
    
}



?>