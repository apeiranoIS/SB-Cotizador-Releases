<?php

class negPerfil{
	
	public static function getPerfiles()
	{
		return dtPerfil::getPerfiles();
	}
	public static function getPerfil($perfilid)
	{
		return dtPerfil::getPerfil($perfilid);
	}
	public static function getAppsByPerfil($perfilid)
	{
		return dtPerfil::getAppsByPerfil($perfilid);
	}
	public static function getApps()
	{
		return dtPerfil::getApps();
	}
	public static function creaPerfil($nombre,$descripcion,$apps)
	{
		
		$p = dtPerfil::creaPerfil($nombre,$descripcion);
		
		$perfilid = $p["perfilid"];
		negSistema::creaSistemaRegistro($perfilid,"perfil","Perfiles","CREA PERFIL");
		
		
		dtPerfil::limpiaApssPerfil($perfilid);
		if($apps != "")
		{
			
			foreach ($apps as $a)
			{
				dtPerfil::addApssPerfil($perfilid,$a);
			}
		}
	}
	public static function editaPerfil($nombre,$descripcion,$apps,$perfilid)
	{
		
		$p = dtPerfil::editaPerfil($nombre,$descripcion,$perfilid);
		negSistema::creaSistemaRegistro($perfilid,"perfil","Perfiles","MODIFICA PERFIL");
		
		dtPerfil::limpiaApssPerfil($perfilid);
		if($apps != "")
		{
			
			foreach ($apps as $a)
			{
				dtPerfil::addApssPerfil($perfilid,$a);
			}
		}
	}
	
	public static function getUsuariosByPerfil($perfilid)
	{
		return dtPerfil::getUsuariosByPerfil($perfilid);		
	}
	
	public static function eliminaPerfil($perfilid)
	{
		dtPerfil::eliminaPerfil($perfilid);
	}
	
	public static function deshabilitarPerfil($perfilid)
	{
	    dtPerfil::deshabilitarPerfil($perfilid);
	}
	
	public static function habilitarPerfil($perfilid)
	{
	    dtPerfil::habilitarPerfil($perfilid);
	}
    
}
?>