<?php
class negSeccion{
    
    public static function getSeccionPorProducto($productoid)
    {
        return dtSeccion::getSeccionPorProducto($productoid);     
    }
    
    public static function getSecciones()
    {
        return dtSeccion::getSecciones();
    }
    
    public static function getSeccionPorId($seccionid)
    {
        return dtSeccion::getSeccionPorId($seccionid);
    }
    public static function getSeccionUltimoPorProducto($productoid)
    {
        $arr = array();
        $prod = dtSeccion::getSeccionPorProducto($productoid);
        $fant = 0;
        $codigo_seccion_ant = ''; 
        foreach ($prod as $p)
        {
            $objAnterior  = $p;

            $fecha = str_replace("-","", $p["r_fecha_vigencia"]);
            $fecha = (int)$fecha;
             
            if($p["r_codigo_seccion"] == $codigo_seccion_ant)
            {
                
                if((INT)$fant >= (INT)$fecha )
                {
                    $p["r_fecha_vigencia"]='NA';
                }else {
                    $arr[] = $objAnterior;
                }
            }else {
                $arr[] = $objAnterior;
            }
            
            
            $codigo_seccion_ant = $p["r_codigo_seccion"];
            $fant=$fecha;
            
        }
        
        return $arr;
    }
    
   /* public static function ConsultarSecciones(){
        
        $consulta =  file_get_contents('http://104.211.29.91:9080/producto/getSeccion');
        
        $array = json_decode($consulta, true);        
        
        if($array["statusCode"] == "200")//RESPUESTA OK
        {
            $secciones  = $array["result"];
            
            foreach ($secciones as $s)
            {
                dtSeccion::CompletaSecciones($s["nombre_Seccion"], $s["codigo"],$s["fecha_Vigencia"],$s["codigo_producto"]);              
            }
            
            dtSeccion::CompletaProductoSeccioneRelacion();
        }
        
    }*/
    
    public static function ConsultarSecciones()
    {
        $integracion = 'get_seccion';
        $url = dtSeccion::getUrlIntegracionSecciones($integracion);
        
        $consultaSB =  file_get_contents($url['url']);
        //$ConfigProd =  file_get_contents('http://104.211.29.91:9080/producto/getConfiguracionProducto');
        $consultaLocal = dtSeccion::getSecciones();
        
        $array = json_decode($consultaSB, true);
        //$arrCP = json_decode($ConfigProd, true);
        
        if($array["statusCode"] == "200")//RESPUESTA OK
        {
            $Secciones  = $array["result"];
            //$cproductos  = $arrCP["result"];
            
            foreach ($Secciones as $sb)// recorre $Secciones
            {
                $existe = 'NO';
                
                
                foreach($consultaLocal as $local)//recorre BDD local $ramo
                {
                    if($sb["codigo_producto"] == $local["codigo_producto"] && $sb["nombre_Seccion"] == $local["seccion"] && $sb["codigo"] == $local["r_codigo_seccion"] && $sb["fecha_Vigencia"] == $local["r_fecha_vigencia"])
                    {
                        $existe = 'SI';
                    }
                }
                if($existe == 'NO')
                { //echo "Inster (Nuevo Linea Negocio) --> ". $sb["nombre_Seccion"].",".$sb["codigo"]."<br />************************";
                    dtSeccion::insertSecciones($sb["nombre_Seccion"],$sb["codigo"],$sb["fecha_Vigencia"],$sb["codigo_producto"]);
                }
                else
                {
                    //echo "YA EXISTE RAMO --> ". $sb["ramo"].",".$sb["codigo"]."<br />************************";
                }
            }
            dtSeccion::CompletaProductoSeccioneRelacion();
        }
    }
    
}

?>