<?php


class util
{
    public static function getCondicionBloqueo($condBloq,$tipo_bloqueo,$monedaid,$valor)
    {
        
       
        foreach ($condBloq as $cb)
        {
            if( $cb["tipo_bloqueo"]==$tipo_bloqueo && $monedaid == $cb["monedaid"] )
            {
                $arrcond = explode("|", $cb["condicion_php"]);
                $condicion = $arrcond[1];
                $valor_comparacion = $arrcond[2];
                $cumple = false;
                
                if($condicion == "=="){if($valor == $valor_comparacion){ $cumple = true;}}
                if($condicion == ">") {if($valor >  $valor_comparacion){ $cumple = true;}}
                if($condicion == "<") {if($valor <  $valor_comparacion){ $cumple = true;}}
                if($condicion == ">="){if($valor >= $valor_comparacion){ $cumple = true;}}
                if($condicion == "<="){if($valor <= $valor_comparacion){ $cumple = true;}}
                if($condicion == "!="){if($valor != $valor_comparacion){ $cumple = true;}}
                
                if($cumple == true){return $cb["mensaje"];}
                    
            }
        }
        
        
    }
	public static function generateRandomString($length = 10) {
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		return $randomString;
	}
	public static function encodeKeyWord($palabra)
	{
		
		$ct="S";
		if(!strpos($palabra, "0") === false){$ct="N";}
		if(!strpos($palabra, "1") === false){$ct="N";}
		if(!strpos($palabra, "2") === false){$ct="N";}
		if(!strpos($palabra, "3") === false){$ct="N";}
		if(!strpos($palabra, "4") === false){$ct="N";}
		if(!strpos($palabra, "5") === false){$ct="N";}
		if(!strpos($palabra, "6") === false){$ct="N";}
		if(!strpos($palabra, "7") === false){$ct="N";}
		if(!strpos($palabra, "8") === false){$ct="N";}
		if(!strpos($palabra, "9") === false){$ct="N";}
		
		if($ct == "S")  
		{
			$palabra = str_replace("a", "0", $palabra);
			$palabra = str_replace("e", "9", $palabra);
			$palabra = str_replace("i", "8", $palabra);
			$palabra = str_replace("o", "7", $palabra);
			$palabra = str_replace("u", "6", $palabra);
			
			$palabra = str_replace("A", "5", $palabra);
			$palabra = str_replace("E", "4", $palabra);
			$palabra = str_replace("I", "3", $palabra);
			$palabra = str_replace("O", "2", $palabra);
			$palabra = str_replace("U", "1", $palabra);
		} 
		
		return ($palabra);
	}
	public static function decodeKeyWord($palabra)
	{
		$ct="S";
		if(!strpos($palabra, "a") === false){$ct="N";}
		if(!strpos($palabra, "e") === false){$ct="N";}
		if(!strpos($palabra, "i") === false){$ct="N";}
		if(!strpos($palabra, "o") === false){$ct="N";}
		if(!strpos($palabra, "u") === false){$ct="N";}
		
		if(!strpos($palabra, "A") === false){$ct="N";}
		if(!strpos($palabra, "E") === false){$ct="N";}
		if(!strpos($palabra, "I") === false){$ct="N";}
		if(!strpos($palabra, "O") === false){$ct="N";}
		if(!strpos($palabra, "U") === false){$ct="N";}
		
		if($ct == "S")
		{
			$palabra = str_replace("0", "a", $palabra);
			$palabra = str_replace("9", "e", $palabra);
			$palabra = str_replace("8", "i", $palabra);
			$palabra = str_replace("7", "o", $palabra);
			$palabra = str_replace("6", "u", $palabra);
			
			$palabra = str_replace("5", "A", $palabra);
			$palabra = str_replace("4", "E", $palabra);
			$palabra = str_replace("3", "I", $palabra);
			$palabra = str_replace("2", "O", $palabra);
			$palabra = str_replace("1", "U", $palabra);
		}
		
		return ($palabra);
	}
	/**
     * util::decodeParamURL($string)
     * [13-01-2016]-DOO: Decodifica los parametros de la URL
     * Version: 1.0
     * Estado: En Operacion
     * @param mixed $string: Parametros de la URL encriptado
     * @1q	return retorna la URL decodificada
     */
    public static function decodeParamURL($string)
    {
        $string = base64_decode($string);
        $string= self::decodeKeyWord($string);
        
        $cad_get = explode("&",$string); //separo la url por &
        foreach($cad_get as $value)
        {
            $val_get = explode("=",$value); //asigno los valosres al GET
            $_REQUEST[$val_get[0]]=utf8_decode($val_get[1]);
        }
    }
    public static function validaSession($vuelve) 
    {
    	if(!isset($_SESSION["IGT-usuarioid"]))
    	{	
    		$url = $vuelve.'cw_publico/login.php';
    		header('Location: ' . $url, true, 301);
    		
    		
    		
    		exit();
    	}
    }
    
    public static function getPageApp($level,$codigo)
    {
    	$vuelve=self::getLevel($level);
    	$apps_sist = negSistema::getAplicacionCode($codigo);
    	$GO_URL="";
    	foreach ($apps_sist as $as)
    	{
    		if($as["codigo"] == $codigo)
    		{
    			$GO_URL = $as["page"];
    		}
    	}
    	$salida = $vuelve.$GO_URL;
    	return $salida;
    	
    }
    
    public static function validaAppsByCodigo($codigo)
    {
    	
    	$appIn = negSistema::getAplicacionCode($codigo);
    	$aplicacionid = 0;
    	$tipo = '';
    	$appsPerfil = $_SESSION["IGT-perfil_obj"];
    	$validacion = "NOK";
    	
    	foreach ($appIn as $a)
    	{
    		$aplicacionid = $a["aplicacionid"];
    		$tipo = $a["tipo"];
    	}
    	
    	if($tipo =="APLICACION-INTERNA-SIN-PERFIL")
    	{
    		$validacion = "OK";
    		
    	}else
    	{
    		foreach ($appsPerfil as $ap)
    		{
    			if($ap["aplicacionid"] == $aplicacionid)
    			{
    				$validacion = "OK";
    			}
    			
    		}
    	}
    	
    	return $validacion;    		
    	
    }
    
    public static function validaAppsByAppId($aplicacionid)
    {
    	$appsPerfil = $_SESSION["IGT-perfil_obj"];
    	$validacion = "NOK";
    	foreach ($appsPerfil as $ap)
    	{
    		if($ap["aplicacionid"] == $aplicacionid)
    		{
    			$validacion = "OK";
    		}
    		
    	}
    	
    	return $validacion;
    	
    	
    }
    
    /***
     * Entrega la URL codificada de una app del sistema.
     * @param INT $level -> Indica el nivel de donde fue llamado
     * @param STRING $codigo -> Se debe indicar el codigo interno de apps
     * @param string $param -> Parametros opcionales si es que se quiere enviar mas de un dato por la url todos deben llevar & ejemplo &id=34&cadigo=123
     * @return string
     */
    public static function creaURLApp($level,$codigo,$param="")
    {
    	$salida = '';
    	$vuelve=self::getLevel($level);
    	if(self::validaAppsByCodigo($codigo) == "OK")
    	{
    		
    		$apps_sist = negSistema::getAplicacionCode($codigo);
    		$GO_URL = util::encodeParamURL('pth=0|home'.$param);
    		foreach ($apps_sist as $as)
    		{
    			if($as["codigo"] == $codigo)
    			{
    				$GO_URL = util::encodeParamURL('pth='.$as["cod_web"].$param);
    			}
    		}
    		$salida = $vuelve.'cw_home/home.php?'.$GO_URL;
    		
    	}else
    	{
    		$GO_URL = util::encodeParamURL('pth=999|error');
    		$salida = $vuelve.'cw_home/home.php?'.$GO_URL;
    	}
    	    	
    	
    	
    	return $salida;
    	
    }
    
    public static function getCodWeb($codigo)
    {
        $codWEB = '';
        if(self::validaAppsByCodigo($codigo) == "OK")
        {
            $apps_sist = negSistema::getAplicacionCode($codigo);
            foreach ($apps_sist as $as)
            {
                if($as["codigo"] == $codigo)
                {
                    $codWEB = $as["cod_web"];
                }
            }
        }
        
        return $codWEB;
    }
    public static function creaURLAppMasiva($level,$cod_web,$param="")
    {
        $vuelve=self::getLevel($level);
        $GO_URL = util::encodeParamURL('pth='.$cod_web.$param);
        $salida = $vuelve.'cw_home/home.php?'.$GO_URL;
        return $salida;
        
    }
   
    public static function creaURLAppDirect($level,$codigo,$param="",$html)
    {
        $salida = '';
        $vuelve=self::getLevel($level);
        if(self::validaAppsByCodigo($codigo) == "OK")
        {
            
            $apps_sist = negSistema::getAplicacionCode($codigo);
            $GO_URL = util::encodeParamURL('pth=0|home'.$param);
            foreach ($apps_sist as $as)
            {
                if($as["codigo"] == $codigo)
                {
                    $GO_URL = util::encodeParamURL('pth='.$as["cod_web"].$param);
                }
            }
            $salida = $vuelve.$html.'?'.$GO_URL;
            
        }
        
        
        
        return $salida;
        
    }
    public static function encodeParamURL($urlParam)
    {
    	
    	$urlParam = self::encodeKeyWord($urlParam);
    	return  "qwerty=".base64_encode($urlParam);
    }
    public static function validaFuncionApps($aplicacionid)
    {
    	$apps = $_SESSION["IGT-perfil_obj"];
    	$salida = "NO";
    	foreach ($apps as $a)
    	{
    		if($aplicacionid == $a["aplicacionid"])
    		{
    			$salida = "SI";
    		}
    		
    	}
    	
    	return $salida;
    }
    public static function getNombreMenu($obj)
    {
    	$salida = $obj["aplicacionidtxt"];
    	/*
    	$det = negSistema::getSistemaDef();
    	
    	if($obj["nombre_param"] != "")
    	{
    		$nom = $obj["nombre_param"];
    		$valor = $det[$nom];
    		
    		$salida = str_replace("[var]", $valor, $salida);
    	}
    	*/
    	return $salida;
    }
    
    public static function getMenu5($level,$gof)    
    {
    	//$sistema = negSistema::getSistemaDef();
    	$vuelve=self::getLevel($level);
    	$apps_sist = negSistema::getAplicacionesSistema();
    	
    	$mdls = explode("|", $gof);
    	$padreid = $mdls[0];
    	$modulo  = $mdls[1];
    	
    	$appsPerfil = $_SESSION["IGT-perfil_obj"];
    	
    	
     	$dpl = '<nav id="sidebar" class="px-0 bg-dark bg-gradient sidebar">
					<ul class="nav nav-pills flex-column">
						<li class="logo-nav-item">
							<a class="navbar-brand" href="'.$vuelve.'cw_home/home.php?'.util::encodeParamURL('pth=0|home').'">
								<img src="'.$vuelve.'/images/logo_sb_blanco_2.png" width="140"  alt="Cotizador Web">
							</a>
						</li>
						<li>
							<br />
						</li>';
     	$csis=0;
     	$chjo=0;
     	
     	foreach($apps_sist as $as)
     	{
     		
     		$appTxt = self::getNombreMenu($as);
     		
     		
     		$val = "NOK";
     		foreach ($appsPerfil as $ap)
     		{
     			
     			if($ap["aplicacionid"] == $as["aplicacionid"])
     			{
     				$val = "OK";     				
     				
     				
     				
     			}
     			
     		}
     		
     		
     		if($val == "OK" || ($as["tipo_menu"]=="PADRE" || $as["tipo_menu"]=="PRINCIPAL"))
     		{
     			if($as["tipo_aplicacion"] == "interna-menu")
     			{
     			    
     				$csis++;
     				$hrf	='';
     				
     				$activeP = '';
     				//$activoPUl = '';
     				$activeH = ' class="nav-link" ';
     				
     				if($as["page"]!="NA")
     				{
     					if($modulo ==  $as["codigo"] )
     					{
     						$activeH = ' class="nav-link active" ';
     					}
     					$GO_URL = util::encodeParamURL('pth='.$as["cod_web"]);
     					$hrf	=' href="'.$vuelve.'cw_home/home.php?'.$GO_URL.'" ';
     				}
     				
     				if($as["tipo_menu"]=="PADRE" )
     				{
     					$activeP=' href="#" class="nav-link nav-parent" ';
     					
     					if($padreid ==  $as["aplicacionid"])
     					{
     						$activeP 		= ' class="nav-link nav-parent active" ';
     						//$activoPUl		= ' style="display: block;" ';
     					}
     					
     					
     				}
     				
     				if($as["tipo_menu"]=="PRINCIPAL" )
     				{
     					if($padreid ==  $as["aplicacionid"])
     					{
     						$activeP = ' class="nav-link active" ';
     					}
     					$activeP=' '.$hrf.' class="nav-link" ';
     					
     				}
     				
     				
     				if($as["tipo_menu"]=="PADRE" || $as["tipo_menu"]=="PRINCIPAL")
     				{
     					if($chjo > 0)
     					{
     						
     						$dpl .='</ul>';
     						
     					}
     					$chjo=0;
     					if($csis > 1)
     					{
     						$dpl .='</li>';
     						
     					}
     					
     					$pinta='si';
     					
     					if($as["tipo_menu"]=="PADRE")
     					{
     						$pinta='no';
     						foreach($apps_sist as $asp)
     						{	
     							$valSP = "NOK";
     							foreach ($appsPerfil as $apps)
     							{	
     								if($apps["aplicacionid"] == $asp["aplicacionid"])
     								{
     									$valSP = "OK";
     								}
     							}
     							if($valSP == "OK")
     							{
     								if($as["aplicacionid"] == $asp["aplicacionpadreid"])
     								{
     									$pinta='si';
     								}
     							}
     							
     						}
     						
     					}
     					
     					if($pinta == 'si')
     					{
     						$dpl .='<li class="nav-item" >
							<a '.$activeP.'>
								'.$as["icono"].'
								<span>'.$appTxt.'</span>
							</a>';
     					}
     				}
     				
     				
     				
     				
     				if($as["tipo_menu"]=="HIJO" || $as["tipo_menu"]=="HEADER")
     				{
     					$chjo++;
     					if($chjo == 1)
     					{
     						$dpl .=' <ul class="nav nav-pills flex-column"> ';
     					}
     					
     					
     					$pnt = 'SI';
     					if( ($as["codigo"] == 'pry_todos_proyectos' || $as["codigo"] == 'pry_todos_subproyectos'|| $as["codigo"] == 'pry_todos_procesos'|| $as["codigo"] == 'pry_todos_objetos'))
     					{
     						$pnt = 'NO';
     					}
     					
     					
     					if($pnt == 'SI')
     					{
     						$dpl .='	<li class="nav-item">
								<a '.$activeH.' '.$hrf.'>
									'.$appTxt.'
								</a>
							</li>';
     					}
     					
     					
     				}
     				
     			}
     		}
     		
     		
     		
     	}
     	
     	
     	if($chjo > 0)
     	{
     		
     		$dpl .='</ul>';
     		
     	}
     	
     	if($csis > 0)
     	{
     		$dpl .='</li>';
     		
     	}
     	
     	$dpl .=' 
					</ul>
				</nav>';   
     
   
     
    return $dpl;
    }
    
    public static function getheader($level){
    	
    	$vuelve=self::getLevel($level);
    	
    	/*
    	$urlenv="usuarioid=".$_SESSION["IGT-usuarioid"]."&user=true";
    	$urlenv="edita_usuario.php?".util::encodeParamURL($urlenv);
    	*/
    	
    	
    	$html= '<header class="navbar navbar-expand-lg navbar-light container d-block d-lg-flex" id="header-navbar">    
		    <a class="navbar-brand float-left float-lg-none" href="index.html" id="logo">
		        <img alt="" class="normal-logo" src="'.$vuelve.'imgages/logo_sb.png" /> 
		         <span style="display: inline;" >Proyectos<span>
		    </a>
		    <button aria-controls="navbar-ex1-collapse" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler float-right float-lg-none" data-target=".navbar-ex1-collapse" data-toggle="collapse" type="button">
		        <span class="fa fa-bars"></span>
		    </button>
		    <ul class="nav navbar-nav mr-auto d-none d-lg-block mrg-l-none">
		        <li>
		            <a class="btn" id="make-small-nav">
		                <i class="fa fa-bars">
		                </i>
		            </a>
		        </li>
		        <li class="dropdown d-none d-md-block">
		            <a class="btn dropdown-toggle dropdown-nocaret" data-toggle="dropdown">
		                <i class="fa fa-bell">
		                </i>
		                <span class="count">
		                    3
		                </span>
		            </a>
		            <ul class="dropdown-menu notifications-list">
		                <li class="pointer">
		                    <div class="pointer-inner">
		                        <div class="arrow">
		                        </div>
		                    </div>
		                </li>
		                <li class="item-header">
		                    You have 3 new notifications
		                </li>
		                <li class="item">
		                     <a href="javascript:alert(\'En construccion\');">
		                        <i class="fa fa-comment">
		                        </i>
		                        <span class="content">
		                           Nuevo comentario 
		                        </span>
		                        <span class="time">
		                            <i class="fa fa-clock-o">
		                            </i>
		                            10 min.
		                        </span>
		                    </a>
		                </li>
		                <li class="item">
		                     <a href="javascript:alert(\'En construccion\');">
		                        <i class="fa fa-plus">
		                        </i>
		                        <span class="content">
		                            Alerta
		                        </span>
		                        <span class="time">
		                            <i class="fa fa-clock-o">
		                            </i>
		                            15 min.
		                        </span>
		                    </a>
		                </li>
		                <li class="item">
		                    <a href="javascript:alert(\'En construccion\');">
		                        <i class="fa fa-envelope">
		                        </i>
		                        <span class="content">
		                            Nuevo mensaje 
		                        </span>
								
		                        <span class="time">
		                            <i class="fa fa-clock-o">
		                            </i>
		                            25 min.
		                        </span>
		                    </a>
		                </li>
		               
		                <li class="item-footer">
		                    <a href="javascript:alert(\'En construccion\');">
		                        Ver Todas las Notificaciones
		                    </a>
		                </li>
		            </ul>
		        </li>
		        <li class="dropdown d-none d-md-block">
		            <a class="btn dropdown-toggle dropdown-nocaret" data-toggle="dropdown">
		                <i class="fa fa-tasks">
		                </i>
		                <span class="count">
		                    1
		                </span>
		            </a>
		            <ul class="dropdown-menu notifications-list messages-list">
		                <li class="pointer">
		                    <div class="pointer-inner">
		                        <div class="arrow">
		                        </div>
		                    </div>
		                </li>
		                <li class="item first-item">
		                   <a href="javascript:alert(\'En construccion\');">
		                       <span class="content-headline">
		                       		Cargar horas de trabajo

									 <span class="time">
										<br />
			                            <i class="fa fa-clock-o">
			                            </i>
			                            13 min.
			                        </span>
		                       </span>
		                       
		                    </a>
		                </li>
		                
		                <li class="item-footer">
		                    <a href="javascript:alert(\'En construccion\');">
		                        Revisar todas las tareas
		                    </a>
		                </li>
		            </ul>
		        </li>
		        		        
		    </ul>
		    <ul class="nav navbar-nav ml-auto float-right float-lg-none" id="header-nav">
		        <li class="dropdown d-md-block">
		            <a class="btn dropdown-toggle" data-toggle="dropdown">
		                <i class="fa fa-plus">
		                        </i> Agregar
		            </a>
		            <ul class="dropdown-menu">
						<li class="item">
		                   <a href="javascript:alert(\'En construccion\');">
		                        <i class="fa fa-calendar">
		                        </i>
		                        Registro de Horas
		                    </a>
		                </li>
						<li class="item">
		                    <a href="javascript:alert(\'En construccion\');">
		                        <i class="fa fa-file-text">
		                        </i>
		                        Nueva Tarea
		                    </a>
		                </li>
		                <li class="item">
							<a  class="md-trigger" data-toggle="modal"  href="#modal-form_cproy" >
							
		                         <i class="fa fa-sitemap">
		                        </i>
		                        Crear Proyecto
		                    </a>
		                </li>
						
		                
		                
		            </ul>
		        </li>
		        <li class="dropdown profile-dropdown">
		            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
		                <img alt="" src="'.$vuelve.'img/usuarios/no_user.png"/>
		                <span class="d-none d-md-block">
		                    '.$_SESSION["IGT-nombre_completo"].'
		                </span>
		                <b class="caret">
		                </b>
		            </a>
		            <ul class="dropdown-menu dropdown-menu-right">
		                <li>
		                    <a href="user-profile.html">
		                        <i class="fa fa-user">
		                        </i>
		                        Profile
		                    </a>
		                </li>
		                <li>
		                    <a href="#">
		                        <i class="fa fa-cog">
		                        </i>
		                        Settings
		                    </a>
		                </li>
		                <li>
		                    <a href="#">
		                        <i class="fa fa-envelope-o">
		                        </i>
		                        Messages
		                    </a>
		                </li>
		                <li>
		                    <a href="'.$vuelve.'cw_home/login.php">
		                        <i class="fa fa-power-off">
		                        </i>
		                        Logout
		                    </a>
		                </li>
		            </ul>
		        </li>
		        <li class="d-none d-sm-block">
		            <a class="btn" href="'.$vuelve.'cw_home/login.php" >
		                <i class="fa fa-power-off">
		                </i>
		            </a>
		        </li>
		    </ul>
		</header>
		';
    	
    	return $html;
    	
    }
    
    public static function getDatePickerJS($level){
    	
    	$vuelve=self::getLevel($level);
    	$html= '
				<link rel="stylesheet" href="'.$vuelve.'assets/datePicket/jquery-ui.css">
				<script src="'.$vuelve.'assets/datePicket/jquery-ui.js"></script>
    	';
    	return $html;
    	
    }
    
    public static function getJavaFunctions($level){
    
    	$vuelve=self::getLevel($level);
    
    	$html= '

		<!-- SCRIPTS - REQUIRED START -->
		<!-- Placed at the end of the document so the pages load faster -->
		<!-- Bootstrap core JavaScript -->
		<!-- JQuery -->
		<script type="text/javascript" src="'.$vuelve.'assets/js/jquery/jquery-3.1.1.min.js"></script>
		<!-- Popper.js - Bootstrap tooltips -->
		<script type="text/javascript" src="'.$vuelve.'assets/js/bootstrap/popper.min.js"></script>
		<!-- Bootstrap core JavaScript -->
		<script type="text/javascript" src="'.$vuelve.'assets/js/bootstrap/bootstrap.min.js"></script>
		<!-- MDB core JavaScript -->
		<script type="text/javascript" src="'.$vuelve.'assets/js/bootstrap/mdb.min.js"></script>
		<!-- Velocity -->
		<script type="text/javascript" src="'.$vuelve.'assets/plugins/velocity/velocity.min.js"></script>
		<script type="text/javascript" src="'.$vuelve.'assets/plugins/velocity/velocity.ui.min.js"></script>
		<!-- Custom Scrollbar -->
		<script type="text/javascript" src="'.$vuelve.'assets/plugins/custom-scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
		<!-- jQuery Visible -->
		<script type="text/javascript" src="'.$vuelve.'assets/plugins/jquery_visible/jquery.visible.min.js"></script>
		<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
		<script type="text/javascript" src="'.$vuelve.'assets/js/misc/ie10-viewport-bug-workaround.js"></script>
	
		<!-- SCRIPTS - REQUIRED END -->
	
		<!-- SCRIPTS - OPTIONAL START -->
	
		<!-- SCRIPTS - DEMO - START -->
		<!-- Image Placeholder -->
		<script type="text/javascript" src="'.$vuelve.'assets/js/misc/holder.min.js"></script>
		<!-- SCRIPTS - DEMO - END -->

		<!-- Toastr -->
		<script type="text/javascript" src="'.$vuelve.'assets/plugins/toastr/toastr.min.js"></script>
		
		<!-- SCRIPTS - OPTIONAL END -->
	
		<!-- QuillPro Scripts -->
		<script type="text/javascript" src="'.$vuelve.'assets/js/scripts.js"></script>

		<!-- Datatables -->
		<script type="text/javascript" src="'.$vuelve.'assets/plugins/datatables/js/jquery.dataTables.min.js"></script>
		<script type="text/javascript" src="'.$vuelve.'assets/plugins/datatables/js/dataTables.bootstrap4.min.js"></script>
		<script type="text/javascript" src="'.$vuelve.'assets/plugins/datatables/js/dataTables.responsive.min.js"></script>

		<!-- local scripts -->
		<script src="'.$vuelve.'js/util.js"></script>


		

				
		';
    	
    	
    	
    	
    	return $html;
    }
    public static function geHeadSistem($level)
    {
    	$vuelve=self::getLevel($level);
    	
    	
    	$GO_URL = util::creaURLApp(1, "conf_usuario_mis_datos");
    	$href_mis_datos	=' href="'.$GO_URL.'" ';
    	
    	$html = '<nav class="navbar navbar-expand-lg navbar-light bg-white">
					<a class="navbar-brand d-block d-sm-block d-md-block d-lg-none" href="#">
						<img src="'.$vuelve.'images/logo_sb_2.png" width="180" >
					</a>
					<button class="hamburger hamburger--slider" type="button" data-target=".sidebar" aria-controls="sidebar" aria-expanded="false" aria-label="Toggle Sidebar">
						<span class="hamburger-box">
							<span class="hamburger-inner"></span>
						</span>
					</button>
					<!-- Added Mobile-Only Menu -->
					<ul class="navbar-nav ml-auto mobile-only-control d-block d-sm-block d-md-block d-lg-none">
						<li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle" id="navbar-notification-search-mobile" data-toggle="dropdown" data-flip="false" aria-haspopup="true" aria-expanded="false">
								<i class="batch-icon batch-icon-search"></i>
							</a>
							<ul class="dropdown-menu dropdown-menu-fullscreen" aria-labelledby="navbar-notification-search-mobile">
								<li>
									<form class="form-inline my-2 my-lg-0 no-waves-effect">
										<div class="input-group">
											<input type="text" class="form-control" placeholder="Search for..." aria-label="Search for..." aria-describedby="basic-addon2">
											<div class="input-group-append">
												<button class="btn btn-primary btn-gradient waves-effect waves-light" type="button">
													<i class="batch-icon batch-icon-search"></i>
												</button>
											</div>
										</div>
									</form>
								</li>
							</ul>
						</li>
					</ul>

					<!--  DEPRECATED CODE:
						<div class="navbar-collapse" id="navbarSupportedContent">
					-->
					<!-- USE THIS CODE Instead of the Commented Code Above -->
					<!-- .collapse added to the element -->
					<div class="collapse navbar-collapse" id="navbar-header-content">
						<ul class="navbar-nav navbar-language-translation mr-auto">';
    	
    				$apps_sist = negSistema::getAplicacionesSistema();
    				$c_val = 0;
    				foreach ($apps_sist as $as)
    				{
    					if($as["tipo_menu"] == "HEADER")
    					{
    						if(self::validaAppsByAppId($as["aplicacionid"]) == "OK")
    						{
    							$c_val++;
    						}
    					}
    				}
    				
    				if($c_val >0)
    				{
    					$html.='
						
							<li class="nav-item dropdown">
								<a class="nav-link dropdown-toggle" id="navbar-dropdown-menu-link" data-toggle="dropdown" data-flip="false" aria-haspopup="true" aria-expanded="false">
									<i class="batch-icon batch-icon-inbox"></i>
									Acceso Rapido
								</a>
								<ul class="dropdown-menu" aria-labelledby="navbar-dropdown-menu-link">';
    					
    					foreach ($apps_sist as $as)
    					{
    						if($as["tipo_menu"] == "HEADER")
    						{
    							if(self::validaAppsByAppId($as["aplicacionid"]) == "OK")
    							{
    								
    								
    								$GO_URL = util::encodeParamURL('pth='.$as["cod_web"]);
    								$hrf	=' href="'.$vuelve.'cw_home/home.php?'.$GO_URL.'" ';
    								
    								
    								
    								$html.='<li><a class="dropdown-item" '.$hrf.'>'.self::getNombreMenu($as).'</a></li>';
    							}
    						}
    					}
    					
    					$html.='
								</ul>
							</li>
						';
    					
    				}
    	
    	
				
				
				$html.='</ul>
                        
						<ul class="navbar-nav navbar-notifications float-right">
                             <!--
							<li class="nav-item dropdown">
								<a class="nav-link dropdown-toggle" id="navbar-notification-search" data-toggle="dropdown" data-flip="false" aria-haspopup="true" aria-expanded="false">
									<i class="batch-icon batch-icon-search"></i>
								</a>
                               
								<ul class="dropdown-menu dropdown-menu-fullscreen" aria-labelledby="navbar-notification-search">
									<li>
										<form class="form-inline my-2 my-lg-0 no-waves-effect">
											<div class="input-group">
												<input type="text" class="form-control" placeholder="Busqueda de clientes..." aria-label="Busqueda de clientes.." aria-describedby="basic-addon2">
												<div class="input-group-append">
													<button class="btn btn-primary btn-gradient waves-effect waves-light" type="button">Buscar Cliente</button>
												</div>
											</div>
										</form>
									</li>
								</ul>
                               
							</li>
                             -->';
				
				$cv = 0;
				$cec = 0;
				
				/*COTIZACIONES EN CURSO USUARIO CONECTADO*/
				$MisCot = negCotizacion::getMisCotizacionesEnCurso();
				if(count($MisCot)>0){$cec=count($MisCot); $cv++;}
				
				
				/*VALIDA NOTIFICACIONES*/
				$notif = '';
				if($cv>0){$notif='<span class="notification-number">'.$cv.'</span>';}
				
				$html .='
							<li class="nav-item dropdown">
								<a class="nav-link dropdown-toggle no-waves-effect" id="navbar-notification-misc" data-toggle="dropdown" data-flip="false" aria-haspopup="true" aria-expanded="false">
									<i class="batch-icon batch-icon-bell"></i>
									'.$notif.'
								</a>
								<ul class="dropdown-menu dropdown-menu-right dropdown-menu-md" aria-labelledby="navbar-notification-misc">';
				
				                                    $html.='
													<li class="media">
														<a href="#">
															<i class="batch-icon batch-icon-bell batch-icon-xl d-flex mr-3"></i>
															<div class="media-body">
																<h6 class="mt-0 mb-1 notification-heading">Cotizaciones en Curso</h6>
																<div class="notification-text" onclick="goto(\''.util::creaURLApp(1, "mis_cotizacion_curso","").'\')" >
																	Tienes <span class="badge badge-pill badge-primary">'.$cec.'</span> cotización en curso
																</div>
																<span class="notification-time"></span>
															</div>
														</a>
													</li>';
				                    /*
									
										$html.='
													<li class="media">
														<a href="#">
															<i class="batch-icon batch-icon-bell batch-icon-xl d-flex mr-3"></i>
															<div class="media-body">
																<h6 class="mt-0 mb-1 notification-heading">Cotizaciones en Curso</h6>
																<div class="notification-text">
																	Tienes 40 cotizaciones en curso
																</div>
																<span class="notification-time">Revisar</span>
															</div>
														</a>
													</li>
                                                    <li class="media">
														<a href="#">
															<i class="batch-icon batch-icon-bell batch-icon-xl d-flex mr-3"></i>
															<div class="media-body">
																<h6 class="mt-0 mb-1 notification-heading">Cotizaciones pendientes</h6>
																<div class="notification-text">
																	Tienes 4 cotizaciones pendientes hace mas de una semana
																</div>
																<span class="notification-time">Notificar</span>
															</div>
														</a>
													</li>
										';
									
									*/
									
					$html.='
									
								</ul>
							</li>
						</ul>
						<ul class="navbar-nav ml-5 navbar-profile">
							<li class="nav-item dropdown">
								<a class="nav-link dropdown-toggle" id="navbar-dropdown-navbar-profile" data-toggle="dropdown" data-flip="false" aria-haspopup="true" aria-expanded="false">
									<div class="profile-name">
										'.$_SESSION["IGT-nombre_completo"].'
									</div>
									';

										$avatar = "../assets/img/user.png";
										if($_SESSION["IGT-avatarid"]!="")
										{
											$avatar = $_SESSION["IGT-avatarid"];
										}
										
										
										
					$html.='		<div class="profile-picture bg-gradient bg-primary has-message float-right">
										<img src="'.$avatar.'" width="44" height="44">
									</div>
								</a>
								<ul class="dropdown-menu dropdown-menu-right" aria-labelledby="navbar-dropdown-navbar-profile">
									<li><a class="dropdown-item" '.$href_mis_datos.'>Mis Datos</a></li>
									<li>
										<a class="dropdown-item" href="#">
											Manual de usuario											
										</a>
									</li>									
									<li><a class="dropdown-item" href="'.$vuelve.'cw_publico/login.php">Salir</a></li>
								</ul>
							</li>
						</ul>
					</div>
				</nav>';
    	
    	return $html;
    	
    	
    }
    public static function getHeadHtml($level,$descripcion,$validaSession='si'){

    	$vuelve=self::getLevel($level);      
    	if($validaSession == 'si')
    	{
    		//Valida session
    		self::validaSession($vuelve);
    		
    	}else
    	{
    	
    		$_SESSION["IGT-usuarioid"] = "1";
    	}
        $html= '
					
					<meta charset="utf-8">
					<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
					<meta name="description" content="Administración de Proyectos">
					<meta name="author" content="Imaginasoft Limitada.">
					
					<title>'.$descripcion.'- Version 1.0</title>
									
					<!-- Favicon -->
					<link rel="icon" href="'.$vuelve.'images/favicon.ico">

					<!-- Fonts -->
					<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,700&amp;subset=latin-ext" rel="stylesheet">
				
					<!-- CSS - REQUIRED - START -->
					<!-- Batch Icons -->
					<link rel="stylesheet" href="'.$vuelve.'assets/fonts/batch-icons/css/batch-icons.css">
					<!-- Bootstrap core CSS -->
					<link rel="stylesheet" href="'.$vuelve.'assets/css/bootstrap/bootstrap.min.css">
					<!-- Material Design Bootstrap -->
					<link rel="stylesheet" href="'.$vuelve.'assets/css/bootstrap/mdb.min.css">
					<!-- Custom Scrollbar -->
					<link rel="stylesheet" href="'.$vuelve.'assets/plugins/custom-scrollbar/jquery.mCustomScrollbar.min.css">
					<!-- Hamburger Menu -->
					<link rel="stylesheet" href="'.$vuelve.'assets/css/hamburgers/hamburgers.css">
				
					<!-- CSS - REQUIRED - END -->
				
					<!-- CSS - OPTIONAL - START -->
					<!-- Font Awesome -->
					<link rel="stylesheet" href="'.$vuelve.'assets/fonts/font-awesome/css/font-awesome.min.css">
					<link rel="stylesheet" href="'.$vuelve.'assets/plugins/datatables/css/responsive.dataTables.min.css">
					<link rel="stylesheet" href="'.$vuelve.'assets/plugins/datatables/css/responsive.bootstrap4.min.css">
				
					<!-- Toastr -->
					<link rel="stylesheet" href="'.$vuelve.'assets/plugins/toastr/toastr.min.css">
					
					<!-- CSS - OPTIONAL - END -->
				
					<!-- QuillPro Styles -->
					<link rel="stylesheet" href="'.$vuelve.'assets/css/quillpro/quillpro.css">
					
					
					';
      
        return $html;       
    }
    public static function getLevel($level)    
    {
        $vuelve="";
        if($level==0){
        	$vuelve="./";
        }
        if($level==1 || $level==1000){
            $vuelve="../";
        }
        if($level==2){
            $vuelve="../../";
        }
        if($level==3){
            $vuelve="../../../";
        }
        return $vuelve;
    }
   	
	public static function pintaConsoleJquery($datoInConsole)
    {
        echo '<script language="javascript" type="text/javascript">
                    $( document ).ready(function() {
                        console.log("'.$datoInConsole.'")
                    });
                    
             </script>
            ';
    }
    public static function getSelected($d1,$d2)
    {
    	$salida='  ';
    	if($d1==$d2)
    	{
    		$salida=' selected="selected" ';
    	}
    	
    	return($salida);
    }
    
    public static function getModal($id,$cierre="SI")
    {
    	
    	$htm= '
						<div class="modal fade" id="'.$id.'" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
							<div class="modal-dialog">
								<div class="modal-content">
									<div class="modal-header">
										<h4 class="modal-title" id="md_title_'.$id.'">Modal title</h4>';
    									if($cierre == 'SI')
    									{
    										$htm .='<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>';
    									}
		$htm.='
									</div>
									<div class="modal-body" id="md_body_'.$id.'">
										
										
									</div>
									<div class="modal-footer" id="md_footer_'.$id.'">
										<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
										<button type="button" class="btn btn-primary">Aceptar</button>
									</div>
								</div><!-- /.modal-content -->
							</div><!-- /.modal-dialog -->
						</div><!-- /.modal -->					
				';
    	
    	return $htm;
    }
    
    public static function getFooter($level)
    {
    	
    	$htm='	<div class="row mb-4">
			    	<div class="col-md-12">
				    	<footer>
				    	Powered by - <a href="http://www.imaginasoft.cl/" target="_blank" style="font-weight:300;color:#ffffff;background:#1d1d1d;padding:0 3px;">Imagina<span style="color:#ffa733;font-weight:bold"> SOFT</span> </a>
				    	</footer>
			    	</div>
			    </div>';
    	
    	return $htm;
    }
    
    public static function  normalizaAcentos($cadena){
    	$originales = 'ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝÞßàáâãäåæçèéêëìíîïðñòóôõöøùúûýýþÿŔŕ';
    	$modificadas = 'aaaaaaaceeeeiiiidnoooooouuuuybsaaaaaaaceeeeiiiidnoooooouuuyybyRr';
    	$cadena = utf8_decode($cadena);
    	$cadena = strtr($cadena, utf8_decode($originales), $modificadas);
    	$cadena = strtolower($cadena);
    	return utf8_encode($cadena);
    }
}

?>